from app.models import OHLCV

from fastapi import APIRouter, Depends, HTTPException
from fastapi import Query
from fastapi.responses import Response
from sqlalchemy.orm import Session, aliased
from sqlalchemy import func, or_, case

from app.database import SessionLocal
from app.services.providers.yahoo_provider import YahooProvider
from app.services.ohlcv_sync import sync_ohlcv
from app.services.fundamental_sync import sync_fundamental_data
from app.models import Fundamental, Ownership, Company, RankingSnapshot
from app.services.providers.bse_provider import BSEProvider
from app.services.providers.india_shareholding_provider import IndiaShareholdingProvider
from app.services.providers.sec_provider import SECFundamentalsProvider
from app.services.scheduler import refresh_configured_market_data
from app.services.equity_filters import apply_eligible_equity_filter
from app.services.universe_data_backfill import universe_data_status
from app.services.company_sync import repair_company_identity, bootstrap_companies_from_stored_data

import os
import math
import json
import time
import csv
import requests
from io import BytesIO, StringIO
from types import SimpleNamespace
from datetime import datetime, timedelta, date
from urllib.parse import quote
from statistics import median
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import yfinance as yf

router = APIRouter(prefix="/market", tags=["market"])


_LIVE_ROW_CACHE = {}
_LIVE_ROW_CACHE_TTL = 900
_LIVE_SCREENER_SNAPSHOT_CACHE = {}
_LIVE_BENCHMARK_CLOSE_CACHE = {}
_RANKING_ENRICH_CACHE = {}
_RANKING_ENRICH_TTL = 21600
_RANKING_SEC_PROVIDER = None
_RANKING_WARM_LOCK = threading.Lock()
_RANKING_WARM_ACTIVE = False


def _free_tier_mode() -> bool:
    raw = os.getenv("FREE_TIER_MODE", "1")
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def _live_provider_rows(symbol: str, exchange: str, years: int = 2):
    """Fetch provider history without persisting it to PostgreSQL.

    This is the free-tier escape hatch: charts/indicators keep working even when
    the small Railway volume cannot accept more OHLCV cache rows.
    """
    symbol = str(symbol or "").upper().strip()
    exchange = str(exchange or "US").upper().strip()
    years = max(1, min(6, int(years or 2)))
    cache_key = (exchange, symbol, years)
    cached = _LIVE_ROW_CACHE.get(cache_key)
    now = time.time()
    if cached and (now - cached[0]) < _LIVE_ROW_CACHE_TTL:
        return cached[1]

    start_date = (date.today() - timedelta(days=366 * years + 30)).isoformat()
    provider = YahooProvider()
    rows = []
    if exchange == "BSE":
        try:
            rows = BSEProvider().get_ohlcv(symbol) or []
        except Exception:
            rows = provider.get_ohlcv(symbol=symbol, exchange=exchange, start_date=start_date) or []
    else:
        rows = provider.get_ohlcv(symbol=symbol, exchange=exchange, start_date=start_date) or []

    normalized = []
    for item in rows:
        try:
            dt = item.get("date")
            if hasattr(dt, "date") and not isinstance(dt, date):
                dt = dt.date()
            if not isinstance(dt, date) or dt.weekday() >= 5:
                continue
            values = [float(item.get(k)) for k in ("open", "high", "low", "close")]
            if any((not math.isfinite(v)) or v <= 0 for v in values):
                continue
            volume = item.get("volume")
            try:
                volume = float(volume or 0)
                if not math.isfinite(volume):
                    volume = 0.0
            except Exception:
                volume = 0.0
            normalized.append(SimpleNamespace(
                date=dt,
                open=values[0], high=values[1], low=values[2], close=values[3],
                volume=volume,
            ))
        except Exception:
            continue
    normalized.sort(key=lambda row: row.date)
    _LIVE_ROW_CACHE[cache_key] = (now, normalized)
    return normalized


def _market_rows_with_live_fallback(db: Session, symbol: str, exchange: str, min_rows: int = 1, years: int = 2):
    """Read stored OHLCV when useful, otherwise use live provider rows."""
    stored = []
    if not _free_tier_mode():
        try:
            stored = (
                db.query(OHLCV)
                .filter(OHLCV.symbol == symbol.upper(), OHLCV.exchange == exchange.upper())
                .order_by(OHLCV.date.asc())
                .all()
            )
            stored = _valid_trading_rows(stored, exchange)
        except Exception:
            try:
                db.rollback()
            except Exception:
                pass
            stored = []
    else:
        # On the 500 MB Railway volume OHLCV is intentionally a disposable
        # cache; avoid depending on it after automatic compaction.
        try:
            stored = (
                db.query(OHLCV)
                .filter(OHLCV.symbol == symbol.upper(), OHLCV.exchange == exchange.upper())
                # Bounded free-tier reads must keep the newest rows, not the
                # oldest rows. The previous ASC + LIMIT could make a current
                # database appear to stop years ago.
                .order_by(OHLCV.date.desc())
                .limit(max(500, min_rows + 20))
                .all()
            )
            stored = sorted(_valid_trading_rows(stored, exchange), key=lambda row: row.date)
        except Exception:
            try:
                db.rollback()
            except Exception:
                pass
            stored = []
    # Do not treat a sufficiently long but stale database cache as current market data.
    # The client reported charts stopping in Sep-2023 while newer provider data exists.
    # Keep fresh stored rows when they are recent; otherwise fetch live rows and merge
    # them by date (live provider rows win on overlap). This preserves free-tier DB
    # savings without allowing a stale cache to freeze the chart/indicators.
    latest_stored_date = stored[-1].date if stored else None
    freshness_cutoff = date.today() - timedelta(days=7)
    stored_is_recent = bool(latest_stored_date and latest_stored_date >= freshness_cutoff)
    if len(stored) >= min_rows and stored_is_recent:
        return stored

    live = _live_provider_rows(symbol, exchange, years=years)
    if live:
        merged = {row.date: row for row in stored}
        for row in live:
            merged[row.date] = row
        merged_rows = [merged[key] for key in sorted(merged)]
        if len(merged_rows) >= min_rows:
            return merged_rows
        if len(live) >= min_rows:
            return live
    return stored or live


def _live_close_history_for_candidates(rows):
    """Batch-download up to a few hundred candidate close histories without DB writes."""
    result = {}
    provider = YahooProvider()
    by_exchange = {}
    for row in rows or []:
        ex = str(row.get("exchange") or "").upper()
        sym = str(row.get("symbol") or "").upper()
        if ex and sym:
            by_exchange.setdefault(ex, []).append(sym)

    for ex, symbols in by_exchange.items():
        # Keep the free-tier request bounded.  Top 200 needs only a modest
        # candidate buffer, not history for the full 8k/11k market universe.
        for offset in range(0, len(symbols), 80):
            chunk = symbols[offset:offset + 80]
            ticker_map = {provider.format_symbol(sym, ex): sym for sym in chunk}
            tickers = list(ticker_map.keys())
            if not tickers:
                continue
            try:
                frame = yf.download(
                    tickers=tickers,
                    period="2y",
                    interval="1d",
                    auto_adjust=False,
                    progress=False,
                    threads=True,
                    group_by="ticker",
                )
            except Exception:
                continue
            if frame is None or getattr(frame, "empty", True):
                continue

            for ticker, canonical in ticker_map.items():
                series = None
                try:
                    if hasattr(frame.columns, "nlevels") and frame.columns.nlevels > 1:
                        lvl0 = [str(x) for x in frame.columns.get_level_values(0)]
                        lvl1 = [str(x) for x in frame.columns.get_level_values(1)]
                        if ticker in lvl0:
                            sub = frame[ticker]
                            if "Close" in sub.columns:
                                series = sub["Close"]
                        elif ticker in lvl1 and "Close" in lvl0:
                            series = frame[("Close", ticker)]
                    elif len(tickers) == 1 and "Close" in frame.columns:
                        series = frame["Close"]
                except Exception:
                    series = None
                if series is None:
                    continue
                closes = []
                for value in series.tolist():
                    try:
                        value = float(value)
                        if math.isfinite(value) and value > 0:
                            closes.append(value)
                    except Exception:
                        continue
                if closes:
                    result[(ex, canonical)] = closes
    return result


def _live_benchmark_closes(group_key):
    """Fast exact-benchmark close series for Top-200 alpha/beta."""
    group_key = str(group_key or "").upper()
    ticker = "^GSPC" if group_key == "US" else "^CRSLDX" if group_key == "INDIA" else None
    if not ticker:
        return []
    cached = _LIVE_BENCHMARK_CLOSE_CACHE.get(group_key)
    now = time.time()
    if cached and (now - cached[0]) < _LIVE_ROW_CACHE_TTL:
        return cached[1]
    closes = []
    try:
        frame = yf.download(
            tickers=[ticker],
            period="2y",
            interval="1d",
            auto_adjust=False,
            progress=False,
            threads=False,
            group_by="ticker",
        )
        series = None
        if frame is not None and not getattr(frame, "empty", True):
            if hasattr(frame.columns, "nlevels") and frame.columns.nlevels > 1:
                lvl0 = [str(x) for x in frame.columns.get_level_values(0)]
                lvl1 = [str(x) for x in frame.columns.get_level_values(1)]
                if ticker in lvl0:
                    sub = frame[ticker]
                    if "Close" in sub.columns:
                        series = sub["Close"]
                elif ticker in lvl1 and "Close" in lvl0:
                    series = frame[("Close", ticker)]
            elif "Close" in frame.columns:
                series = frame["Close"]
        if series is not None:
            for value in series.tolist():
                number = _finite_number(value)
                if number is not None and number > 0:
                    closes.append(number)
    except Exception:
        closes = []
    if closes:
        _LIVE_BENCHMARK_CLOSE_CACHE[group_key] = (now, closes)
    return closes



def _finite_number(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except Exception:
        return None


def _ranking_history_metric_score(history, metric: str):
    """Score the confirmed 11 handwritten growth rules for EPS/PAT/Sales.

    A provider may expose fewer than all historical periods.  In that case the
    score is normalized only across rules whose required real inputs exist and
    the returned coverage reports how much of the 100-point rule set was
    actually observable.  No missing value is converted to zero or invented.
    """
    if not history:
        return {"score": None, "coverage": 0.0, "latest_yoy": None, "acceleration": None}
    quarterly = list(history.get("quarterly") or [])
    annual = list(history.get("annual") or [])

    def q(index, kind):
        if index >= len(quarterly):
            return None
        return _finite_number((quarterly[index] or {}).get(f"{kind}_{metric}"))

    def a(index):
        if index >= len(annual):
            return None
        return _finite_number((annual[index] or {}).get(f"yoy_{metric}"))

    qy0, qy1, qy2 = q(0, "yoy"), q(1, "yoy"), q(2, "yoy")
    qq0, qq1, qq2 = q(0, "qoq"), q(1, "qoq"), q(2, "qoq")
    ay0, ay1, ay2 = a(0), a(1), a(2)

    rules = [
        (10.0, (qy0,), lambda v: v[0] > 20),
        (10.0, (qy0, qy1), lambda v: (v[0] - v[1]) > 20),
        (10.0, (qy1, qy2), lambda v: (v[0] - v[1]) > 20),
        (10.0, (qy0, qy1, qy2), lambda v: (v[0] - ((v[1] + v[2]) / 2.0)) > 20),
        (10.0, (qq0,), lambda v: v[0] > 20),
        (10.0, (qq1,), lambda v: v[0] > 20),
        (10.0, (qq2,), lambda v: v[0] > 20),
        (5.0, (qq0, qq1, qq2), lambda v: (v[0] - ((v[1] + v[2]) / 2.0)) > 20),
        (10.0, (ay0,), lambda v: v[0] > 20),
        (5.0, (ay0, ay1), lambda v: (v[0] - v[1]) > 20),
        (10.0, (ay0, ay1, ay2), lambda v: (v[0] - ((v[1] + v[2]) / 2.0)) > 20),
    ]
    observed_weight = 0.0
    earned = 0.0
    for weight, values, predicate in rules:
        if any(value is None for value in values):
            continue
        observed_weight += weight
        try:
            if predicate(values):
                earned += weight
        except Exception:
            continue
    score = round((earned / observed_weight) * 100.0, 2) if observed_weight > 0 else None
    acceleration = (qy0 - qy1) if qy0 is not None and qy1 is not None else None
    return {
        "score": score,
        "coverage": round(observed_weight, 2),
        "latest_yoy": qy0,
        "acceleration": round(acceleration, 2) if acceleration is not None else None,
    }


def _ranking_fundamental_bundle(history):
    groups = {metric: _ranking_history_metric_score(history, metric) for metric in ("eps", "pat", "sales")}
    usable = [(item["score"], item["coverage"]) for item in groups.values() if item.get("score") is not None and item.get("coverage", 0) > 0]
    if not usable:
        overall = None
        coverage = 0.0
    else:
        total = sum(weight for _score, weight in usable)
        overall = round(sum(score * weight for score, weight in usable) / total, 2) if total else None
        coverage = round(sum(weight for _score, weight in usable) / 3.0, 2)
    return {
        "fundamental_score": overall,
        "fundamental_rule_coverage": coverage,
        "eps_score": groups["eps"]["score"],
        "pat_score": groups["pat"]["score"],
        "sales_score": groups["sales"]["score"],
        "eps_rule_coverage": groups["eps"]["coverage"],
        "pat_rule_coverage": groups["pat"]["coverage"],
        "sales_rule_coverage": groups["sales"]["coverage"],
        "eps_latest_yoy": groups["eps"]["latest_yoy"],
        "pat_latest_yoy": groups["pat"]["latest_yoy"],
        "sales_latest_yoy": groups["sales"]["latest_yoy"],
        "eps_acceleration": groups["eps"]["acceleration"],
        "pat_acceleration": groups["pat"]["acceleration"],
        "sales_acceleration": groups["sales"]["acceleration"],
    }


def _get_ranking_sec_provider():
    global _RANKING_SEC_PROVIDER
    if _RANKING_SEC_PROVIDER is not None:
        return _RANKING_SEC_PROVIDER
    try:
        _RANKING_SEC_PROVIDER = SECFundamentalsProvider()
    except Exception:
        _RANKING_SEC_PROVIDER = False
    return _RANKING_SEC_PROVIDER if _RANKING_SEC_PROVIDER is not False else None


def _fetch_ranking_enrichment(row):
    ex = str(row.get("exchange") or "").upper()
    symbol = str(row.get("symbol") or "").upper()
    if not ex or not symbol:
        return {}
    key = (ex, symbol)
    now = time.time()
    cached = _RANKING_ENRICH_CACHE.get(key)
    if cached and (now - cached[0]) < _RANKING_ENRICH_TTL:
        return cached[1]

    provider = YahooProvider()
    history = None
    if ex == "US":
        sec = _get_ranking_sec_provider()
        if sec is not None:
            try:
                history = sec.get_history(symbol)
            except Exception:
                history = None
    if not history:
        try:
            history = provider.get_fundamental_history(symbol, ex)
        except Exception:
            history = None

    metadata = {}
    # Metadata is fetched only when the stored row has a real gap.  This keeps
    # cold Top-200 refreshes within Railway/Vercel request budgets.
    metadata_fields = (
        "sector", "industry", "market_cap", "trailing_eps", "forward_eps",
        "revenue", "net_income", "profit_margin", "return_on_equity",
        "return_on_assets", "institution_percent", "insider_percent",
        "shares_outstanding", "float_shares",
    )
    needs_metadata = any(row.get(field) in (None, "", "N/A") for field in metadata_fields)
    if needs_metadata:
        try:
            metadata = provider.get_fundamentals(symbol, ex) or {}
        except Exception:
            metadata = {}

    payload = {"history": history, "metadata": metadata}
    payload.update(_ranking_fundamental_bundle(history))
    _RANKING_ENRICH_CACHE[key] = (now, payload)
    return payload


def _apply_ranking_enrichment(rows, limit=None):
    if not rows:
        return {}
    if limit is None:
        try:
            limit = int(os.getenv("TOP200_LIVE_ENRICH_LIMIT", "50") or 50)
        except Exception:
            limit = 50
    limit = max(0, min(len(rows), int(limit)))
    targets = list(rows[:limit])
    if not targets:
        return {}

    result = {}
    workers = max(1, min(8, len(targets)))
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(_fetch_ranking_enrichment, row): row for row in targets}
        for future in as_completed(futures):
            row = futures[future]
            key = (str(row.get("exchange") or "").upper(), str(row.get("symbol") or "").upper())
            try:
                payload = future.result() or {}
            except Exception:
                payload = {}
            result[key] = payload
            metadata = payload.get("metadata") or {}
            # Fill only gaps.  Existing stored provider data remains preferred.
            mapping = {
                "name": "name", "isin": "isin", "sector": "sector", "industry": "industry",
                "market_cap": "market_cap", "trailing_eps": "trailing_eps", "forward_eps": "forward_eps",
                "revenue": "revenue", "net_income": "net_income", "profit_margin": "profit_margin",
                "return_on_equity": "return_on_equity", "return_on_assets": "return_on_assets",
                "institution_percent": "institution_percent", "insider_percent": "insider_percent",
                "shares_outstanding": "shares_outstanding", "float_shares": "float_shares",
            }
            for target_field, source_field in mapping.items():
                if row.get(target_field) in (None, "", "N/A"):
                    value = metadata.get(source_field)
                    if value not in (None, "", "N/A", "nan", "NaN", "-"):
                        row[target_field] = value
    _persist_ranking_enrichment(result)
    return result



def _ranking_snapshot_ttl_seconds():
    try:
        return max(3600, int(os.getenv("TOP200_SNAPSHOT_TTL_SECONDS", "86400") or 86400))
    except Exception:
        return 86400


def _ranking_snapshot_payload(payload):
    """Strip bulky statement history before persisting ranking enrichment."""
    if not payload:
        return {}
    keep = {
        "metadata",
        "fundamental_score", "fundamental_rule_coverage",
        "eps_score", "pat_score", "sales_score",
        "eps_rule_coverage", "pat_rule_coverage", "sales_rule_coverage",
        "eps_latest_yoy", "pat_latest_yoy", "sales_latest_yoy",
        "eps_acceleration", "pat_acceleration", "sales_acceleration",
    }
    compact = {key: payload.get(key) for key in keep if key in payload}
    metadata = compact.get("metadata") or {}
    useful_metadata = any(value not in (None, "", "N/A", "nan", "NaN", "-") for value in metadata.values())
    useful_score = any(compact.get(key) is not None for key in ("fundamental_score", "eps_score", "pat_score", "sales_score"))
    return compact if (useful_metadata or useful_score) else {}


def _persist_ranking_enrichment(payloads):
    """Persist compact Top-200 enrichment so restarts do not lose it."""
    if not payloads:
        return
    db = SessionLocal()
    try:
        for (exchange, symbol), payload in payloads.items():
            compact = _ranking_snapshot_payload(payload)
            if not compact:
                continue

            # Persist small identity/classification metadata as well as the
            # compact ranking snapshot.  Top-200 enrichment previously filled
            # `sector` only in the request-local row, so the selected-stock
            # dashboard could still show Sector N/A on the very next request.
            metadata = compact.get("metadata") or {}
            company = (
                db.query(Company)
                .filter(
                    Company.exchange == str(exchange).upper(),
                    Company.symbol == str(symbol).upper(),
                )
                .first()
            )
            if company is not None:
                for attr in ("name", "isin", "sector", "industry"):
                    value = metadata.get(attr)
                    if value not in (None, "", "N/A", "nan", "NaN", "-"):
                        setattr(company, attr, str(value).strip())
                company.is_active = 1

            encoded = json.dumps(compact, default=str, separators=(",", ":"))
            snap = (
                db.query(RankingSnapshot)
                .filter(
                    RankingSnapshot.exchange == str(exchange).upper(),
                    RankingSnapshot.symbol == str(symbol).upper(),
                )
                .first()
            )
            if snap is None:
                snap = RankingSnapshot(
                    exchange=str(exchange).upper(),
                    symbol=str(symbol).upper(),
                    payload_json=encoded,
                )
                db.add(snap)
            else:
                snap.payload_json = encoded
                snap.updated_at = datetime.utcnow()
        db.commit()
    except Exception:
        try:
            db.rollback()
        except Exception:
            pass
    finally:
        db.close()


def _load_persisted_ranking_enrichment(rows):
    """Load compact persisted enrichment and fill metadata gaps."""
    rows = list(rows or [])
    if not rows:
        return {}
    wanted = {(str(r.get("exchange") or "").upper(), str(r.get("symbol") or "").upper()) for r in rows}
    wanted.discard(("", ""))
    if not wanted:
        return {}
    cutoff = datetime.utcnow() - timedelta(seconds=_ranking_snapshot_ttl_seconds())
    db = SessionLocal()
    try:
        snapshots = db.query(RankingSnapshot).filter(RankingSnapshot.updated_at >= cutoff).all()
    except Exception:
        try:
            db.rollback()
        except Exception:
            pass
        snapshots = []
    finally:
        db.close()

    result = {}
    for snap in snapshots:
        key = (str(snap.exchange or "").upper(), str(snap.symbol or "").upper())
        if key not in wanted:
            continue
        try:
            result[key] = json.loads(snap.payload_json or "{}") or {}
        except Exception:
            continue

    mapping = {
        "name": "name", "isin": "isin", "sector": "sector", "industry": "industry",
        "market_cap": "market_cap", "trailing_eps": "trailing_eps", "forward_eps": "forward_eps",
        "revenue": "revenue", "net_income": "net_income", "profit_margin": "profit_margin",
        "return_on_equity": "return_on_equity", "return_on_assets": "return_on_assets",
        "institution_percent": "institution_percent", "insider_percent": "insider_percent",
        "shares_outstanding": "shares_outstanding", "float_shares": "float_shares",
    }
    for row in rows:
        key = (str(row.get("exchange") or "").upper(), str(row.get("symbol") or "").upper())
        metadata = (result.get(key) or {}).get("metadata") or {}
        for target_field, source_field in mapping.items():
            if row.get(target_field) in (None, "", "N/A"):
                value = metadata.get(source_field)
                if value not in (None, "", "N/A", "nan", "NaN", "-"):
                    row[target_field] = value
    return result


def _apply_cached_ranking_enrichment(rows):
    result = {}
    now = time.time()
    mapping = {
        "name": "name", "isin": "isin", "sector": "sector", "industry": "industry",
        "market_cap": "market_cap", "trailing_eps": "trailing_eps", "forward_eps": "forward_eps",
        "revenue": "revenue", "net_income": "net_income", "profit_margin": "profit_margin",
        "return_on_equity": "return_on_equity", "return_on_assets": "return_on_assets",
        "institution_percent": "institution_percent", "insider_percent": "insider_percent",
        "shares_outstanding": "shares_outstanding", "float_shares": "float_shares",
    }
    for row in rows or []:
        key = (str(row.get("exchange") or "").upper(), str(row.get("symbol") or "").upper())
        cached = _RANKING_ENRICH_CACHE.get(key)
        if not cached or (now - cached[0]) >= _RANKING_ENRICH_TTL:
            continue
        payload = cached[1] or {}
        result[key] = payload
        metadata = payload.get("metadata") or {}
        for target_field, source_field in mapping.items():
            if row.get(target_field) in (None, "", "N/A"):
                value = metadata.get(source_field)
                if value not in (None, "", "N/A", "nan", "NaN", "-"):
                    row[target_field] = value
    return result


def _warm_ranking_enrichment_background(rows):
    """Progressively warm the remaining Top-200 statement cache after response work.

    This avoids making the first dashboard refresh wait for every candidate while
    still allowing subsequent refreshes to approach full real-data coverage.
    """
    global _RANKING_WARM_ACTIVE
    rows = list(rows or [])
    if not rows:
        return
    with _RANKING_WARM_LOCK:
        if _RANKING_WARM_ACTIVE:
            return
        _RANKING_WARM_ACTIVE = True

    def runner():
        global _RANKING_WARM_ACTIVE
        try:
            # Smaller provider batches reduce Yahoo/SEC throttling while the
            # cache is warming in the background.
            for offset in range(0, len(rows), 10):
                chunk = rows[offset:offset + 10]
                try:
                    _apply_ranking_enrichment(chunk, limit=len(chunk))
                except Exception:
                    continue
        finally:
            with _RANKING_WARM_LOCK:
                _RANKING_WARM_ACTIVE = False

    threading.Thread(target=runner, name="top200-ranking-warm", daemon=True).start()

def _sector_scores_from_enriched(rows, enrichment):
    """Bounded real-data sector score using the client's documented components.

    The live Top-200 path cannot afford an 11,500-stock historical statement
    crawl on a 500 MB Railway tier.  This therefore ranks real historical
    growth across the enriched candidate peer set and is explicitly marked
    provisional by the dashboard response.
    """
    buckets = {}
    for row in rows:
        key = (str(row.get("exchange") or "").upper(), str(row.get("symbol") or "").upper())
        payload = enrichment.get(key) or {}
        sector = str(row.get("sector") or "").strip()
        if not sector or not payload:
            continue
        bucket = buckets.setdefault(sector, {m: [] for m in ("eps_yoy", "pat_yoy", "sales_yoy", "eps_acc", "pat_acc", "sales_acc")})
        for metric, field in (("eps_yoy", "eps_latest_yoy"), ("pat_yoy", "pat_latest_yoy"), ("sales_yoy", "sales_latest_yoy"),
                              ("eps_acc", "eps_acceleration"), ("pat_acc", "pat_acceleration"), ("sales_acc", "sales_acceleration")):
            value = _finite_number(payload.get(field))
            if value is not None:
                bucket[metric].append(value)

    stats = {}
    for sector, bucket in buckets.items():
        def med(key):
            values = bucket.get(key) or []
            return float(median(values)) if values else None
        def breadth(key):
            values = bucket.get(key) or []
            return (sum(1 for value in values if value > 0) * 100.0 / len(values)) if values else None
        eps = med("eps_yoy"); pat = med("pat_yoy"); sales = med("sales_yoy")
        acc_values = [v for v in (med("eps_acc"), med("pat_acc"), med("sales_acc")) if v is not None]
        acceleration = sum(acc_values) / len(acc_values) if acc_values else None
        breadth_values = [v for v in (breadth("eps_yoy"), breadth("pat_yoy"), breadth("sales_yoy")) if v is not None]
        growth_breadth = sum(breadth_values) / len(breadth_values) if breadth_values else None
        accel_parts = [(breadth("eps_acc"), 35.0), (breadth("pat_acc"), 35.0), (breadth("sales_acc"), 30.0)]
        accel_parts = [(v, w) for v, w in accel_parts if v is not None]
        acceleration_breadth = (sum(v * w for v, w in accel_parts) / sum(w for _v, w in accel_parts)) if accel_parts else None
        stats[sector] = {
            "eps_raw": eps, "pat_raw": pat, "sales_raw": sales,
            "acceleration_raw": acceleration, "growth_breadth": growth_breadth,
            "acceleration_breadth": acceleration_breadth,
            "peer_count": max((len(values) for values in bucket.values()), default=0),
        }

    for sector, item in stats.items():
        eps_rs = _percentile_rank([x["eps_raw"] for x in stats.values()], item["eps_raw"])
        pat_rs = _percentile_rank([x["pat_raw"] for x in stats.values()], item["pat_raw"])
        sales_rs = _percentile_rank([x["sales_raw"] for x in stats.values()], item["sales_raw"])
        accel_rs = _percentile_rank([x["acceleration_raw"] for x in stats.values()], item["acceleration_raw"])
        components = [
            (eps_rs, 30.0), (pat_rs, 25.0), (sales_rs, 20.0), (accel_rs, 15.0),
            (item.get("growth_breadth"), 5.0), (item.get("acceleration_breadth"), 5.0),
        ]
        available = [(v, w) for v, w in components if v is not None]
        item["score"] = round(sum(v * w for v, w in available) / sum(w for _v, w in available), 2) if available else None
    return stats


def _selected_sector_component(db, company):
    """Return a real, bounded sector-growth score for the selected stock.

    Uses the same compact ranking snapshots produced by the Top-200 enrichment
    pipeline.  This avoids storing universe OHLCV while allowing the selected
    stock card to reuse real EPS/PAT/Sales growth history already fetched for
    the ranking dashboard.  Nothing is fabricated: if there is not enough
    cross-sector history, the component stays N/A.
    """
    if db is None or company is None:
        return None, 0, None

    exchange = str(company.exchange or "").upper()
    symbol = str(company.symbol or "").upper()
    if not exchange or not symbol:
        return None, 0, None

    # First recover classification from a fresh ranking snapshot when the
    # company master predates enrichment.
    cutoff = datetime.utcnow() - timedelta(seconds=_ranking_snapshot_ttl_seconds())
    try:
        selected_snap = (
            db.query(RankingSnapshot)
            .filter(
                RankingSnapshot.exchange == exchange,
                RankingSnapshot.symbol == symbol,
                RankingSnapshot.updated_at >= cutoff,
            )
            .first()
        )
    except Exception:
        selected_snap = None

    if selected_snap is not None:
        try:
            selected_payload = json.loads(selected_snap.payload_json or "{}") or {}
            metadata = selected_payload.get("metadata") or {}
            changed = False
            for attr in ("name", "isin", "sector", "industry"):
                value = metadata.get(attr)
                if value not in (None, "", "N/A", "nan", "NaN", "-") and not getattr(company, attr, None):
                    setattr(company, attr, str(value).strip())
                    changed = True
            if changed:
                db.commit()
        except Exception:
            try:
                db.rollback()
            except Exception:
                pass

    # If classification is still absent, make one bounded live metadata call
    # for the selected stock.  This is tiny compared with a universe backfill.
    if not getattr(company, "sector", None):
        try:
            metadata = YahooProvider().get_fundamentals(symbol, exchange) or {}
            changed = False
            for attr in ("name", "isin", "sector", "industry"):
                value = metadata.get(attr)
                if value not in (None, "", "N/A", "nan", "NaN", "-"):
                    setattr(company, attr, str(value).strip())
                    changed = True
            if changed:
                company.is_active = 1
                db.commit()
        except Exception:
            try:
                db.rollback()
            except Exception:
                pass

    sector_name = str(getattr(company, "sector", None) or "").strip()
    if not sector_name:
        return None, 0, None

    # Gather fresh compact snapshots across the same market.  Their metadata
    # supplies sector labels and their derived fields supply real growth /
    # acceleration metrics.  Cap the set to keep the free-tier request small.
    try:
        snaps = (
            db.query(RankingSnapshot)
            .filter(
                RankingSnapshot.exchange == exchange,
                RankingSnapshot.updated_at >= cutoff,
            )
            .order_by(RankingSnapshot.updated_at.desc())
            .limit(300)
            .all()
        )
    except Exception:
        snaps = []

    rows = []
    enrichment = {}
    seen = set()
    for snap in snaps:
        key = (str(snap.exchange or "").upper(), str(snap.symbol or "").upper())
        if key in seen:
            continue
        try:
            payload = json.loads(snap.payload_json or "{}") or {}
        except Exception:
            continue
        metadata = payload.get("metadata") or {}
        sector = str(metadata.get("sector") or "").strip()
        if not sector:
            continue
        seen.add(key)
        rows.append({"exchange": key[0], "symbol": key[1], "sector": sector})
        enrichment[key] = payload

    selected_key = (exchange, symbol)
    if selected_key not in enrichment:
        # Ensure the selected stock itself has a compact history payload. One
        # synchronous symbol fetch is bounded and is persisted for later loads.
        seed_row = {
            "exchange": exchange,
            "symbol": symbol,
            "sector": sector_name,
            "industry": getattr(company, "industry", None),
        }
        try:
            fetched = _apply_ranking_enrichment([seed_row], limit=1)
            enrichment.update(fetched)
            if fetched.get(selected_key):
                rows.append(seed_row)
        except Exception:
            pass

    if not rows or selected_key not in enrichment:
        return None, 0, sector_name

    stats = _sector_scores_from_enriched(rows, enrichment)
    info = stats.get(sector_name) or {}
    peer_count = int(info.get("peer_count") or 0)
    score = _finite_number(info.get("score"))

    # Breadth/acceleration are peer metrics; require a minimum real peer sample
    # before exposing a score on the selected-stock card.
    if score is None or peer_count < 5:
        return None, peer_count, sector_name
    return round(float(score), 2), peer_count, sector_name


def _alpha_beta_from_closes(stock_closes, benchmark_closes):
    if not stock_closes or not benchmark_closes:
        return None, None
    n = min(len(stock_closes), len(benchmark_closes), 253)
    if n < 61:
        return None, None
    stock = [float(v) for v in stock_closes[-n:] if _finite_number(v) is not None]
    bench = [float(v) for v in benchmark_closes[-n:] if _finite_number(v) is not None]
    n = min(len(stock), len(bench))
    if n < 61:
        return None, None
    stock = stock[-n:]; bench = bench[-n:]
    sr = [(stock[i] / stock[i - 1]) - 1.0 for i in range(1, n) if stock[i - 1] > 0]
    br = [(bench[i] / bench[i - 1]) - 1.0 for i in range(1, n) if bench[i - 1] > 0]
    nret = min(len(sr), len(br))
    if nret < 60:
        return None, None
    sr = sr[-nret:]; br = br[-nret:]
    mean_s = sum(sr) / nret; mean_b = sum(br) / nret
    var_b = sum((x - mean_b) ** 2 for x in br) / max(1, nret - 1)
    if var_b <= 0:
        return None, None
    cov = sum((sr[i] - mean_s) * (br[i] - mean_b) for i in range(nret)) / max(1, nret - 1)
    beta = cov / var_b
    alpha = (mean_s - (beta * mean_b)) * 252.0 * 100.0
    return round(alpha, 2), round(beta, 2)

def _standard_deviation_percent_from_closes(closes):
    """Annualized standard deviation of daily returns, expressed as percent."""
    values = [float(v) for v in (closes or [])[-253:] if _finite_number(v) is not None and float(v) > 0]
    if len(values) < 21:
        return None
    returns = [(values[i] / values[i - 1]) - 1.0 for i in range(1, len(values)) if values[i - 1] > 0]
    if len(returns) < 20:
        return None
    mean_return = sum(returns) / len(returns)
    variance = sum((value - mean_return) ** 2 for value in returns) / max(1, len(returns) - 1)
    return round((variance ** 0.5) * (252.0 ** 0.5) * 100.0, 2)


def _live_screener_snapshots(rows):
    """Return live one-year price snapshots for visible screener rows without DB writes.

    This keeps LTP/52-week fields useful after the free-tier OHLCV cache is compacted.
    Results are cached per symbol for the same 15-minute window as chart data.
    """
    now = time.time()
    result = {}
    missing = []
    provider = YahooProvider()
    for row in rows or []:
        ex = str(row.get("exchange") or "").upper()
        sym = str(row.get("symbol") or "").upper()
        if not ex or not sym:
            continue
        key = (ex, sym)
        cached = _LIVE_SCREENER_SNAPSHOT_CACHE.get(key)
        if cached and (now - cached[0]) < _LIVE_ROW_CACHE_TTL:
            result[key] = cached[1]
        else:
            missing.append((ex, sym))

    by_exchange = {}
    for ex, sym in missing:
        by_exchange.setdefault(ex, []).append(sym)

    for ex, symbols in by_exchange.items():
        for offset in range(0, len(symbols), 80):
            chunk = symbols[offset:offset + 80]
            ticker_map = {provider.format_symbol(sym, ex): sym for sym in chunk}
            tickers = list(ticker_map)
            if not tickers:
                continue
            try:
                frame = yf.download(
                    tickers=tickers,
                    period="1y",
                    interval="1d",
                    auto_adjust=False,
                    progress=False,
                    threads=True,
                    group_by="ticker",
                )
            except Exception:
                continue
            if frame is None or getattr(frame, "empty", True):
                continue

            def series_for(ticker, field):
                try:
                    if hasattr(frame.columns, "nlevels") and frame.columns.nlevels > 1:
                        lvl0 = [str(x) for x in frame.columns.get_level_values(0)]
                        lvl1 = [str(x) for x in frame.columns.get_level_values(1)]
                        if ticker in lvl0:
                            sub = frame[ticker]
                            return sub[field] if field in sub.columns else None
                        if ticker in lvl1 and field in lvl0:
                            return frame[(field, ticker)]
                    elif len(tickers) == 1 and field in frame.columns:
                        return frame[field]
                except Exception:
                    return None
                return None

            for ticker, canonical in ticker_map.items():
                close_s = series_for(ticker, "Close")
                high_s = series_for(ticker, "High")
                low_s = series_for(ticker, "Low")
                vol_s = series_for(ticker, "Volume")
                if close_s is None:
                    continue
                valid = []
                for idx, raw_close in close_s.items():
                    try:
                        close = float(raw_close)
                        if not math.isfinite(close) or close <= 0:
                            continue
                        high = float(high_s.loc[idx]) if high_s is not None else close
                        low = float(low_s.loc[idx]) if low_s is not None else close
                        volume = float(vol_s.loc[idx]) if vol_s is not None else 0.0
                        if not math.isfinite(high): high = close
                        if not math.isfinite(low): low = close
                        if not math.isfinite(volume): volume = 0.0
                        valid.append((idx, close, high, low, volume))
                    except Exception:
                        continue
                if not valid:
                    continue
                latest_idx, latest_close, _, _, latest_volume = valid[-1]
                highs = [x[2] for x in valid]
                lows = [x[3] for x in valid]
                vols = [x[4] for x in valid if x[4] > 0]
                high_52w = max(highs) if highs else None
                low_52w = min(lows) if lows else None
                avg_volume = (sum(vols) / len(vols)) if vols else None
                latest_date_value = latest_idx.date() if hasattr(latest_idx, "date") else latest_idx
                latest_date_text = latest_date_value.isoformat() if hasattr(latest_date_value, "isoformat") else str(latest_date_value)[:10]
                snap = {
                    "close": latest_close,
                    "volume": latest_volume,
                    "latest_date": latest_date_text,
                    "distance_52w_high": ((high_52w - latest_close) / high_52w * 100.0) if high_52w else None,
                    "distance_52w_low": ((latest_close - low_52w) / low_52w * 100.0) if low_52w else None,
                    "volume_ratio": (latest_volume / avg_volume) if avg_volume else None,
                }
                key = (ex, canonical)
                result[key] = snap
                _LIVE_SCREENER_SNAPSHOT_CACHE[key] = (now, snap)
    return result


def _enrich_screener_rows_live(items):
    if not items:
        return items
    snapshots = _live_screener_snapshots(items)
    for item in items:
        key = (str(item.get("exchange") or "").upper(), str(item.get("symbol") or "").upper())
        snap = snapshots.get(key) or {}
        for field in ("close", "volume", "latest_date", "distance_52w_high", "distance_52w_low", "volume_ratio"):
            if item.get(field) is None and snap.get(field) is not None:
                item[field] = snap[field]
        # Recompute coverage after live LTP enrichment. Provider fundamentals stay untouched.
        points = sum(1 for field in ("close", "market_cap", "trailing_eps", "revenue", "net_income", "profit_margin", "return_on_equity", "institution_percent") if item.get(field) is not None)
        if item.get("sector") is not None or item.get("industry") is not None:
            points += 1
        item["data_coverage"] = round(points * 100.0 / 9.0, 2)
    return items


def _json_safe(value):
    """Recursively replace non-finite numeric values with None for JSON responses."""
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    # numpy/pandas floating scalars can reach API responses after resampling.
    try:
        if value.__class__.__module__.startswith(("numpy", "pandas")):
            numeric = float(value)
            return numeric if math.isfinite(numeric) else None
    except Exception:
        pass
    return value


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


BENCHMARK_INDEX_EXCHANGE = "BENCHMARK"
BENCHMARK_SPECS = {
    "US": ("^GSPC", "S&P 500"),
    "NSE": ("^CRSLDX", "NIFTY 500"),
    "BSE": ("^CRSLDX", "NIFTY 500"),
}


def _benchmark_spec(exchange: str):
    return BENCHMARK_SPECS.get(str(exchange or "").upper())


def _clean_benchmark_points(points):
    """Normalize, de-duplicate and validate benchmark OHLC points."""
    cleaned = {}
    for item in points or []:
        try:
            trade_date, open_value, high_value, low_value, close_value = item
            if hasattr(trade_date, "date") and not isinstance(trade_date, date):
                trade_date = trade_date.date()
            if not isinstance(trade_date, date) or trade_date.weekday() >= 5:
                continue
            close_value = float(close_value)
            open_value = float(open_value if open_value is not None else close_value)
            high_value = float(high_value if high_value is not None else max(open_value, close_value))
            low_value = float(low_value if low_value is not None else min(open_value, close_value))
            values = (open_value, high_value, low_value, close_value)
            if any((not math.isfinite(v)) or v <= 0 for v in values):
                continue
            cleaned[trade_date] = (trade_date, *values)
        except (TypeError, ValueError, OverflowError):
            continue
    return [cleaned[key] for key in sorted(cleaned)]


def _benchmark_points_from_yfinance(ticker_symbol: str, period: str = "5y"):
    try:
        hist = yf.Ticker(ticker_symbol).history(period=period, interval="1d", auto_adjust=False)
        if hist is None or hist.empty:
            return []
        return _clean_benchmark_points([
            (
                idx.date(),
                row.get("Open"),
                row.get("High"),
                row.get("Low"),
                row.get("Close"),
            )
            for idx, row in hist.iterrows()
        ])
    except Exception:
        return []


def _benchmark_points_from_yahoo_chart(ticker_symbol: str, range_value: str = "5y"):
    """Direct Yahoo chart fallback, independent of yfinance parsing/cookies.

    Railway/cloud IPs can intermittently reach only one of Yahoo's chart hosts,
    so try both query1 and query2 before giving up.
    """
    encoded = quote(ticker_symbol, safe="")
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
        "Accept": "application/json,text/plain,*/*",
    }
    for host in ("query1.finance.yahoo.com", "query2.finance.yahoo.com"):
        try:
            response = requests.get(
                f"https://{host}/v8/finance/chart/{encoded}",
                params={
                    "range": range_value,
                    "interval": "1d",
                    "events": "history",
                    "includeAdjustedClose": "true",
                },
                headers=headers,
                timeout=20,
            )
            response.raise_for_status()
            payload = response.json()
            result = ((payload.get("chart") or {}).get("result") or [None])[0]
            if not result:
                continue
            timestamps = result.get("timestamp") or []
            quote_rows = (((result.get("indicators") or {}).get("quote") or [{}])[0])
            opens = quote_rows.get("open") or []
            highs = quote_rows.get("high") or []
            lows = quote_rows.get("low") or []
            closes = quote_rows.get("close") or []
            points = []
            for index, timestamp in enumerate(timestamps):
                if index >= len(closes) or closes[index] is None:
                    continue
                trade_date = datetime.utcfromtimestamp(int(timestamp)).date()
                points.append((
                    trade_date,
                    opens[index] if index < len(opens) else closes[index],
                    highs[index] if index < len(highs) else closes[index],
                    lows[index] if index < len(lows) else closes[index],
                    closes[index],
                ))
            cleaned = _clean_benchmark_points(points)
            if cleaned:
                return cleaned
        except Exception:
            continue
    return []


def _benchmark_points_from_twelvedata_nifty500(years: int = 5):
    """Exact NIFTY 500 fallback through the configured Twelve Data account.

    The provider symbol is discovered dynamically with ``symbol_search`` and is
    accepted only when the returned instrument name/symbol identifies NIFTY 500.
    This avoids guessing a proxy ticker while giving Railway a provider path
    independent of Yahoo/NSE web anti-bot behavior.
    """
    api_key = os.getenv("TWELVE_DATA_API_KEY", "").strip()
    if not api_key:
        return []

    headers = {
        "User-Agent": "StockScreener/2.0",
        "Accept": "application/json",
    }

    def norm(value):
        return "".join(ch for ch in str(value or "").upper() if ch.isalnum())

    try:
        search_response = requests.get(
            "https://api.twelvedata.com/symbol_search",
            params={
                "symbol": "NIFTY 500",
                "outputsize": 20,
                "apikey": api_key,
            },
            headers=headers,
            timeout=20,
        )
        search_response.raise_for_status()
        payload = search_response.json() or {}
        rows = payload.get("data") or payload.get("values") or []
        if not isinstance(rows, list):
            rows = []
    except Exception:
        return []

    exact_candidates = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        symbol = row.get("symbol")
        instrument_name = row.get("instrument_name") or row.get("name")
        instrument_type = str(row.get("instrument_type") or row.get("type") or "").upper()
        symbol_norm = norm(symbol)
        name_norm = norm(instrument_name)
        if "NIFTY500" not in {symbol_norm, name_norm} and not name_norm.startswith("NIFTY500"):
            continue
        # Prefer index-like instruments, but exact NIFTY 500 naming is still
        # required even when the provider omits instrument_type.
        if instrument_type and "INDEX" not in instrument_type:
            continue
        exact_candidates.append(row)

    for candidate in exact_candidates:
        symbol = candidate.get("symbol")
        if not symbol:
            continue
        params = {
            "symbol": symbol,
            "interval": "1day",
            "outputsize": min(5000, max(400, int(years) * 300)),
            "apikey": api_key,
        }
        exchange = candidate.get("exchange")
        mic_code = candidate.get("mic_code")
        if exchange:
            params["exchange"] = exchange
        elif mic_code:
            params["mic_code"] = mic_code
        try:
            response = requests.get(
                "https://api.twelvedata.com/time_series",
                params=params,
                headers=headers,
                timeout=30,
            )
            response.raise_for_status()
            data = response.json() or {}
            if data.get("status") == "error":
                continue
            values = data.get("values") or []
            points = []
            for item in values:
                try:
                    raw_date = str(item.get("datetime") or "").split(" ")[0]
                    trade_date = datetime.strptime(raw_date, "%Y-%m-%d").date()
                    close_value = float(item.get("close"))
                    open_value = float(item.get("open") or close_value)
                    high_value = float(item.get("high") or max(open_value, close_value))
                    low_value = float(item.get("low") or min(open_value, close_value))
                    points.append((trade_date, open_value, high_value, low_value, close_value))
                except Exception:
                    continue
            cleaned = _clean_benchmark_points(points)
            if cleaned:
                return cleaned
        except Exception:
            continue

    return []


def _benchmark_points_from_nseindia(index_name: str = "NIFTY 500", years: int = 5):
    """Official NSE India historical index API fallback.

    Uses NSE's current ``/api/historicalOR/indicesHistory`` endpoint with a
    browser-like session/cookie bootstrap.  Data is fetched in recent-first
    chunks so a later rate-limit/provider failure cannot discard already
    collected current history.
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
        "Accept": "application/json,text/plain,*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://www.nseindia.com/reports-indices-historical-index-data",
        "Connection": "keep-alive",
    }
    end_date = date.today()
    start_date = end_date - timedelta(days=max(1, int(years)) * 366)

    windows = []
    cursor_end = end_date
    while cursor_end >= start_date:
        cursor_start = max(start_date, cursor_end - timedelta(days=329))
        windows.append((cursor_start, cursor_end))
        cursor_end = cursor_start - timedelta(days=1)

    session = requests.Session()
    session.headers.update(headers)
    for bootstrap in (
        "https://www.nseindia.com/reports-indices-historical-index-data",
        "https://www.nseindia.com/",
    ):
        try:
            session.get(bootstrap, timeout=10)
            if session.cookies:
                break
        except Exception:
            continue

    points_by_date = {}
    normalized_requested = " ".join(str(index_name).upper().split())
    for chunk_start, chunk_end in windows:
        try:
            response = session.get(
                "https://www.nseindia.com/api/historicalOR/indicesHistory",
                params={
                    "indexType": index_name,
                    "from": chunk_start.strftime("%d-%m-%Y"),
                    "to": chunk_end.strftime("%d-%m-%Y"),
                },
                timeout=20,
            )
            response.raise_for_status()
            payload = response.json() or {}
            rows = payload.get("data") or []
            if isinstance(rows, dict):
                rows = rows.get("indexCloseOnlineRecords") or rows.get("data") or []
            if not isinstance(rows, list):
                rows = []
        except Exception:
            continue

        for row in rows:
            if not isinstance(row, dict):
                continue
            try:
                response_name = row.get("EOD_INDEX_NAME") or row.get("INDEX_NAME") or row.get("indexName")
                if response_name:
                    normalized_response = " ".join(str(response_name).upper().split())
                    if normalized_response != normalized_requested:
                        continue

                raw_date = row.get("EOD_TIMESTAMP") or row.get("TIMESTAMP") or row.get("HistoricalDate") or row.get("Date")
                trade_date = None
                for fmt in (
                    "%d-%b-%Y", "%d %b %Y", "%d-%B-%Y", "%d %B %Y",
                    "%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y",
                ):
                    try:
                        trade_date = datetime.strptime(str(raw_date).strip(), fmt).date()
                        break
                    except Exception:
                        continue
                if trade_date is None:
                    continue

                def num(*keys):
                    for key in keys:
                        value = row.get(key)
                        if value not in (None, "", "-"):
                            return float(str(value).replace(",", ""))
                    return None

                close_value = num("EOD_CLOSE_INDEX_VAL", "CLOSE", "Close", "close")
                if close_value is None:
                    continue
                points_by_date[trade_date] = (
                    trade_date,
                    num("EOD_OPEN_INDEX_VAL", "OPEN", "Open", "open") or close_value,
                    num("EOD_HIGH_INDEX_VAL", "HIGH", "High", "high") or close_value,
                    num("EOD_LOW_INDEX_VAL", "LOW", "Low", "low") or close_value,
                    close_value,
                )
            except Exception:
                continue

        cleaned = _clean_benchmark_points(points_by_date.values())
        if len(cleaned) >= 200 and cleaned[-1][0] >= date.today() - timedelta(days=45):
            return cleaned

    return _clean_benchmark_points(points_by_date.values())


def _benchmark_points_from_niftyindices(index_name: str = "NIFTY 500", years: int = 5):
    """Official NSE Indices historical-data fallback for Indian benchmarks.

    The publisher uses a legacy ASP.NET endpoint whose payload/edge behavior is
    inconsistent across deployments. Try both official hosts and both known
    cinfo encodings. Request newest chunks first so even a later edge/rate-limit
    failure still leaves current benchmark overlap for RS calculations.
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Content-Type": "application/json; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
        "Referer": "https://www.niftyindices.com/reports/historical-data",
    }
    end_date = date.today()
    start_date = end_date - timedelta(days=max(1, int(years)) * 366)

    # Build recent-first <= 360-day windows. Recent benchmark overlap is more
    # important than old history for the client's 1W..1Y RS calculation.
    windows = []
    cursor_end = end_date
    while cursor_end >= start_date:
        cursor_start = max(start_date, cursor_end - timedelta(days=359))
        windows.append((cursor_start, cursor_end))
        cursor_end = cursor_start - timedelta(days=1)

    points_by_date = {}
    for host in ("https://www.niftyindices.com", "https://niftyindices.com"):
        session = requests.Session()
        session.headers.update(headers)
        try:
            session.get(f"{host}/reports/historical-data", timeout=8)
        except Exception:
            pass

        for chunk_start, chunk_end in windows:
            date_variants = [
                (chunk_start.strftime("%d-%b-%Y"), chunk_end.strftime("%d-%b-%Y")),
                (chunk_start.strftime("%d %b %Y"), chunk_end.strftime("%d %b %Y")),
            ]
            chunk_rows = []
            for start_text, end_text in date_variants:
                cinfo_dict = {
                    "name": index_name,
                    "startDate": start_text,
                    "endDate": end_text,
                    "indexName": index_name,
                }
                cinfo_variants = [
                    json.dumps(cinfo_dict, separators=(",", ":")),
                    "{'name':'%s','startDate':'%s','endDate':'%s','indexName':'%s'}"
                    % (index_name, start_text, end_text, index_name),
                ]
                for cinfo in cinfo_variants:
                    try:
                        response = session.post(
                            f"{host}/Backpage.aspx/getHistoricaldatatabletoString",
                            data=json.dumps({"cinfo": cinfo}),
                            timeout=20,
                        )
                        response.raise_for_status()
                        outer = response.json() or {}
                        raw = outer.get("d")
                        if isinstance(raw, str):
                            rows = json.loads(raw or "[]")
                        elif isinstance(raw, list):
                            rows = raw
                        else:
                            rows = []
                        if rows:
                            chunk_rows = rows
                            break
                    except Exception:
                        continue
                if chunk_rows:
                    break

            for row in chunk_rows:
                try:
                    raw_date = row.get("HistoricalDate") or row.get("DATE") or row.get("Date")
                    trade_date = None
                    for fmt in ("%d %b %Y", "%d-%b-%Y", "%Y-%m-%d"):
                        try:
                            trade_date = datetime.strptime(str(raw_date).strip(), fmt).date()
                            break
                        except Exception:
                            continue
                    if trade_date is None:
                        continue

                    def num(*keys):
                        for key in keys:
                            value = row.get(key)
                            if value not in (None, "", "-"):
                                return float(str(value).replace(",", ""))
                        return None

                    close_value = num("CLOSE", "Close", "close")
                    if close_value is None:
                        continue
                    point = (
                        trade_date,
                        num("OPEN", "Open", "open") or close_value,
                        num("HIGH", "High", "high") or close_value,
                        num("LOW", "Low", "low") or close_value,
                        close_value,
                    )
                    points_by_date[trade_date] = point
                except Exception:
                    continue

            # Once we have enough recent daily observations for 1Y RS, continue
            # older windows opportunistically, but a failure must not discard the
            # recent data already collected.

        cleaned = _clean_benchmark_points(points_by_date.values())
        if len(cleaned) >= 200 and cleaned[-1][0] >= date.today() - timedelta(days=45):
            return cleaned

    return _clean_benchmark_points(points_by_date.values())

def _cached_benchmark_points(db: Session, ticker_symbol: str):
    if db is None:
        return []
    try:
        rows = (
            db.query(OHLCV)
            .filter(
                OHLCV.exchange == BENCHMARK_INDEX_EXCHANGE,
                OHLCV.symbol == ticker_symbol,
            )
            .order_by(OHLCV.date.asc())
            .all()
        )
        return _clean_benchmark_points([
            (row.date, row.open, row.high, row.low, row.close) for row in rows
        ])
    except Exception:
        return []


def _cache_benchmark_points(db: Session, ticker_symbol: str, points):
    if db is None or not points or _free_tier_mode():
        return
    try:
        normalized = _clean_benchmark_points(points)
        existing_rows = (
            db.query(OHLCV)
            .filter(
                OHLCV.exchange == BENCHMARK_INDEX_EXCHANGE,
                OHLCV.symbol == ticker_symbol,
            )
            .all()
        )
        existing = {row.date: row for row in existing_rows}
        for trade_date, open_value, high_value, low_value, close_value in normalized:
            row = existing.get(trade_date)
            if row is None:
                row = OHLCV(
                    symbol=ticker_symbol,
                    exchange=BENCHMARK_INDEX_EXCHANGE,
                    date=trade_date,
                )
                db.add(row)
            row.open = open_value
            row.high = high_value
            row.low = low_value
            row.close = close_value
            row.volume = 0.0
        db.commit()
    except Exception:
        try:
            db.rollback()
        except Exception:
            pass


def _benchmark_series_usable(points, minimum_points: int = 200, max_age_days: int = 45):
    cleaned = _clean_benchmark_points(points)
    if len(cleaned) < minimum_points:
        return False
    return cleaned[-1][0] >= date.today() - timedelta(days=max_age_days)


def _load_benchmark_points(exchange: str, db: Session = None, minimum_points: int = 200):
    """Return a resilient exact broad-market benchmark series.

    Priority is a recent database cache, then Yahoo/yfinance, then Yahoo's direct
    chart endpoint. Indian markets then try the current official NSE India
    historical-index API and the legacy NSE Indices endpoint before falling back
    to an older verified cache. The exact benchmark is never replaced by a proxy.
    """
    spec = _benchmark_spec(exchange)
    if not spec:
        return [], None, None, "Unsupported exchange"
    ticker_symbol, benchmark_name = spec

    cached = _cached_benchmark_points(db, ticker_symbol)
    if _benchmark_series_usable(cached, minimum_points=minimum_points, max_age_days=45):
        return cached, ticker_symbol, benchmark_name, "Database benchmark cache"

    loaders = [
        (lambda symbol: _benchmark_points_from_yfinance(symbol), "Yahoo Finance via yfinance"),
        (lambda symbol: _benchmark_points_from_yahoo_chart(symbol), "Yahoo Finance direct chart fallback"),
    ]
    # For Indian markets, use the current official NSE India historical-index
    # API before the legacy NSE Indices endpoint. Both request the exact NIFTY
    # 500 index; neither substitutes a proxy instrument.
    if str(exchange or "").upper() in {"NSE", "BSE"} and benchmark_name == "NIFTY 500":
        loaders.extend([
            (lambda _symbol: _benchmark_points_from_twelvedata_nifty500(years=5),
             "Twelve Data exact NIFTY 500 fallback"),
            (lambda _symbol: _benchmark_points_from_nseindia("NIFTY 500", years=5),
             "Official NSE India historical index API"),
            (lambda _symbol: _benchmark_points_from_niftyindices("NIFTY 500", years=5),
             "Official NSE Indices legacy historical fallback"),
        ])

    for loader, method in loaders:
        points = loader(ticker_symbol)
        if _benchmark_series_usable(points, minimum_points=minimum_points, max_age_days=45):
            _cache_benchmark_points(db, ticker_symbol, points)
            return points, ticker_symbol, benchmark_name, method

    if _benchmark_series_usable(cached, minimum_points=minimum_points, max_age_days=90):
        return cached, ticker_symbol, benchmark_name, "Stored benchmark fallback"
    return [], ticker_symbol, benchmark_name, "Benchmark unavailable"


def _benchmark_close_points(exchange: str, db: Session = None):
    points, symbol, name, method = _load_benchmark_points(exchange, db=db)
    return [(d, o, c) for d, o, _h, _l, c in points], symbol, name, method


def _valid_trading_rows(rows, exchange: str):
    """Exclude invalid stock bars from calculations and API output.

    Normal US/NSE/BSE equity candles must be weekday-dated and have finite,
    strictly positive OHLC values.  Filtering here protects the UI and ranking
    calculations from legacy/provider rows such as a zero close.
    """
    rows = list(rows)
    if exchange.upper() not in {"US", "NSE", "BSE"}:
        return rows

    valid = []
    for row in rows:
        if row.date is None or row.date.weekday() >= 5:
            continue
        try:
            ohlc = [float(row.open), float(row.high), float(row.low), float(row.close)]
        except (TypeError, ValueError):
            continue
        if any((not math.isfinite(value)) or value <= 0 for value in ohlc):
            continue
        valid.append(row)
    return valid


def _ema(values, period):
    if len(values) < period:
        return None
    multiplier = 2 / (period + 1)
    value = sum(values[:period]) / period
    for price in values[period:]:
        value = ((price - value) * multiplier) + value
    return value


def _rma(values, period):
    """TradingView/Wilder moving average used by ATR and RSI-style smoothing."""
    if len(values) < period:
        return None
    value = sum(values[:period]) / period
    alpha = 1 / period
    for item in values[period:]:
        value = (alpha * item) + ((1 - alpha) * value)
    return value


def _rsi(values, period=14):
    if len(values) < period + 1:
        return None
    changes = [values[i] - values[i - 1] for i in range(1, len(values))]
    gains = [max(change, 0) for change in changes]
    losses = [max(-change, 0) for change in changes]

    def rma(items):
        result = sum(items[:period]) / period
        alpha = 1 / period
        for item in items[period:]:
            result = (alpha * item) + ((1 - alpha) * result)
        return result

    avg_gain = rma(gains)
    avg_loss = rma(losses)
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


CLIENT_COMPOSITE_WEIGHTS = {
    "technical": 25.0,
    "fundamental": 30.0,
    "ownership": 15.0,
    "sector": 5.0,
    "relative_strength": 25.0,
}

CLIENT_SECTOR_WEIGHTS = {
    "eps_growth_rs": 30.0,
    "pat_growth_rs": 25.0,
    "sales_growth_rs": 20.0,
    "growth_acceleration_rs": 15.0,
    "growth_breadth": 5.0,
    "acceleration_breadth": 5.0,
}


# Compact filter-table defaults from the client's latest handwritten layout.
# Thresholds/weights that were not legible or not explicitly defined remain
# zero/disabled so the screener never invents a ranking rule.
CLIENT_TECHNICAL_FILTER_CONFIG = [
    {"name": "Upper BB - Lower BB", "compare": "<=", "value": 10.0, "weight": 10.0, "enabled": True},
    {"name": "5-day ATR% average vs 20-day ATR% average", "compare": "<", "value": "20-day ATR%", "weight": 10.0, "enabled": True},
    {"name": "10-day ATR% average vs 20-day ATR% average", "compare": "<", "value": "20-day ATR%", "weight": 5.0, "enabled": True},
    {"name": "RSI (14)", "compare": "bands", "value": "30 / 40 / 50", "weight": 5.0, "enabled": True},
    {"name": "10-day volume average vs 20-day volume average", "compare": "<", "value": "20-day volume", "weight": 10.0, "enabled": True},
    {"name": "20-day volume average vs 40-day volume average", "compare": "<", "value": "40-day volume", "weight": 5.0, "enabled": True},
    {"name": "Distance from 52-week high", "compare": "bands", "value": "10 / 17 / 20%", "weight": 10.0, "enabled": True},
    {"name": "20 EMA vs 50 EMA", "compare": ">", "value": "50 EMA", "weight": 8.0, "enabled": True},
    {"name": "50 EMA vs 150 EMA", "compare": ">", "value": "150 EMA", "weight": 4.0, "enabled": True},
]

CLIENT_FUNDAMENTAL_FILTER_CONFIG = [
    {"group": 'EPS', "name": 'Latest quarter EPS growth (YoY)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'EPS', "name": 'Latest Q EPS YoY - prior Q EPS YoY', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'EPS', "name": 'Prior Q EPS YoY - second-prior Q EPS YoY', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'EPS', "name": 'Latest Q EPS YoY - prior-two YoY average', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'EPS', "name": 'Latest quarter EPS growth (QoQ)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'EPS', "name": 'Prior-quarter EPS growth (QoQ)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'EPS', "name": 'Second-prior-quarter EPS growth (QoQ)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'EPS', "name": 'Latest Q EPS QoQ - prior-two QoQ average', "compare": '>', "value": 20, "weight": 5.0, "enabled": True},
    {"group": 'EPS', "name": 'Latest annual EPS growth (YoY)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'EPS', "name": 'Latest annual EPS YoY - prior annual EPS YoY', "compare": '>', "value": 20, "weight": 5.0, "enabled": True},
    {"group": 'EPS', "name": 'Latest annual EPS YoY - prior-two annual YoY average', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'PAT', "name": 'Latest quarter PAT growth (YoY)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'PAT', "name": 'Latest Q PAT YoY - prior Q PAT YoY', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'PAT', "name": 'Prior Q PAT YoY - second-prior Q PAT YoY', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'PAT', "name": 'Latest Q PAT YoY - prior-two YoY average', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'PAT', "name": 'Latest quarter PAT growth (QoQ)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'PAT', "name": 'Prior-quarter PAT growth (QoQ)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'PAT', "name": 'Second-prior-quarter PAT growth (QoQ)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'PAT', "name": 'Latest Q PAT QoQ - prior-two QoQ average', "compare": '>', "value": 20, "weight": 5.0, "enabled": True},
    {"group": 'PAT', "name": 'Latest annual PAT growth (YoY)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'PAT', "name": 'Latest annual PAT YoY - prior annual PAT YoY', "compare": '>', "value": 20, "weight": 5.0, "enabled": True},
    {"group": 'PAT', "name": 'Latest annual PAT YoY - prior-two annual YoY average', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'Sales', "name": 'Latest quarter Sales growth (YoY)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'Sales', "name": 'Latest Q Sales YoY - prior Q Sales YoY', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'Sales', "name": 'Prior Q Sales YoY - second-prior Q Sales YoY', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'Sales', "name": 'Latest Q Sales YoY - prior-two YoY average', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'Sales', "name": 'Latest quarter Sales growth (QoQ)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'Sales', "name": 'Prior-quarter Sales growth (QoQ)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'Sales', "name": 'Second-prior-quarter Sales growth (QoQ)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'Sales', "name": 'Latest Q Sales QoQ - prior-two QoQ average', "compare": '>', "value": 20, "weight": 5.0, "enabled": True},
    {"group": 'Sales', "name": 'Latest annual Sales growth (YoY)', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'Sales', "name": 'Latest annual Sales YoY - prior annual Sales YoY', "compare": '>', "value": 20, "weight": 5.0, "enabled": True},
    {"group": 'Sales', "name": 'Latest annual Sales YoY - prior-two annual YoY average', "compare": '>', "value": 20, "weight": 10.0, "enabled": True},
    {"group": 'NPM', "name": 'Latest quarter NPM growth (YoY)', "compare": '>', "value": 20.0, "weight": 20.0, "enabled": True},
    {"group": 'NPM', "name": 'Latest quarter NPM growth (QoQ)', "compare": '>', "value": 20.0, "weight": 20.0, "enabled": True},
    {"group": 'NPM', "name": 'Latest annual NPM growth (YoY)', "compare": '>', "value": 20.0, "weight": 20.0, "enabled": True},
    {"group": 'NPM', "name": 'NPM expansion vs 3-year average', "compare": '>', "value": 0.0, "weight": 0.0, "enabled": True},
    {"group": 'NPM', "name": 'Industry NPM comparison', "compare": 'industry', "value": 'Above median=20 points; below median=10 points', "weight": 20.0, "enabled": True},
    {"group": 'NPM', "name": 'Latest Q NPM YoY - prior Q NPM YoY', "compare": '>', "value": 20.0, "weight": 0.0, "enabled": True},
    {"group": 'CFO', "name": 'Operating cash flow growth (YoY)', "compare": '>', "value": 0.0, "weight": 0.0, "enabled": False},
    {"group": 'CFO', "name": 'Cash flow per share', "compare": '>', "value": 0.0, "weight": 0.0, "enabled": False},
    {"group": 'Other', "name": 'ROE', "compare": '>', "value": 20.0, "weight": 0.0, "enabled": True},
    {"group": 'Other', "name": 'ROCE', "compare": '>', "value": 30.0, "weight": 0.0, "enabled": True},
    {"group": 'Other', "name": 'Outstanding shares', "compare": '<', "value": 0.0, "weight": 0.0, "enabled": False},
    {"group": 'Other', "name": 'Float shares', "compare": '<', "value": 0.0, "weight": 0.0, "enabled": False},
]


def _roc(values, periods):
    if periods <= 0 or len(values) <= periods:
        return None
    base = values[-1 - periods]
    if base in (None, 0):
        return None
    return ((values[-1] / base) - 1) * 100


def _wilder_series(values, period):
    if len(values) < period:
        return []
    out = [None] * len(values)
    value = sum(values[:period]) / period
    out[period - 1] = value
    for i in range(period, len(values)):
        value = ((value * (period - 1)) + values[i]) / period
        out[i] = value
    return out


def _adx_di(highs, lows, closes, period=14):
    """Return latest ADX, +DI, -DI and DI spread using Wilder smoothing."""
    if len(closes) < (period * 2 + 1):
        return None, None, None, None
    trs, plus_dm, minus_dm = [], [], []
    for i in range(1, len(closes)):
        up = highs[i] - highs[i - 1]
        down = lows[i - 1] - lows[i]
        plus_dm.append(up if up > down and up > 0 else 0.0)
        minus_dm.append(down if down > up and down > 0 else 0.0)
        trs.append(max(
            highs[i] - lows[i],
            abs(highs[i] - closes[i - 1]),
            abs(lows[i] - closes[i - 1]),
        ))
    atr_s = _wilder_series(trs, period)
    plus_s = _wilder_series(plus_dm, period)
    minus_s = _wilder_series(minus_dm, period)
    dx = []
    di_pairs = []
    for tr, pdm, mdm in zip(atr_s, plus_s, minus_s):
        if tr in (None, 0) or pdm is None or mdm is None:
            dx.append(None)
            di_pairs.append((None, None))
            continue
        pdi = 100 * pdm / tr
        mdi = 100 * mdm / tr
        denom = pdi + mdi
        dx.append((100 * abs(pdi - mdi) / denom) if denom else 0.0)
        di_pairs.append((pdi, mdi))
    usable_dx = [v for v in dx if v is not None]
    if len(usable_dx) < period:
        return None, None, None, None
    adx_series = _wilder_series(usable_dx, period)
    adx = next((v for v in reversed(adx_series) if v is not None), None)
    plus_di, minus_di = next(((p, m) for p, m in reversed(di_pairs) if p is not None and m is not None), (None, None))
    spread = (plus_di - minus_di) if plus_di is not None and minus_di is not None else None
    return adx, plus_di, minus_di, spread


def _shift_months(value_date, months):
    import calendar
    month_index = value_date.year * 12 + (value_date.month - 1) - months
    year = month_index // 12
    month = (month_index % 12) + 1
    day = min(value_date.day, calendar.monthrange(year, month)[1])
    return date(year, month, day)


def _rs_anchor_date(end_date, label):
    if label == "1w":
        return end_date - timedelta(days=7)
    if label == "2w":
        return end_date - timedelta(days=14)
    if label == "1m":
        return _shift_months(end_date, 1)
    if label == "2m":
        return _shift_months(end_date, 2)
    if label == "3m":
        return _shift_months(end_date, 3)
    if label == "6m":
        return _shift_months(end_date, 6)
    if label == "1y":
        return _shift_months(end_date, 12)
    return end_date


def _point_date(point):
    return point[0]


def _point_open(point):
    if len(point) >= 3:
        return float(point[1]) if point[1] not in (None, 0) else None
    return None


def _point_close(point):
    value = point[2] if len(point) >= 3 else point[1]
    return float(value) if value not in (None, 0) else None


def _close_on_or_before(points, target_date):
    for point in reversed(points):
        trade_date = _point_date(point)
        close = _point_close(point)
        if trade_date <= target_date and close is not None:
            return trade_date, close
    return None


def _close_on_or_after(points, target_date):
    for point in points:
        trade_date = _point_date(point)
        close = _point_close(point)
        if trade_date >= target_date and close is not None:
            return trade_date, close
    return None


def _period_start_date(end_date, label):
    """Start of the current TradingView-style candle for the requested period.

    The client compares the percent shown on TradingView after selecting 1W/1M/etc.
    That percentage is the current candle's open-to-current-close change, not a
    trailing close-to-close return.
    """
    if label == "1d":
        return end_date
    if label == "1w":
        return end_date - timedelta(days=end_date.weekday())
    if label == "2w":
        monday = end_date - timedelta(days=end_date.weekday())
        return monday - timedelta(days=7)
    if label == "3w":
        monday = end_date - timedelta(days=end_date.weekday())
        return monday - timedelta(days=14)
    if label == "1m":
        return end_date.replace(day=1)
    if label == "2m":
        month_index = end_date.month - 1
        start_month = (month_index // 2) * 2 + 1
        return end_date.replace(month=start_month, day=1)
    if label == "3m":
        start_month = ((end_date.month - 1) // 3) * 3 + 1
        return end_date.replace(month=start_month, day=1)
    if label == "6m":
        start_month = 1 if end_date.month <= 6 else 7
        return end_date.replace(month=start_month, day=1)
    if label == "1y":
        return end_date.replace(month=1, day=1)
    return end_date


def _open_on_or_after(points, target_date):
    for point in points:
        trade_date = _point_date(point)
        if trade_date < target_date:
            continue
        open_value = _point_open(point)
        if open_value is not None:
            return trade_date, open_value
        close_value = _point_close(point)
        if close_value is not None:
            return trade_date, close_value
    return None


def _period_returns_from_points(points, labels=("1d", "1w", "2w", "3w", "1m", "2m", "3m", "6m", "1y")):
    """Return TradingView-style current-candle returns for comparison tables."""
    if not points:
        return {}
    points = sorted(points, key=_point_date)
    end_date = _point_date(points[-1])
    end = _close_on_or_before(points, end_date)
    if not end:
        return {}
    result = {}
    for label in labels:
        start = _open_on_or_after(points, _period_start_date(end_date, label))
        if not start or start[1] in (None, 0):
            result[label] = None
            continue
        result[label] = round(((end[1] / start[1]) - 1) * 100, 2)
    return result


def _yf_period_returns(ticker_symbol):
    # Use the same resilient dual Yahoo path for the broad-market benchmarks so
    # the comparison table and RS engine do not disagree during provider hiccups.
    points = _benchmark_points_from_yfinance(ticker_symbol, period="2y")
    if not points:
        points = _benchmark_points_from_yahoo_chart(ticker_symbol, range_value="2y")
    compact = [(d, o, c) for d, o, _h, _l, c in points]
    return _period_returns_from_points(compact) if compact else {}


def _peer_group_period_returns(db, exchange, field_name, field_value, exclude_symbol=None, minimum_peers=5):
    """Average raw returns for real stored peers only.

    The selected stock is excluded. If the database does not contain enough
    peer histories, return no values so the UI shows N/A instead of repeating
    the selected stock's own return as an apparent sector/industry return.
    """
    if db is None or not field_value or field_name not in {"sector", "industry"}:
        return {}
    field = getattr(Company, field_name)
    peer_symbols = [
        row.symbol for row in db.query(Company.symbol)
        .filter(Company.exchange == exchange.upper(), field == field_value, Company.is_active == 1)
        .all()
    ]
    if exclude_symbol:
        peer_symbols = [s for s in peer_symbols if s != exclude_symbol.upper()]
    if len(peer_symbols) < minimum_peers:
        return {}

    cutoff = date.today() - timedelta(days=430)
    rows = (
        db.query(OHLCV)
        .filter(OHLCV.exchange == exchange.upper(), OHLCV.symbol.in_(peer_symbols), OHLCV.date >= cutoff)
        .order_by(OHLCV.symbol.asc(), OHLCV.date.asc())
        .all()
    )
    grouped = {}
    for row in _valid_trading_rows(rows, exchange):
        if row.close is None:
            continue
        grouped.setdefault(row.symbol, []).append(
            (row.date, float(row.open) if row.open is not None else float(row.close), float(row.close))
        )

    per_symbol = [
        _period_returns_from_points(points)
        for points in grouped.values()
        if len(points) >= 2
    ]
    if len(per_symbol) < minimum_peers:
        return {}

    result = {}
    for label in ("1d", "1w", "2w", "3w", "1m", "2m", "3m", "6m", "1y"):
        vals = [item.get(label) for item in per_symbol if item.get(label) is not None]
        result[label] = round(sum(vals) / len(vals), 2) if vals else None
    return result


def _nse_delivery_summary(symbol):
    """Best-effort NSE delivery percentage; never substitutes ordinary volume for delivery data."""
    try:
        session = requests.Session()
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/123 Safari/537.36",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://www.nseindia.com/",
        }
        session.get("https://www.nseindia.com/", headers=headers, timeout=8)
        end = date.today()
        start = end - timedelta(days=45)
        params = {
            "symbol": symbol.upper(),
            "series": '["EQ"]',
            "from": start.strftime("%d-%m-%Y"),
            "to": end.strftime("%d-%m-%Y"),
        }
        response = session.get("https://www.nseindia.com/api/historical/cm/equity", params=params, headers=headers, timeout=10)
        response.raise_for_status()
        payload = response.json()
        data = payload.get("data") or []
        parsed = []
        for item in data:
            pct = item.get("CH_DELIV_PER")
            qty = item.get("CH_DELIV_QTY")
            total = item.get("CH_TOT_TRADED_QTY")
            dt = item.get("CH_TIMESTAMP") or item.get("mTIMESTAMP")
            try:
                pct = float(pct) if pct not in (None, "", "-") else None
                qty = float(qty) if qty not in (None, "", "-") else None
                total = float(total) if total not in (None, "", "-") else None
            except Exception:
                continue
            parsed.append({"date": str(dt or ""), "percent": pct, "delivered": qty, "total": total})
        if not parsed:
            return {"available": False, "source": "NSE", "note": "NSE delivery data unavailable"}

        def aggregate(items):
            delivered = sum(x["delivered"] for x in items if x["delivered"] is not None)
            total = sum(x["total"] for x in items if x["total"] is not None)
            if delivered and total:
                pct = delivered / total * 100
            else:
                vals = [x["percent"] for x in items if x["percent"] is not None]
                pct = sum(vals) / len(vals) if vals else None
            return {
                "percent": round(pct, 2) if pct is not None else None,
                "delivered_quantity": round(delivered, 0) if delivered else None,
                "traded_quantity": round(total, 0) if total else None,
            }

        # NSE generally returns newest first.
        return {
            "available": True,
            "source": "NSE",
            "day": aggregate(data and parsed[:1] or []),
            "weekly": aggregate(parsed[:5]),
            "monthly": aggregate(parsed[:20]),
        }
    except Exception:
        # NSE may return an HTML/block page instead of JSON from cloud-hosted
        # servers. Do not surface parser/internal exception text to the user.
        return {
            "available": False,
            "source": "NSE",
            "note": "Delivery percentage is currently unavailable from the live NSE delivery-data endpoint.",
        }


def _weighted_relative_return_from_points(stock_points, benchmark_points, weights):
    """Client method using TradingView-style period candle returns.

    Period return = (current close / current period candle open - 1) * 100.
    Period Relative Return = Stock Return % - Benchmark Return %.
    """
    if not stock_points or not benchmark_points:
        return None, {}

    end_date = min(_point_date(stock_points[-1]), _point_date(benchmark_points[-1]))
    stock_end = _close_on_or_before(stock_points, end_date)
    bench_end = _close_on_or_before(benchmark_points, end_date)
    if not stock_end or not bench_end:
        return None, {}

    metrics = {}
    weighted_sum = 0.0
    available_weight = 0.0
    for label in ("1w", "2w", "1m", "2m", "3m", "6m", "1y"):
        weight = max(0.0, float(weights.get(label, 0) or 0))
        period_start = _period_start_date(end_date, label)
        stock_old = _open_on_or_after(stock_points, period_start)
        bench_old = _open_on_or_after(benchmark_points, period_start)
        if not stock_old or not bench_old or stock_old[1] == 0 or bench_old[1] == 0:
            continue

        stock_return = ((stock_end[1] / stock_old[1]) - 1) * 100
        benchmark_return = ((bench_end[1] / bench_old[1]) - 1) * 100
        relative_return = stock_return - benchmark_return
        metrics[label] = {
            "weight_percent": weight,
            "stock_return_percent": round(stock_return, 2),
            "benchmark_return_percent": round(benchmark_return, 2),
            "relative_return_percent": round(relative_return, 2),
            "start_date": stock_old[0].isoformat(),
            "benchmark_start_date": bench_old[0].isoformat(),
            "period_start_date": period_start.isoformat(),
            "end_date": stock_end[0].isoformat(),
            "return_method": "period_open_to_current_close",
        }
        if weight > 0:
            weighted_sum += relative_return * weight
            available_weight += weight

    if available_weight <= 0:
        return None, metrics
    return weighted_sum / available_weight, metrics

RS_PERCENTILE_TARGETS = {
    "US": 5000,
    "INDIA": 5000,
}


def _rs_market_group(exchange: str) -> str:
    return "US" if exchange.upper() == "US" else "INDIA"


def _rs_market_exchanges(exchange: str):
    return ("US",) if exchange.upper() == "US" else ("NSE", "BSE")


def _rs_percentile_total(exchange: str) -> int:
    return RS_PERCENTILE_TARGETS[_rs_market_group(exchange)]

def _percentile_rank(values, target_value, total_count=None):
    """Client percentile: (lower + 0.5 * equal) * 100 / total.

    Stock RS uses the client-defined fixed 5,000-stock denominator for both
    US and Indian (NSE/BSE) market scoring. Other
    percentile uses (for example sector-to-sector comparisons) can leave
    ``total_count`` unset and use the actual sample size.
    """
    values = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    if target_value is None or not values:
        return None
    tolerance = 1e-9
    lower = sum(1 for value in values if value < target_value - tolerance)
    equal = sum(1 for value in values if abs(value - target_value) <= tolerance)
    denominator = int(total_count) if total_count is not None else len(values)
    if denominator <= 0:
        return None
    percentile = ((lower + 0.5 * equal) * 100.0) / denominator
    return round(max(0.0, min(100.0, percentile)), 2)


def _rs_universe_metrics(db: Session, exchange: str, benchmark_points):
    """Return period relative returns for the selected market universe.

    US scores use US listings only. Indian scores use stored NSE + BSE listings
    together, matching the client's requirement for one Indian RS universe.
    Exchange is included in the internal key so equal ticker strings on two
    exchanges cannot overwrite one another.
    """
    if db is None:
        return {}, {}

    market_exchanges = _rs_market_exchanges(exchange)
    cutoff = date.today() - timedelta(days=430)
    rows = (
        db.query(OHLCV)
        .join(
            Company,
            (Company.symbol == OHLCV.symbol) & (Company.exchange == OHLCV.exchange),
        )
        .filter(
            OHLCV.exchange.in_(market_exchanges),
            OHLCV.date >= cutoff,
            Company.is_active == 1,
        )
        .order_by(OHLCV.exchange.asc(), OHLCV.symbol.asc(), OHLCV.date.asc())
        .all()
    )
    grouped = {}
    for row in rows:
        if row.date is None or row.date.weekday() >= 5 or row.close is None:
            continue
        key = f"{row.exchange.upper()}:{row.symbol.upper()}"
        grouped.setdefault(key, []).append(
            (row.date, float(row.open) if row.open is not None else float(row.close), float(row.close))
        )

    # The relative-return metrics themselves do not depend on scoring weights.
    metric_weights = {key: 1.0 for key in ("1w", "2w", "1m", "2m", "3m", "6m", "1y")}
    symbol_metrics = {}
    for key, points in grouped.items():
        _, metrics = _weighted_relative_return_from_points(points, benchmark_points, metric_weights)
        if metrics:
            symbol_metrics[key] = metrics

    sector_by_symbol = {
        f"{row.exchange.upper()}:{row.symbol.upper()}": row.sector
        for row in db.query(Company)
        .filter(Company.exchange.in_(market_exchanges), Company.is_active == 1)
        .all()
        if row.sector
    }
    return symbol_metrics, sector_by_symbol


def _weighted_rs_against_benchmark(daily_rows, exchange: str, period_weights=None, db: Session = None):
    """Client RS method: period relative returns -> period percentiles -> weighted RS score."""
    spec = _benchmark_spec(exchange)
    benchmark_symbol = spec[0] if spec else None
    benchmark_name = spec[1] if spec else "Benchmark"

    # Latest client handwritten RS reference:
    # 1W*0.30 + 1M*0.25 + 3M*0.20 + 6M*0.15 + 12M*0.10
    # 2W/2M and Sector RS remain optional custom components with zero default weight.
    defaults = {"1w": 30.0, "2w": 0.0, "1m": 25.0, "2m": 0.0, "3m": 20.0, "6m": 15.0, "1y": 10.0, "sector": 0.0}
    weights = defaults.copy()
    if period_weights:
        for key, value in period_weights.items():
            if key in weights:
                try:
                    weights[key] = max(0.0, float(value))
                except Exception:
                    pass

    try:
        benchmark_points, _benchmark_symbol, _benchmark_name, _benchmark_method = _benchmark_close_points(exchange, db=db)
        if not benchmark_points:
            return None, None, {}, benchmark_name, []
        stock_points = [
            (r.date, float(r.open) if r.open is not None else float(r.close), float(r.close))
            for r in daily_rows
            if r.date is not None and r.close is not None and math.isfinite(float(r.close))
        ]
        stock_points.sort(key=lambda item: item[0])
        benchmark_points.sort(key=lambda item: item[0])

        benchmark_by_date = {d: c for d, _o, c in benchmark_points}
        aligned = [(d, c, benchmark_by_date.get(d)) for d, _o, c in stock_points if benchmark_by_date.get(d) is not None]
        rs_chart = []
        base_ratio = None
        for trade_date, stock_close, bench_close in aligned:
            if not stock_close or not bench_close:
                continue
            ratio = stock_close / bench_close
            if base_ratio is None:
                base_ratio = ratio
            if base_ratio:
                rs_chart.append({"date": trade_date.isoformat(), "rs": round((ratio / base_ratio) * 100, 4)})

        metric_weights = {key: 1.0 for key in ("1w", "2w", "1m", "2m", "3m", "6m", "1y")}
        _, metrics = _weighted_relative_return_from_points(stock_points, benchmark_points, metric_weights)
        if not metrics:
            return None, None, metrics, benchmark_name, rs_chart

        target_size = _rs_percentile_total(exchange)
        universe_metrics, sector_by_symbol = _rs_universe_metrics(db, exchange, benchmark_points)
        for label in ("1w", "2w", "1m", "2m", "3m", "6m", "1y"):
            target_rr = (metrics.get(label) or {}).get("relative_return_percent")
            universe_values = [
                m[label]["relative_return_percent"]
                for m in universe_metrics.values()
                if label in m and m[label].get("relative_return_percent") is not None
            ]
            pct = _percentile_rank(universe_values, target_rr, target_size)
            if label in metrics:
                metrics[label]["percentile"] = pct
                metrics[label]["universe_size"] = target_size
                metrics[label]["scored_stocks_available"] = len(universe_values)
                metrics[label]["score_weight_percent"] = weights.get(label, 0.0)

        # First calculate each stock's period-percentile composite (without sector).
        period_labels = ("1w", "2w", "1m", "2m", "3m", "6m", "1y")
        period_universe_values = {
            label: [
                m[label]["relative_return_percent"]
                for m in universe_metrics.values()
                if label in m and m[label].get("relative_return_percent") is not None
            ]
            for label in period_labels
        }

        stock_period_scores = {}
        for symbol, sym_metrics in universe_metrics.items():
            score_sum = 0.0
            score_weight = 0.0
            for label in period_labels:
                weight = weights.get(label, 0.0)
                if weight <= 0 or label not in sym_metrics:
                    continue
                rr = sym_metrics[label].get("relative_return_percent")
                pct = _percentile_rank(period_universe_values[label], rr, target_size)
                if pct is None:
                    continue
                score_sum += pct * weight
                score_weight += weight
            if score_weight > 0:
                stock_period_scores[symbol] = score_sum / score_weight

        # Sector RS Score = percentile rank of the target sector's average member RS
        # versus the average RS of all other represented sectors.
        sector_groups = {}
        for symbol, score in stock_period_scores.items():
            sector = sector_by_symbol.get(symbol)
            if sector:
                sector_groups.setdefault(sector, []).append(score)
        sector_scores = {sector: sum(vals) / len(vals) for sector, vals in sector_groups.items() if vals}

        target_symbol = daily_rows[-1].symbol if daily_rows else None
        target_key = f"{exchange.upper()}:{target_symbol.upper()}" if target_symbol else None
        target_sector = sector_by_symbol.get(target_key) if target_key else None
        target_sector_raw = sector_scores.get(target_sector) if target_sector else None
        sector_percentile = _percentile_rank(list(sector_scores.values()), target_sector_raw)
        metrics["sector"] = {
            "sector": target_sector,
            "score": round(target_sector_raw, 2) if target_sector_raw is not None else None,
            "percentile": sector_percentile,
            "universe_size": len(sector_scores),
            "score_weight_percent": weights.get("sector", 0.0),
        }

        weighted_score = 0.0
        available_weight = 0.0
        for label in period_labels:
            weight = weights.get(label, 0.0)
            pct = (metrics.get(label) or {}).get("percentile")
            if weight > 0 and pct is not None:
                weighted_score += pct * weight
                available_weight += weight
        # Sector RS is an optional scoring component. Its default weight is 0,
        # so the standard period-only formula is unchanged unless the user enables it.
        sector_weight = weights.get("sector", 0.0)
        if sector_weight > 0 and sector_percentile is not None:
            weighted_score += sector_percentile * sector_weight
            available_weight += sector_weight

        if available_weight <= 0:
            return None, None, metrics, benchmark_name, rs_chart

        rating = round(weighted_score / available_weight, 2)

        # IMPORTANT: raw/composite relative return is intentionally independent
        # of the editable score weights.  The client specifically requested that
        # changing score weightage must change only Final RS Score.  Keep this
        # compatibility field on the fixed reference mix, while the final score
        # above uses the editable percentile weights.
        fixed_relative_weights = {
            "1w": 30.0, "2w": 0.0, "1m": 25.0, "2m": 0.0,
            "3m": 20.0, "6m": 15.0, "1y": 10.0,
        }
        weighted_relative, _ = _weighted_relative_return_from_points(
            stock_points, benchmark_points, fixed_relative_weights
        )
        metrics["_universe_size"] = target_size
        required_default_periods = ("1w", "1m", "3m", "6m", "1y")
        metrics["_scored_stocks_available"] = sum(
            1
            for symbol_metrics in universe_metrics.values()
            if all(
                label in symbol_metrics
                and symbol_metrics[label].get("relative_return_percent") is not None
                for label in required_default_periods
            )
        )
        metrics["_score_weight_total"] = available_weight
        metrics["_relative_return_weight_independent"] = True
        metrics["_fixed_relative_return_reference_weights"] = fixed_relative_weights
        return rating, weighted_relative, metrics, benchmark_name, rs_chart
    except Exception:
        return None, None, {}, benchmark_name, []


def _normalize_score_weights(weights=None):
    defaults = dict(CLIENT_COMPOSITE_WEIGHTS)
    if not weights:
        return defaults

    merged = {**defaults, **{k: max(0.0, float(v)) for k, v in weights.items() if k in defaults}}
    total = sum(merged.values())
    if total <= 0:
        return defaults
    return {k: (v / total) * 100.0 for k, v in merged.items()}


def _score_symbol(db: Session, symbol: str, exchange: str, weights=None, include_components=False, subweights=None, rs_period_weights=None):
    rows = (
        db.query(OHLCV)
        .filter(OHLCV.symbol == symbol, OHLCV.exchange == exchange)
        .order_by(OHLCV.date.asc())
        .all()
    )
    rows = _valid_trading_rows(rows, exchange)
    fundamental = (
        db.query(Fundamental)
        .filter(Fundamental.symbol == symbol, Fundamental.exchange == exchange)
        .first()
    )
    ownership = (
        db.query(Ownership)
        .filter(Ownership.symbol == symbol, Ownership.exchange == exchange)
        .first()
    )

    components = {
        "technical": None,
        "fundamental": None,
        "relative_strength": None,
        "ownership": None,
        # Sector growth score is a separate Milestone-2 component. It remains
        # unavailable until the peer fundamental-growth universe has enough
        # real observations; it is never replaced with a price-RS proxy.
        "sector": None,
    }

    closes = [float(row.close) for row in rows if row.close is not None]
    highs = [float(row.high) for row in rows if row.high is not None]
    lows = [float(row.low) for row in rows if row.low is not None]
    volumes = [float(row.volume or 0) for row in rows]

    if closes:
        latest = closes[-1]
        configured_subweights = subweights or {}
        technical_weights = configured_subweights.get("technical", {
            "ema20": 20, "ema50": 20, "ema150": 20, "ema200": 20, "rsi": 20,
        })
        technical_metrics = {}
        for period, key in [(20, "ema20"), (50, "ema50"), (150, "ema150"), (200, "ema200")]:
            ema = _ema(closes, period)
            if ema is not None:
                technical_metrics[key] = 100.0 if latest > ema else 0.0

        rsi = _rsi(closes, 14)
        if rsi is not None:
            technical_metrics["rsi"] = 100.0 if 50 <= rsi <= 70 else 50.0 if (40 <= rsi < 50 or 70 < rsi <= 80) else 0.0

        tw_sum = sum(max(0.0, float(technical_weights.get(k, 0))) for k in technical_metrics)
        if tw_sum > 0:
            components["technical"] = round(sum(technical_metrics[k] * max(0.0, float(technical_weights.get(k, 0))) for k in technical_metrics) / tw_sum, 2)

        # Keep dashboard RS aligned with the customizable Technical Summary model.
        rs_component, _, _, _, _ = _weighted_rs_against_benchmark(rows, exchange, rs_period_weights, db=db)
        if rs_component is not None:
            components["relative_strength"] = rs_component


    if fundamental:
        fundamental_weights = (subweights or {}).get("fundamental", {
            "eps": 20, "net_income": 20, "profit_margin": 20, "roe": 20, "roa": 20,
        })
        raw_checks = {
            "eps": (fundamental.trailing_eps, lambda x: x > 0),
            "net_income": (fundamental.net_income, lambda x: x > 0),
            "profit_margin": (fundamental.profit_margin, lambda x: x > 0),
            "roe": (fundamental.return_on_equity, lambda x: x >= 0.15),
            "roa": (fundamental.return_on_assets, lambda x: x >= 0.05),
        }
        fundamental_metrics = {}
        for key, (value, check) in raw_checks.items():
            if value is None:
                continue
            numeric = float(value)
            fundamental_metrics[key] = 100.0 if check(numeric) else (50.0 if numeric > 0 else 0.0)
        fw_sum = sum(max(0.0, float(fundamental_weights.get(k, 0))) for k in fundamental_metrics)
        if fw_sum > 0:
            components["fundamental"] = round(sum(fundamental_metrics[k] * max(0.0, float(fundamental_weights.get(k, 0))) for k in fundamental_metrics) / fw_sum, 2)

    if ownership:
        ownership_weights = (subweights or {}).get("ownership", {"institution": 70, "insider": 30})
        ownership_metrics = {}
        if ownership.institution_percent is not None:
            pct = float(ownership.institution_percent)
            if pct <= 1:
                pct *= 100
            ownership_metrics["institution"] = max(0, min(100, pct))
        if ownership.insider_percent is not None:
            pct = float(ownership.insider_percent)
            if pct <= 1:
                pct *= 100
            ownership_metrics["insider"] = max(0, min(100, pct * 5))
        ow_sum = sum(max(0.0, float(ownership_weights.get(k, 0))) for k in ownership_metrics)
        if ow_sum > 0:
            components["ownership"] = round(sum(ownership_metrics[k] * max(0.0, float(ownership_weights.get(k, 0))) for k in ownership_metrics) / ow_sum, 2)

    normalized_weights = _normalize_score_weights(weights)
    weighted_points = 0.0
    available_weight = 0.0
    for key, weight in normalized_weights.items():
        value = components.get(key)
        if value is None:
            continue
        weighted_points += value * weight
        available_weight += weight

    if available_weight <= 0:
        return (None, 0, components, normalized_weights) if include_components else (None, 0)

    score = round(weighted_points / available_weight)
    coverage = round(available_weight)
    result = (max(0, min(100, score)), max(0, min(100, coverage)))
    if include_components:
        return result[0], result[1], components, normalized_weights
    return result


def _rank_within(db: Session, company: Company, field: str, minimum_peers: int = 5):
    value = getattr(company, field)
    if not value:
        return {
            "available": False,
            "rank": None,
            "total": 0,
            "group": None,
            "note": "Classification data is unavailable for this stock."
        }

    peers = (
        db.query(Company)
        .filter(
            Company.exchange == company.exchange,
            getattr(Company, field) == value,
            Company.is_active == 1
        )
        .limit(100)
        .all()
    )

    scored = []
    for peer in peers:
        score, _ = _score_symbol(db, peer.symbol, peer.exchange)
        if score is not None:
            scored.append((peer.symbol, score))

    if len(scored) < minimum_peers:
        return {
            "available": False,
            "rank": None,
            "total": len(scored),
            "group": value,
            "note": f"Insufficient peer data ({len(scored)}/{minimum_peers} minimum)."
        }

    scored.sort(key=lambda item: item[1], reverse=True)
    for index, (peer_symbol, _) in enumerate(scored, start=1):
        if peer_symbol == company.symbol:
            return {
                "available": True,
                "rank": index,
                "total": len(scored),
                "group": value,
                "note": None
            }

    return {
        "available": False,
        "rank": None,
        "total": len(scored),
        "group": value,
        "note": "The selected stock does not yet have enough comparable scored peer data."
    }


def _stored_rs_rating(db: Session, symbol: str, exchange: str, minimum_universe: int = 20):
    cutoff = date.today() - timedelta(days=220)
    rows = (
        db.query(OHLCV)
        .filter(OHLCV.exchange == exchange, OHLCV.date >= cutoff)
        .order_by(OHLCV.symbol.asc(), OHLCV.date.asc())
        .limit(50000)
        .all()
    )
    rows = _valid_trading_rows(rows, exchange)

    grouped = {}
    for row in rows:
        if row.close is None:
            continue
        grouped.setdefault(row.symbol, []).append(float(row.close))

    returns = {}
    for peer_symbol, closes in grouped.items():
        if len(closes) >= 40 and closes[0] != 0:
            returns[peer_symbol] = (closes[-1] / closes[0]) - 1

    if symbol not in returns or len(returns) < minimum_universe:
        return None, len(returns)

    target = returns[symbol]
    below_or_equal = sum(1 for value in returns.values() if value <= target)
    percentile = round((below_or_equal / len(returns)) * 99)
    return max(1, min(99, percentile)), len(returns)


def _cached_symbol_summary(db: Session, symbol: str, exchange: str):
    rows = (
        db.query(OHLCV)
        .filter(
            OHLCV.symbol == symbol.upper(),
            OHLCV.exchange == exchange.upper(),
        )
        .order_by(OHLCV.date.desc())
        .limit(5000)
        .all()
    )
    valid = _valid_trading_rows(rows, exchange)
    if not valid:
        return None
    latest = valid[0]
    return {
        "cached_records": len(valid),
        "latest_date": latest.date.isoformat() if latest.date else None,
        "latest_close": float(latest.close) if latest.close is not None else None,
    }


@router.post("/refresh/{symbol}")
def refresh_symbol(
    symbol: str,
    exchange: str = "US",
    db: Session = Depends(get_db)
):
    symbol = symbol.upper().strip()
    exchange = exchange.upper().strip()

    def cached_response(reason: str):
        cached = _cached_symbol_summary(db, symbol, exchange)
        if not cached:
            return None
        return {
            "status": "cached",
            "provider_refresh_ok": False,
            "symbol": symbol,
            "exchange": exchange,
            "records_received": 0,
            "added": 0,
            "updated": 0,
            "removed_invalid_dates": 0,
            "warning": reason,
            **cached,
        }

    try:
        # Manual refresh used to request the complete history from 2000 on every
        # click. Repeated clicks can trigger provider rate limits and make a
        # healthy deployment look stale. Fetch only a small overlap after the
        # newest stored bar; use the full history only for a first-time symbol.
        latest_stored = (
            db.query(func.max(OHLCV.date))
            .filter(OHLCV.symbol == symbol, OHLCV.exchange == exchange)
            .scalar()
        )
        start_date = "2000-01-01"
        if latest_stored:
            start_date = (latest_stored - timedelta(days=10)).isoformat()

        if exchange == "BSE":
            try:
                rows = BSEProvider().get_ohlcv(symbol)
            except Exception as primary_exc:
                # BSE has a second configured provider path through Yahoo.
                try:
                    rows = YahooProvider().get_ohlcv(
                        symbol=symbol,
                        exchange=exchange,
                        start_date=start_date,
                    )
                except Exception:
                    cached = cached_response(f"Live BSE refresh unavailable: {primary_exc}")
                    if cached:
                        return cached
                    raise
        else:
            rows = YahooProvider().get_ohlcv(
                symbol=symbol,
                exchange=exchange,
                start_date=start_date,
            )

        if not rows:
            cached = cached_response("The live provider returned no new rows; verified stored market data is being shown.")
            if cached:
                return cached
            raise HTTPException(status_code=404, detail="No market data returned and no stored market data is available")

        if _free_tier_mode():
            # The 500 MB Railway volume is too small for full-universe OHLCV.
            # Return live provider success without writing rebuildable history.
            metadata = {}
            try:
                metadata = YahooProvider().get_fundamentals(symbol, exchange) or {}
            except Exception:
                metadata = {}
            return {
                "status": "live_only",
                "provider_refresh_ok": True,
                "symbol": symbol,
                "exchange": exchange,
                "records_received": len(rows),
                "added": 0,
                "updated": 0,
                "removed_invalid_dates": 0,
                "company_name": metadata.get("name"),
                "isin": metadata.get("isin"),
                "warning": "FREE_TIER_MODE: live data returned without storing the rebuildable OHLCV cache.",
            }

        result = sync_ohlcv(
            db=db,
            symbol=symbol,
            exchange=exchange,
            rows=rows
        )

        # Make a freshly loaded ticker immediately available to the universe
        # screener even if the external company-master job is still pending.
        company = (
            db.query(Company)
            .filter(Company.symbol == symbol, Company.exchange == exchange)
            .first()
        )
        if company is None:
            db.add(Company(symbol=symbol, exchange=exchange, name=symbol, is_active=1))
            db.commit()

        # Refresh identity/fundamentals separately. A metadata-provider failure
        # must never turn a successful OHLCV refresh into a failed refresh.
        try:
            if exchange == "NSE":
                repair_company_identity(db, symbol, exchange)
            metadata = YahooProvider().get_fundamentals(symbol, exchange)
            if isinstance(metadata, dict) and metadata:
                sync_fundamental_data(db, symbol, exchange, metadata)
            if exchange == "NSE":
                # NSE official identity wins over any third-party display name.
                repair_company_identity(db, symbol, exchange)
        except Exception:
            db.rollback()

        cached = _cached_symbol_summary(db, symbol, exchange) or {}
        company = (
            db.query(Company)
            .filter(Company.symbol == symbol, Company.exchange == exchange)
            .first()
        )
        return {
            "status": "success",
            "provider_refresh_ok": True,
            "symbol": symbol,
            "exchange": exchange,
            "records_received": len(rows),
            "company_name": company.name if company else None,
            "isin": company.isin if company else None,
            **result,
            **cached,
        }

    except HTTPException:
        raise

    except Exception as exc:
        cached = cached_response(f"Live provider refresh failed temporarily: {exc}")
        if cached:
            return cached
        raise HTTPException(
            status_code=503,
            detail=f"Market data refresh failed and no verified stored data is available: {str(exc)}"
        )

@router.get("/history/{symbol}")
def get_history(
    symbol: str,
    exchange: str = "US",
    limit: int = 260,
    db: Session = Depends(get_db)
):
    rows = _market_rows_with_live_fallback(
        db, symbol=symbol, exchange=exchange, min_rows=1, years=5
    )
    rows = list(reversed(rows[-limit:]))

    return [
        {
            "date": row.date,
            "open": row.open,
            "high": row.high,
            "low": row.low,
            "close": row.close,
            "volume": row.volume
        }
        for row in rows
    ]

@router.get("/dashboard/{symbol}")
def get_dashboard_summary(
    symbol: str,
    exchange: str = "US",
    technical_weight: float = 25,
    fundamental_weight: float = 30,
    relative_strength_weight: float = 25,
    ownership_weight: float = 15,
    sector_weight: float = 5,
    technical_ema20_weight: float = 20,
    technical_ema50_weight: float = 20,
    technical_ema150_weight: float = 20,
    technical_ema200_weight: float = 20,
    technical_rsi_weight: float = 20,
    fundamental_eps_weight: float = 20,
    fundamental_net_income_weight: float = 20,
    fundamental_profit_margin_weight: float = 20,
    fundamental_roe_weight: float = 20,
    fundamental_roa_weight: float = 20,
    ownership_institution_weight: float = 70,
    ownership_insider_weight: float = 30,
    rs_1w_weight: float = 30,
    rs_2w_weight: float = 0,
    rs_1m_weight: float = 25,
    rs_2m_weight: float = 0,
    rs_3m_weight: float = 20,
    rs_6m_weight: float = 15,
    rs_1y_weight: float = 10,
    rs_sector_weight: float = 0,
    db: Session = Depends(get_db)
):
    symbol = symbol.upper()
    exchange = exchange.upper()

    # Repair exact NSE identity before reading the dashboard record. This fixes
    # stale database metadata without touching OHLC/fundamental history.
    if exchange == "NSE":
        try:
            repair_company_identity(db, symbol, exchange)
        except Exception:
            pass

    company = (
        db.query(Company)
        .filter(Company.symbol == symbol, Company.exchange == exchange)
        .first()
    )

    requested_weights = {
        "technical": technical_weight,
        "fundamental": fundamental_weight,
        "relative_strength": relative_strength_weight,
        "ownership": ownership_weight,
        "sector": sector_weight,
    }
    ranking_subweights = {
        "technical": {"ema20": technical_ema20_weight, "ema50": technical_ema50_weight, "ema150": technical_ema150_weight, "ema200": technical_ema200_weight, "rsi": technical_rsi_weight},
        "fundamental": {"eps": fundamental_eps_weight, "net_income": fundamental_net_income_weight, "profit_margin": fundamental_profit_margin_weight, "roe": fundamental_roe_weight, "roa": fundamental_roa_weight},
        "ownership": {"institution": ownership_institution_weight, "insider": ownership_insider_weight},
    }
    rs_period_weights = {"1w": rs_1w_weight, "2w": rs_2w_weight, "1m": rs_1m_weight, "2m": rs_2m_weight, "3m": rs_3m_weight, "6m": rs_6m_weight, "1y": rs_1y_weight, "sector": rs_sector_weight}
    score, coverage, components, normalized_weights = _score_symbol(
        db, symbol, exchange, weights=requested_weights, include_components=True,
        subweights=ranking_subweights, rs_period_weights=rs_period_weights
    )
    if score is None:
        raise HTTPException(status_code=404, detail="Not enough data to calculate dashboard score")

    # Reuse the compact Top-200 enrichment cache for the selected stock's real
    # sector-growth component.  This closes the old gap where AAPL could have
    # Technical/Fundamental/Ownership/RS but still show Sector N/A even after
    # Top-200 had already fetched real sector metadata/history.
    sector_component, sector_peer_count, sector_name = _selected_sector_component(db, company)
    if sector_component is not None:
        components["sector"] = sector_component

        weighted_points = 0.0
        available_weight = 0.0
        for key, weight in normalized_weights.items():
            value = components.get(key)
            if value is None:
                continue
            weighted_points += float(value) * float(weight)
            available_weight += float(weight)
        if available_weight > 0:
            score = max(0, min(100, round(weighted_points / available_weight)))
            coverage = max(0, min(100, round(available_weight)))

    # Refresh the ORM object after a snapshot/live classification repair.
    try:
        db.refresh(company)
    except Exception:
        pass

    # Do not present a seemingly complete Indian-market ranking when weighted
    # fundamental/ownership categories are unavailable. This directly exposes
    # the data-coverage limitation instead of silently re-normalizing it away.
    missing_required = []
    if exchange in {"NSE", "BSE"}:
        if normalized_weights.get("fundamental", 0) > 0 and components.get("fundamental") is None:
            missing_required.append("fundamental")
        if normalized_weights.get("ownership", 0) > 0 and components.get("ownership") is None:
            missing_required.append("ownership")

    if missing_required:
        displayed_score = None
        signal = "Insufficient Data"
    else:
        displayed_score = score
        if score >= 70:
            signal = "Buy"
        elif score >= 45:
            signal = "Watch"
        else:
            signal = "Sell"

    sector_rank = _rank_within(db, company, "sector") if company and not missing_required else None
    industry_rank = _rank_within(db, company, "industry") if company and not missing_required else None

    # Client NPM rule #5 compares the current NPM with the median NPM of the
    # selected stock's industry.  Use only verified stored provider margins.
    industry_median_npm = None
    industry_npm_peer_count = 0
    if company and company.industry:
        peer_rows = (
            db.query(Fundamental.profit_margin)
            .join(
                Company,
                (Company.symbol == Fundamental.symbol)
                & (Company.exchange == Fundamental.exchange),
            )
            .filter(
                Company.exchange == exchange,
                Company.industry == company.industry,
                Fundamental.profit_margin.isnot(None),
            )
            .all()
        )
        peer_npms = []
        for (raw_margin,) in peer_rows:
            try:
                value = float(raw_margin)
                if not math.isfinite(value):
                    continue
                # Yahoo snapshot profit margin is normally a ratio (0.25 =
                # 25%). Keep already-percent values unchanged.
                if abs(value) <= 1:
                    value *= 100.0
                peer_npms.append(value)
            except (TypeError, ValueError):
                continue
        if peer_npms:
            industry_median_npm = float(median(peer_npms))
            industry_npm_peer_count = len(peer_npms)

    return _json_safe({
        "symbol": symbol,
        "name": company.name if company else None,
        "isin": company.isin if company else None,
        "exchange": exchange,
        "score": displayed_score,
        "signal": signal,
        "missing_required_score_categories": missing_required,
        "score_coverage_percent": coverage,
        "score_components": components,
        "score_weights": {k: round(v, 2) for k, v in normalized_weights.items()},
        "ranking_subweights": ranking_subweights,
        "rs_period_weights": rs_period_weights,
        "sector": company.sector if company else None,
        "industry": company.industry if company else None,
        "industry_median_npm": industry_median_npm,
        "industry_npm_peer_count": industry_npm_peer_count,
        "sector_rank": sector_rank,
        "industry_rank": industry_rank,
        "sector_score_peer_count": sector_peer_count,
        "sector_score_status": "Real compact peer-history ranking" if components.get("sector") is not None else "Insufficient real peer history",
        "method_note": "Milestone-2 composite follows the client note: Fundamental 30% + Technical 25% + RS 25% + Ownership 15% + Sector 5%. The selected-stock Sector component reuses real compact Top-200 EPS/PAT/Sales peer history and requires at least 5 real peers; it is never substituted with price RS. For NSE/BSE, a score is withheld when a positively weighted fundamental or ownership category is unavailable, rather than producing a misleading partial ranking."
    })


@router.get("/ownership-details/{symbol}")
def get_ownership_details(symbol: str, exchange: str = "US"):
    try:
        provider = YahooProvider()
        return provider.get_ownership_details(symbol.upper(), exchange.upper())
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ownership details failed: {str(e)}")


@router.get("/sec-edgar/{symbol}")
def get_sec_edgar_data(
    symbol: str,
    exchange: str = "US",
    filings_limit: int = Query(12, ge=1, le=50),
):
    """Official SEC EDGAR filings + XBRL fundamental history for US stocks."""
    if exchange.upper() != "US":
        raise HTTPException(
            status_code=400,
            detail="SEC EDGAR integration applies to US-listed companies only",
        )
    try:
        data = SECFundamentalsProvider().get_snapshot(symbol.upper(), filings_limit)
        if not data.get("cik") and data.get("status") == "not_found":
            raise HTTPException(status_code=404, detail="Ticker was not found in the SEC EDGAR company list")
        # Temporary SEC/ticker-map outages return a structured 200 payload so
        # the dashboard can explain the provider problem without treating the
        # rest of the stock data as failed.
        return _json_safe(data)
    except HTTPException:
        raise
    except RuntimeError as exc:
        # Configuration/ticker-map failures are explicit, while transient SEC
        # sub-resource failures are handled inside get_snapshot as partial data.
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception:
        raise HTTPException(status_code=503, detail="SEC EDGAR is temporarily unavailable. Please retry shortly.")


@router.post("/refresh-configured")
def refresh_configured_symbols_now():
    """Run the configured automatic-refresh list immediately for demonstration/testing."""
    return _json_safe(refresh_configured_market_data())


@router.get("/ranking-spec")
def get_client_ranking_spec():
    """Machine-readable Milestone-2 formulas transcribed from the client's notes."""
    return {
        "overall_composite": {
            "formula": "Fundamental*0.30 + Technical*0.25 + RS*0.25 + Ownership*0.15 + Sector*0.05",
            "weights_percent": CLIENT_COMPOSITE_WEIGHTS,
        },
        "sector_ranking": {
            "formula": "EPS_RS*0.30 + PAT_RS*0.25 + Sales_RS*0.20 + GrowthAcceleration_RS*0.15 + GrowthBreadth*0.05 + AccelerationBreadth*0.05",
            "weights_percent": CLIENT_SECTOR_WEIGHTS,
            "aggregation": "Use median stock growth for sector growth metrics rather than average.",
            "growth_breadth": "(Sales breadth + PAT breadth + EPS breadth) / 3",
            "acceleration_breadth": "EPS acceleration breadth*0.35 + PAT acceleration breadth*0.35 + Sales acceleration breadth*0.30",
        },
        "filter_layout": {
            "columns": ["Filter name", "Compare", "Value / target", "Weight", "Filter score", "Enable / disable"],
            "technical": CLIENT_TECHNICAL_FILTER_CONFIG,
            "fundamental": CLIENT_FUNDAMENTAL_FILTER_CONFIG,
            "fundamental_groups": ["EPS", "PAT", "Sales", "NPM", "CFO", "Other"],
        },
        "data_integrity": {
            "missing_values": "N/A; never fabricate a value to complete a score.",
            "ambiguous_handwritten_weights": "Remain editable/unconfirmed until the client confirms them.",
        },
    }


EXCEL_MIN_HISTORY_YEARS = 4
EXCEL_FETCH_HISTORY_YEARS = 5
EXCEL_DEFAULT_HISTORY_ROWS = 1500


def _excel_history_status(db: Session, symbol: str, exchange: str):
    symbol = symbol.upper()
    exchange = exchange.upper()
    earliest, latest, count = (
        db.query(func.min(OHLCV.date), func.max(OHLCV.date), func.count(OHLCV.id))
        .filter(OHLCV.symbol == symbol, OHLCV.exchange == exchange)
        .one()
    )
    required_start = date.today() - timedelta(days=366 * EXCEL_MIN_HISTORY_YEARS)
    return {
        "earliest_date": earliest.isoformat() if earliest else None,
        "latest_date": latest.isoformat() if latest else None,
        "stored_rows": int(count or 0),
        "required_years": EXCEL_MIN_HISTORY_YEARS,
        "requested_years": EXCEL_FETCH_HISTORY_YEARS,
        "requirement_met": bool(earliest and earliest <= required_start),
    }


def _ensure_excel_history(db: Session, symbol: str, exchange: str):
    """Best-effort backfill so Excel receives at least four years of real daily data.

    The client creates longer-period indicators in Excel.  We request five
    calendar years to leave a safety margin around holidays and missing trading
    days.  Provider failures never fabricate data: the endpoint still returns
    the verified stored history together with an explicit readiness flag.
    """
    symbol = symbol.upper().strip()
    exchange = exchange.upper().strip()
    status = _excel_history_status(db, symbol, exchange)
    if _free_tier_mode():
        # Never refill the 500 MB Railway volume with multi-year Excel OHLCV.
        # The Master Excel Python bridge now fetches up to 20 years directly
        # from the provider and uses this endpoint only for compact snapshots.
        return {
            **status,
            "backfill_attempted": False,
            "warning": "Free-tier mode: long Excel/backtest history is fetched directly by the Master Excel Python bridge and is not stored in PostgreSQL.",
        }
    if status["requirement_met"]:
        return {**status, "backfill_attempted": False, "warning": None}

    start_date = (date.today() - timedelta(days=366 * EXCEL_FETCH_HISTORY_YEARS)).isoformat()
    warning = None
    try:
        # Yahoo is the common long-history source for US/NSE and a configured
        # fallback for BSE.  sync_ohlcv is idempotent, so repeated Excel refresh
        # requests do not duplicate rows.
        rows = YahooProvider().get_ohlcv(
            symbol=symbol,
            exchange=exchange,
            start_date=start_date,
        )
        if rows:
            sync_ohlcv(db=db, symbol=symbol, exchange=exchange, rows=rows)
        else:
            warning = "Long-history provider returned no rows; verified stored history is being used."
    except Exception as exc:
        db.rollback()
        warning = f"Long-history refresh is temporarily unavailable: {exc}"

    status = _excel_history_status(db, symbol, exchange)
    return {**status, "backfill_attempted": True, "warning": warning}


@router.get("/excel-feed/{symbol}")
def get_excel_feed(symbol: str, exchange: str = "US", limit: int = Query(EXCEL_DEFAULT_HISTORY_ROWS, ge=20, le=5000), db: Session = Depends(get_db)):
    """Refreshable JSON feed for Excel snapshots; long backtest history is fetched directly by the Master Excel bridge in free-tier mode."""
    symbol = symbol.upper().strip()
    exchange = exchange.upper().strip()
    history_status = _ensure_excel_history(db, symbol, exchange)
    company = db.query(Company).filter(Company.symbol == symbol, Company.exchange == exchange).first()
    rows = (
        db.query(OHLCV)
        .filter(OHLCV.symbol == symbol, OHLCV.exchange == exchange)
        .order_by(OHLCV.date.desc())
        .limit(limit)
        .all()
    )
    rows = list(reversed(_valid_trading_rows(rows, exchange)))
    fundamental = db.query(Fundamental).filter(Fundamental.symbol == symbol, Fundamental.exchange == exchange).first()
    ownership = db.query(Ownership).filter(Ownership.symbol == symbol, Ownership.exchange == exchange).first()
    return _json_safe({
        "symbol": symbol,
        "exchange": exchange,
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "history": history_status,
        "company": {
            "name": company.name if company else None,
            "isin": company.isin if company else None,
            "sector": company.sector if company else None,
            "industry": company.industry if company else None,
        },
        "fundamental_snapshot": {
            "market_cap": fundamental.market_cap if fundamental else None,
            "trailing_eps": fundamental.trailing_eps if fundamental else None,
            "forward_eps": fundamental.forward_eps if fundamental else None,
            "revenue": fundamental.revenue if fundamental else None,
            "net_income": fundamental.net_income if fundamental else None,
            "profit_margin": fundamental.profit_margin if fundamental else None,
            "return_on_equity": fundamental.return_on_equity if fundamental else None,
            "return_on_assets": fundamental.return_on_assets if fundamental else None,
        },
        "ownership_snapshot": {
            "insider_percent": ownership.insider_percent if ownership else None,
            "institution_percent": ownership.institution_percent if ownership else None,
            "shares_outstanding": ownership.shares_outstanding if ownership else None,
            "float_shares": ownership.float_shares if ownership else None,
        },
        "ohlcv": [
            {"date": r.date.isoformat(), "open": r.open, "high": r.high, "low": r.low, "close": r.close, "volume": r.volume}
            for r in rows
        ],
        "ranking_spec": get_client_ranking_spec(),
        "excel_note": "Master Excel uses compact API snapshots plus direct real-provider history for up to 20-year backtesting in free-tier mode; missing provider data remains N/A.",
    })


@router.get("/excel-live-csv/{symbol}")
def get_excel_live_csv(symbol: str, exchange: str = "US", limit: int = Query(EXCEL_DEFAULT_HISTORY_ROWS, ge=20, le=5000), db: Session = Depends(get_db)):
    """CSV endpoint intended for a persistent Excel web-query connection.

    The first request best-effort backfills five years, which satisfies the
    client's requirement that indicator creation has at least four years of
    daily data.  Excel can keep this URL as an external connection and update it
    with Data -> Refresh All.
    """
    feed = get_excel_feed(symbol=symbol, exchange=exchange, limit=limit, db=db)
    company = feed.get("company") or {}
    history = feed.get("history") or {}
    output = StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow([
        "Symbol", "Exchange", "Company", "ISIN", "Sector", "Industry",
        "Date", "Open", "High", "Low", "Close", "Volume",
    ])
    for row in feed.get("ohlcv") or []:
        writer.writerow([
            feed.get("symbol"), feed.get("exchange"), company.get("name"), company.get("isin"),
            company.get("sector"), company.get("industry"), row.get("date"), row.get("open"),
            row.get("high"), row.get("low"), row.get("close"), row.get("volume"),
        ])

    filename = f"{feed.get('symbol', 'stock')}_{feed.get('exchange', 'market')}_live_history.csv"
    return Response(
        content=output.getvalue(),
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": f'inline; filename="{filename}"',
            "Cache-Control": "no-store, max-age=0",
            "X-Excel-History-Requirement": "met" if history.get("requirement_met") else "partial",
            "X-Excel-Earliest-Date": str(history.get("earliest_date") or ""),
            "X-Excel-Latest-Date": str(history.get("latest_date") or ""),
        },
    )


@router.get("/excel-export/{symbol}")
def export_excel_snapshot(symbol: str, exchange: str = "US", limit: int = Query(EXCEL_DEFAULT_HISTORY_ROWS, ge=20, le=5000), db: Session = Depends(get_db)):
    """Download an editable workbook containing real stored data + client ranking formula sheets."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Excel export dependency is unavailable: {exc}")

    symbol = symbol.upper()
    exchange = exchange.upper()
    feed = get_excel_feed(symbol=symbol, exchange=exchange, limit=limit, db=db)
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    summary_rows = [
        ("Symbol", symbol), ("Exchange", exchange),
        ("Company", feed["company"].get("name")),
        ("Sector", feed["company"].get("sector")),
        ("Industry", feed["company"].get("industry")),
        ("Generated At", feed.get("generated_at")),
    ]
    for row in summary_rows:
        ws.append(row)
    ws["A1"].font = Font(bold=True)

    raw = wb.create_sheet("OHLCV")
    raw.append(["Date", "Open", "High", "Low", "Close", "Volume"])
    for cell in raw[1]: cell.font = Font(bold=True)
    for row in feed["ohlcv"]:
        raw.append([row["date"], row["open"], row["high"], row["low"], row["close"], row["volume"]])

    snap = wb.create_sheet("Fundamental_Ownership")
    snap.append(["Field", "Value"])
    for cell in snap[1]: cell.font = Font(bold=True)
    for key, value in feed["fundamental_snapshot"].items(): snap.append([f"fundamental.{key}", value])
    for key, value in feed["ownership_snapshot"].items(): snap.append([f"ownership.{key}", value])

    cfg = wb.create_sheet("Ranking_Config")
    cfg.append(["Component", "Score (0-100)", "Weight %", "Weighted Points"])
    for cell in cfg[1]: cell.font = Font(bold=True)
    order = ["fundamental", "technical", "relative_strength", "ownership", "sector"]
    for idx, key in enumerate(order, start=2):
        cfg.cell(idx, 1, key)
        cfg.cell(idx, 2, None)
        cfg.cell(idx, 3, CLIENT_COMPOSITE_WEIGHTS[key])
        cfg.cell(idx, 4, f"=IF(ISNUMBER(B{idx}),B{idx}*C{idx}/100,0)")
    cfg["A8"] = "Composite Score"
    cfg["B8"] = "=IF(COUNT(B2:B6)=0,\"\",SUM(D2:D6)/SUMPRODUCT(--ISNUMBER(B2:B6),C2:C6)*100)"
    cfg["A10"] = "Client formula"
    cfg["B10"] = "Fundamental*0.30 + Technical*0.25 + RS*0.25 + Ownership*0.15 + Sector*0.05"

    tech_filters = wb.create_sheet("Technical_Filter_Config")
    tech_filters.append(["Filter Name", "Compare", "Value / Target", "Weight", "Enabled", "Filter Score (0-100)", "Weighted Points"])
    for cell in tech_filters[1]: cell.font = Font(bold=True)
    for idx, item in enumerate(CLIENT_TECHNICAL_FILTER_CONFIG, start=2):
        tech_filters.append([item["name"], item["compare"], item["value"], item["weight"], "Yes" if item["enabled"] else "No", None, f'=IF(AND(E{idx}="Yes",ISNUMBER(F{idx})),F{idx}*D{idx},0)'])
    tech_total_row = len(CLIENT_TECHNICAL_FILTER_CONFIG) + 3
    tech_filters.cell(tech_total_row, 1, "Technical Filter Score")
    tech_filters.cell(tech_total_row, 2, f'=IFERROR(SUM(G2:G{tech_total_row-2})/SUMPRODUCT((E2:E{tech_total_row-2}="Yes")*D2:D{tech_total_row-2}),"")')

    fundamental_filters = wb.create_sheet("Fundamental_Filter_Config")
    fundamental_filters.append(["Group", "Filter Name", "Compare", "Value / Target", "Weight", "Enabled", "Filter Score (0-100)", "Weighted Points"])
    for cell in fundamental_filters[1]: cell.font = Font(bold=True)
    for idx, item in enumerate(CLIENT_FUNDAMENTAL_FILTER_CONFIG, start=2):
        fundamental_filters.append([item["group"], item["name"], item["compare"], item["value"], item["weight"], "Yes" if item["enabled"] else "No", None, f'=IF(AND(F{idx}="Yes",ISNUMBER(G{idx})),G{idx}*E{idx},0)'])
    row_cursor = len(CLIENT_FUNDAMENTAL_FILTER_CONFIG) + 3
    fundamental_filters.cell(row_cursor, 1, "Overall Fundamental Filter Score")
    fundamental_filters.cell(row_cursor, 2, f'=IFERROR(SUM(H2:H{row_cursor-2})/SUMPRODUCT((F2:F{row_cursor-2}="Yes")*E2:E{row_cursor-2}),"")')
    row_cursor += 2
    fundamental_filters.cell(row_cursor, 1, "Group Scores")
    fundamental_filters.cell(row_cursor, 1).font = Font(bold=True)
    row_cursor += 1
    for group_name in ["EPS", "PAT", "Sales", "NPM", "CFO", "Other"]:
        fundamental_filters.cell(row_cursor, 1, group_name)
        # SUMIFS keeps the workbook editable even when the client changes weights/scores.
        fundamental_filters.cell(row_cursor, 2, f'=IFERROR(SUMIFS(H$2:H${len(CLIENT_FUNDAMENTAL_FILTER_CONFIG)+1},A$2:A${len(CLIENT_FUNDAMENTAL_FILTER_CONFIG)+1},A{row_cursor})/SUMIFS(E$2:E${len(CLIENT_FUNDAMENTAL_FILTER_CONFIG)+1},A$2:A${len(CLIENT_FUNDAMENTAL_FILTER_CONFIG)+1},A{row_cursor},F$2:F${len(CLIENT_FUNDAMENTAL_FILTER_CONFIG)+1},"Yes"),"")')
        row_cursor += 1

    sector = wb.create_sheet("Sector_Ranking_Config")
    sector.append(["Sector Component", "Score (0-100)", "Weight %", "Weighted Points"])
    for cell in sector[1]: cell.font = Font(bold=True)
    for idx, (key, weight) in enumerate(CLIENT_SECTOR_WEIGHTS.items(), start=2):
        sector.cell(idx, 1, key)
        sector.cell(idx, 2, None)
        sector.cell(idx, 3, weight)
        sector.cell(idx, 4, f"=IF(ISNUMBER(B{idx}),B{idx}*C{idx}/100,0)")
    sector["A9"] = "Sector Score"
    sector["B9"] = "=IF(COUNT(B2:B7)=0,\"\",SUM(D2:D7)/SUMPRODUCT(--ISNUMBER(B2:B7),C2:C7)*100)"
    sector["A11"] = "Growth Breadth"
    sector["B11"] = "=(Sales breadth + PAT breadth + EPS breadth) / 3"
    sector["A12"] = "Acceleration Breadth"
    sector["B12"] = "=35% EPS + 35% PAT + 30% Sales acceleration breadth"

    notes = wb.create_sheet("Notes")
    notes.append(["Milestone 2 handwritten ranking notes"])
    notes["A1"].font = Font(bold=True)
    notes.append(["All market/fundamental values must come from configured providers or stored DB data; missing values stay N/A."])
    notes.append(["Ambiguous handwritten thresholds/point allocations remain editable and must not be guessed."])
    notes.append(["For a live Excel connection, use the /market/excel-feed/{symbol}?exchange=... endpoint through Power Query."])

    for sheet in wb.worksheets:
        for col in sheet.columns:
            width = min(60, max(12, max(len(str(c.value)) if c.value is not None else 0 for c in col) + 2))
            sheet.column_dimensions[col[0].column_letter].width = width

    stream = BytesIO()
    wb.save(stream)
    stream.seek(0)
    filename = f"{symbol}_{exchange}_screener.xlsx"
    payload = stream.getvalue()
    return Response(
        content=payload,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(payload)),
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
        },
    )


@router.get("/provider-status")
def get_provider_status():
    """Configuration-only provider status; no third-party network call is made."""
    sec_agent = os.getenv("SEC_USER_AGENT", "").strip()
    twelve_key = os.getenv("TWELVE_DATA_API_KEY", "").strip()
    auto_symbols = os.getenv("AUTO_REFRESH_SYMBOLS", "").strip()
    return {
        "providers": {
            "yahoo_finance": {
                "configured": True,
                "uses_personal_api_key": False,
                "purpose": "US/NSE OHLCV, quotes, provider fallback fundamentals/ownership",
            },
            "sec_edgar": {
                "configured": bool(sec_agent),
                "uses_personal_api_key": False,
                "purpose": "Official US XBRL fundamentals and filing metadata",
                "required_env": "SEC_USER_AGENT",
            },
            "twelve_data_bse": {
                "configured": bool(twelve_key),
                "uses_personal_api_key": True,
                "purpose": "BSE/XBOM daily OHLCV",
                "required_env": "TWELVE_DATA_API_KEY",
            },
            "kotak_neo_india": {
                "configured": bool(os.getenv("KOTAK_NEO_API_KEY", "").strip() or os.getenv("KOTAK_NEO_ACCESS_TOKEN", "").strip()),
                "ready_for_live_quotes": bool(os.getenv("KOTAK_NEO_BASE_URL", "").strip() and os.getenv("KOTAK_NEO_ACCESS_TOKEN", "").strip()),
                "uses_personal_api_key": True,
                "purpose": "Indian-stock market data only; kept separate from US sources",
                "required_env": "KOTAK_NEO_API_KEY / KOTAK_NEO_ACCESS_TOKEN / KOTAK_NEO_BASE_URL",
                "note": "Credential/auth flow will be validated with the client's Kotak Neo account before enabling it as the live Indian provider.",
            },
        },
        "automatic_refresh": {
            "configured_symbols": [item.strip() for item in auto_symbols.split(",") if item.strip()],
            "enabled": bool(auto_symbols),
            "note": "Configure AUTO_REFRESH_SYMBOLS as EXCHANGE:SYMBOL entries; no CSV upload is required.",
        },
    }


@router.get("/india-shareholding/{symbol}")
def get_india_shareholding(symbol: str, exchange: str = "NSE", limit: int = 8):
    exchange = exchange.upper()
    if exchange not in {"NSE", "BSE"}:
        raise HTTPException(status_code=400, detail="Indian shareholding supports NSE/BSE symbols only")
    try:
        provider = IndiaShareholdingProvider()
        return _json_safe(provider.get_history(symbol.upper(), limit=limit))
    except Exception as e:
        # Keep a clean 503 instead of turning a third-party provider outage into
        # a generic 500 that makes the whole dashboard look broken.
        raise HTTPException(status_code=503, detail=f"Indian shareholding data unavailable: {str(e)}")


@router.get("/technical-summary/{symbol}")
def get_technical_summary(
    symbol: str,
    exchange: str = "US",
    timeframe: str = Query("daily", pattern="^(daily|weekly|monthly)$"),
    rs_1w_weight: float = 30,
    rs_2w_weight: float = 0,
    rs_1m_weight: float = 25,
    rs_2m_weight: float = 0,
    rs_3m_weight: float = 20,
    rs_6m_weight: float = 15,
    rs_1y_weight: float = 10,
    rs_sector_weight: float = 0,
    db: Session = Depends(get_db)
):
    symbol = symbol.upper()
    exchange = exchange.upper()

    daily_rows = _market_rows_with_live_fallback(
        db, symbol=symbol, exchange=exchange, min_rows=20, years=5
    )
    if len(daily_rows) < 20:
        raise HTTPException(status_code=404, detail="Not enough historical data for technical summary")

    rows = daily_rows
    if timeframe != "daily":
        import pandas as pd
        from types import SimpleNamespace

        frame = pd.DataFrame([
            {
                "date": row.date,
                "open": float(row.open),
                "high": float(row.high),
                "low": float(row.low),
                "close": float(row.close),
                "volume": float(row.volume or 0),
            }
            for row in daily_rows
        ])
        frame["date"] = pd.to_datetime(frame["date"])
        frame["actual_date"] = frame["date"]
        frame = frame.set_index("date")
        rule = "W" if timeframe == "weekly" else "ME"
        frame = frame.resample(rule).agg({
            "open": "first",
            "high": "max",
            "low": "min",
            "close": "last",
            "volume": "sum",
            "actual_date": "last",
        }).dropna(subset=["open", "high", "low", "close"])

        rows = [
            SimpleNamespace(
                date=item.actual_date.date(),
                open=float(item.open),
                high=float(item.high),
                low=float(item.low),
                close=float(item.close),
                volume=float(item.volume or 0),
            )
            for item in frame.itertuples()
        ]

    if len(rows) < 20:
        raise HTTPException(status_code=404, detail=f"Not enough {timeframe} historical data for technical summary")

    closes = [float(row.close) for row in rows]
    highs = [float(row.high) for row in rows]
    lows = [float(row.low) for row in rows]
    opens = [float(row.open) for row in rows]
    volumes = [float(row.volume or 0) for row in rows]

    ema_periods = [20, 30, 50, 100, 150, 200]
    emas = {str(period): _ema(closes, period) for period in ema_periods}
    available_emas = [emas[str(p)] for p in ema_periods if emas[str(p)] is not None]
    ema_alignment = "Unavailable"
    if len(available_emas) == len(ema_periods):
        bullish = all(available_emas[i] > available_emas[i + 1] for i in range(len(available_emas) - 1))
        bearish = all(available_emas[i] < available_emas[i + 1] for i in range(len(available_emas) - 1))
        ema_alignment = "Bullish" if bullish else "Bearish" if bearish else "Mixed"

    avg_volume_10 = sum(volumes[-10:]) / 10 if len(volumes) >= 10 else None
    avg_volume_20 = sum(volumes[-20:]) / 20
    avg_volume_40 = sum(volumes[-40:]) / 40 if len(volumes) >= 40 else None
    avg_volume_50 = sum(volumes[-50:]) / 50 if len(volumes) >= 50 else None
    volume_ratio = (volumes[-1] / avg_volume_20) if avg_volume_20 else None
    volume_ratio_50 = (volumes[-1] / avg_volume_50) if avg_volume_50 else None

    # ADR is a DAILY metric even when the chart is weekly/monthly.
    # Client/TradingView reference displays ADR(20) as an absolute price range:
    # Average(High - Low, 20 daily sessions).  Keep ADR% separately for
    # normalized comparisons and volatility logic.
    adr_daily_rows = daily_rows[-20:]
    adr_abs_values = [
        float(r.high) - float(r.low)
        for r in adr_daily_rows
        if r.high is not None and r.low is not None
    ]
    adr_percent_values = [
        ((float(r.high) - float(r.low)) / float(r.low)) * 100
        for r in adr_daily_rows
        if r.high is not None and r.low not in (None, 0)
    ]
    adr_value = sum(adr_abs_values) / len(adr_abs_values) if adr_abs_values else None
    adr_percent = sum(adr_percent_values) / len(adr_percent_values) if adr_percent_values else None

    # ATR uses Wilder's RMA (the same smoothing convention used by TradingView
    # ATR), calculated on the SELECTED timeframe.
    true_ranges = []
    for i in range(len(rows)):
        prev_close = closes[i - 1] if i > 0 else closes[i]
        true_ranges.append(max(highs[i] - lows[i], abs(highs[i] - prev_close), abs(lows[i] - prev_close)))
    atr14 = _rma(true_ranges, 14)
    atr_percent = (atr14 / closes[-1] * 100) if atr14 is not None and closes[-1] else None

    # Handwritten client ranking factors compare short ATR% averages with a
    # 20-period ATR% average.  Expose the raw comparable values so the UI can
    # score exactly those factors without inventing hidden inputs.
    atr_percent_series = [
        (true_ranges[i] / closes[i] * 100) if closes[i] else None
        for i in range(len(true_ranges))
    ]
    def _tail_average(values, period):
        usable = [v for v in values[-period:] if v is not None]
        return (sum(usable) / len(usable)) if len(usable) == period else None

    avg_atr_percent_5 = _tail_average(atr_percent_series, 5)
    avg_atr_percent_10 = _tail_average(atr_percent_series, 10)
    avg_atr_percent_20 = _tail_average(atr_percent_series, 20)
    rsi14 = _rsi(closes, 14)

    # Additional Milestone-2 technical filters from the client's handwritten notes.
    latest_price = closes[-1]
    ema20_previous = _ema(closes[:-1], 20) if len(closes) > 20 else None
    ema50_previous = _ema(closes[:-1], 50) if len(closes) > 50 else None
    ema200_previous = _ema(closes[:-1], 200) if len(closes) > 200 else None
    adx14, plus_di14, minus_di14, di_spread14 = _adx_di(highs, lows, closes, 14)
    roc_1m = _roc(closes, 21)
    roc_3m = _roc(closes, 63)
    roc_6m = _roc(closes, 126)
    roc_12m = _roc(closes, 252)
    roc_1m_two_weeks_ago = None
    if len(closes) > 31:
        historic = closes[:-10]
        roc_1m_two_weeks_ago = _roc(historic, 21)
    roc_acceleration_1m = (
        roc_1m - roc_1m_two_weeks_ago
        if roc_1m is not None and roc_1m_two_weeks_ago is not None else None
    )

    range90 = None
    if len(rows) >= 90:
        low90 = min(lows[-90:])
        high90 = max(highs[-90:])
        range90 = ((high90 - low90) / low90 * 100) if low90 else None

    recent20 = closes[-20:]
    sma20 = sum(recent20) / 20
    variance20 = sum((x - sma20) ** 2 for x in recent20) / 20
    sd20 = variance20 ** 0.5
    bb_upper = sma20 + 2 * sd20
    bb_lower = sma20 - 2 * sd20
    # Client-specified Bollinger Band width formula:
    # (Upper BB - Lower BB) * 100 / Lower BB
    bb_width = ((bb_upper - bb_lower) / bb_lower * 100) if bb_lower not in (None, 0) else None
    bb_width_20_periods_ago = None
    if len(closes) >= 40:
        old_window = closes[-40:-20]
        old_mean = sum(old_window) / 20
        old_var = sum((x - old_mean) ** 2 for x in old_window) / 20
        old_sd = old_var ** 0.5
        old_upper = old_mean + 2 * old_sd
        old_lower = old_mean - 2 * old_sd
        bb_width_20_periods_ago = ((old_upper - old_lower) / old_lower * 100) if old_lower else None

    range20 = ((max(highs[-20:]) - min(lows[-20:])) / min(lows[-20:]) * 100) if min(lows[-20:]) else None

    # Volatility trend series follows the SELECTED chart timeframe.
    # The top ADR(20D) value above intentionally remains a daily metric per the
    # earlier client rule, while this trend chart converts its candles to weekly
    # or monthly when the user changes the main chart timeframe.
    metric_rows = rows
    metric_series = []
    metric_trs = []
    running_metric_atr = None
    for i, r in enumerate(metric_rows):
        h = float(r.high)
        l = float(r.low)
        c = float(r.close)
        prev_c = float(metric_rows[i - 1].close) if i > 0 else c
        tr = max(h - l, abs(h - prev_c), abs(l - prev_c))
        metric_trs.append(tr)
        if i == 13:
            running_metric_atr = sum(metric_trs[:14]) / 14
        elif i > 13 and running_metric_atr is not None:
            running_metric_atr = ((running_metric_atr * 13) + tr) / 14

        if i < 19:
            continue

        window = metric_rows[i - 19:i + 1]
        closes20 = [float(x.close) for x in window]
        highs20 = [float(x.high) for x in window]
        lows20 = [float(x.low) for x in window]
        adr_pct_values = [
            ((float(x.high) - float(x.low)) / float(x.low)) * 100
            for x in window if float(x.low) != 0
        ]
        adr_pct_20 = (sum(adr_pct_values) / len(adr_pct_values)) if adr_pct_values else None

        mean20 = sum(closes20) / 20
        variance = sum((v - mean20) ** 2 for v in closes20) / 20
        sd = variance ** 0.5
        upper = mean20 + 2 * sd
        lower = mean20 - 2 * sd
        bb_pct = ((upper - lower) / lower * 100) if lower else None
        price_range_pct = ((max(highs20) - min(lows20)) / min(lows20) * 100) if min(lows20) else None
        atr_pct_period = (running_metric_atr / c * 100) if running_metric_atr is not None and c else None

        metric_series.append({
            "date": r.date.isoformat() if hasattr(r.date, "isoformat") else str(r.date),
            "adr_percent": round(adr_pct_20, 2) if adr_pct_20 is not None else None,
            "atr_percent": round(atr_pct_period, 2) if atr_pct_period is not None else None,
            "bollinger_width_percent": round(bb_pct, 2) if bb_pct is not None else None,
            # Keep the existing API key for frontend/backward compatibility;
            # its window is 20 periods of the selected timeframe.
            "range_20d_percent": round(price_range_pct, 2) if price_range_pct is not None else None,
        })
    periods_per_52w = 252 if timeframe == "daily" else 52 if timeframe == "weekly" else 12
    lookback_52w = min(periods_per_52w, len(rows))
    high_52w = max(highs[-lookback_52w:])
    distance_52w_high = ((high_52w - closes[-1]) / high_52w * 100) if high_52w else None
    high_52w_slice = highs[-lookback_52w:]
    high_52w_index = max(range(len(high_52w_slice)), key=lambda i: high_52w_slice[i]) if high_52w_slice else None
    periods_since_52w_high = (len(high_52w_slice) - 1 - high_52w_index) if high_52w_index is not None else None

    # VCP/consolidation detection. Three successive 20-period windows are used
    # as transparent contractions. When both price depth and ATR% contract in
    # sequence, the final contraction high becomes the pivot (client-defined).
    contractions = []
    final_contraction_high = None
    if len(rows) >= 60:
        for start_i, end_i in [(-60, -40), (-40, -20), (-20, None)]:
            segment = rows[start_i:end_i]
            seg_high = max(float(r.high) for r in segment)
            seg_low = min(float(r.low) for r in segment)
            depth = ((seg_high - seg_low) / seg_high * 100) if seg_high else None
            seg_tr = []
            for j, r in enumerate(segment):
                prev = float(segment[j-1].close) if j > 0 else float(r.close)
                seg_tr.append(max(float(r.high)-float(r.low), abs(float(r.high)-prev), abs(float(r.low)-prev)))
            seg_atr = _rma(seg_tr, 14) if len(seg_tr) >= 14 else (sum(seg_tr) / len(seg_tr) if seg_tr else None)
            seg_atr_pct = (seg_atr / float(segment[-1].close) * 100) if seg_atr and segment[-1].close else None
            seg_closes = [float(r.close) for r in segment if r.close is not None]
            seg_mean = (sum(seg_closes) / len(seg_closes)) if seg_closes else None
            seg_std = (sum((x - seg_mean) ** 2 for x in seg_closes) / len(seg_closes)) ** 0.5 if seg_closes and seg_mean else None
            seg_std_pct = (seg_std / seg_mean * 100) if seg_std is not None and seg_mean else None
            seg_avg_volume = (sum(float(r.volume or 0) for r in segment) / len(segment)) if segment else None
            contractions.append({
                "depth_percent": depth,
                "atr_percent": seg_atr_pct,
                "standard_deviation_percent": seg_std_pct,
                "average_volume": seg_avg_volume,
                "high": seg_high,
                "low": seg_low,
            })

    vcp_stage = "Not Detected"
    if len(contractions) == 3:
        depths = [c["depth_percent"] for c in contractions]
        atrs = [c["atr_percent"] for c in contractions]
        stds = [c["standard_deviation_percent"] for c in contractions]
        vols = [c["average_volume"] for c in contractions]
        price_contracting = all(v is not None for v in depths) and depths[1] < depths[0] and depths[2] < depths[1]
        atr_contracting = all(v is not None for v in atrs) and atrs[1] < atrs[0] and atrs[2] < atrs[1]
        std_contracting = all(v is not None for v in stds) and stds[1] < stds[0] and stds[2] < stds[1]
        volume_contracting = all(v is not None for v in vols) and vols[1] < vols[0] and vols[2] < vols[1]
        if price_contracting and atr_contracting and std_contracting and volume_contracting:
            vcp_stage = "VCP Contraction"
            final_contraction_high = contractions[-1]["high"]

    # If a formal VCP is not detected, use the recent consolidation high as the
    # fallback pivot. Never use today's high itself as the pivot.
    consolidation_rows = rows[-21:-1] if len(rows) >= 21 else rows[:-1]
    consolidation_high = max((float(r.high) for r in consolidation_rows), default=None)
    pivot = final_contraction_high if final_contraction_high is not None else consolidation_high

    buffer = 0.003
    latest_close = closes[-1]
    latest_open = opens[-1]
    latest_midpoint = (highs[-1] + lows[-1]) / 2

    breakout_status = "Unavailable"
    breakout_strength = None
    near_pivot = False
    if pivot is not None:
        near_pivot = (pivot * 0.95) <= latest_close <= (pivot * 1.02)
        above_pivot = latest_close > pivot * (1 + buffer)
        price_confirmation = latest_close > latest_open and latest_close >= latest_midpoint
        volume_confirmation = volume_ratio_50 is not None and volume_ratio_50 >= 1.4

        if above_pivot and price_confirmation and volume_confirmation:
            breakout_status = "Confirmed Breakout"
        elif latest_close > pivot:
            breakout_status = "Potential Breakout"
        elif near_pivot:
            breakout_status = "Near Pivot"
        else:
            breakout_status = "No Breakout"

        # Client-requested 0-100 breakout-strength model.
        points = 0
        if latest_close > pivot: points += 20
        if volume_ratio_50 is not None and volume_ratio_50 >= 1.4: points += 20
        if volume_ratio_50 is not None and volume_ratio_50 >= 2.0: points += 10
        if latest_close > pivot * 1.005: points += 10
        if latest_close > pivot * 1.01: points += 10

        atr_contraction = False
        if len(contractions) >= 2:
            a = contractions[-2].get("atr_percent")
            b = contractions[-1].get("atr_percent")
            atr_contraction = a is not None and b is not None and b < a
        if atr_contraction: points += 10

        if len(rows) >= 10:
            tight_high = max(highs[-10:])
            tight_low = min(lows[-10:])
            tight_range = ((tight_high - tight_low) / tight_high * 100) if tight_high else None
            if tight_range is not None and tight_range <= 10:
                points += 10

        breakout_strength = min(100, points)

    gap_percent = None
    gap_classification = "Unavailable"
    if len(rows) >= 2 and closes[-2]:
        gap_percent = ((opens[-1] - closes[-2]) / closes[-2]) * 100
        if gap_percent >= 8:
            gap_classification = "Excessive Gap Breakout"
        elif gap_percent >= 2:
            gap_classification = "Gap Breakout"
        else:
            gap_classification = "Normal / No Material Gap"

    if breakout_status == "Confirmed Breakout":
        pattern = "Confirmed Breakout"
    elif vcp_stage == "VCP Contraction":
        pattern = "VCP / Volatility Contraction"
    elif range20 is not None and range20 <= 10:
        pattern = "Tight Consolidation"
    elif near_pivot:
        pattern = "Near Pivot"
    else:
        pattern = "None"

    rs_period_weights = {"1w": rs_1w_weight, "2w": rs_2w_weight, "1m": rs_1m_weight, "2m": rs_2m_weight, "3m": rs_3m_weight, "6m": rs_6m_weight, "1y": rs_1y_weight, "sector": rs_sector_weight}
    rs_rating, rs_weighted_relative_return, rs_metrics, benchmark_name, rs_chart = _weighted_rs_against_benchmark(daily_rows, exchange, rs_period_weights, db=db)

    # Client handwritten comparison table: raw returns stay separate from RS scoring weights.
    stock_points = [
        (r.date, float(r.open) if r.open is not None else float(r.close), float(r.close))
        for r in daily_rows if r.date is not None and r.close is not None
    ]
    company = db.query(Company).filter(Company.symbol == symbol, Company.exchange == exchange).first()
    if exchange == "US":
        index_rows = [
            {"key": "dow_jones", "label": "Dow Jones", "returns": _yf_period_returns("^DJI")},
            {"key": "sp500", "label": "S&P 500", "returns": _yf_period_returns("^GSPC")},
        ]
    else:
        index_rows = [
            {"key": "nifty50", "label": "NIFTY 50", "returns": _yf_period_returns("^NSEI")},
            {"key": "nifty500", "label": "NIFTY 500", "returns": _yf_period_returns("^CRSLDX")},
        ]
    industry_returns = _peer_group_period_returns(
        db, exchange, "industry", company.industry if company else None,
        exclude_symbol=symbol, minimum_peers=5
    )
    sector_returns = _peer_group_period_returns(
        db, exchange, "sector", company.sector if company else None,
        exclude_symbol=symbol, minimum_peers=5
    )
    rs_comparison = {
        "periods": ["1d", "1w", "2w", "3w", "1m", "2m", "3m", "6m", "1y"],
        "rows": [
            {"key": "stock", "label": "Stock Return", "returns": _period_returns_from_points(stock_points)},
            *index_rows,
            {
                "key": "industry", "label": "Industry",
                "name": company.industry if company else None,
                "returns": industry_returns,
                "note": None if industry_returns else "Insufficient stored peer history; N/A shown.",
            },
            {
                "key": "sector", "label": "Sector",
                "name": company.sector if company else None,
                "returns": sector_returns,
                "note": None if sector_returns else "Insufficient stored peer history; N/A shown.",
            },
        ],
        "method": "Current-period open to latest close; industry/sector are equal-weight averages of at least 5 stored peers, excluding the selected stock. If fewer peers are available, N/A is shown. These raw returns do not use RS scoring weights.",
    }

    delivery_summary = _nse_delivery_summary(symbol) if exchange == "NSE" else {
        "available": False,
        "source": exchange,
        "note": "True delivery percentage requires exchange deliverable-quantity data; ordinary OHLCV volume is not substituted.",
    }

    client_technical_filters = {
        "trend": {
            "price": latest_price,
            "price_gt_ema20": (latest_price > emas.get("20")) if emas.get("20") is not None else None,
            "ema20_slope_positive": (emas.get("20") > ema20_previous) if emas.get("20") is not None and ema20_previous is not None else None,
            "price_gt_ema50": (latest_price > emas.get("50")) if emas.get("50") is not None else None,
            "ema50_slope_positive": (emas.get("50") > ema50_previous) if emas.get("50") is not None and ema50_previous is not None else None,
            "price_gt_ema200": (latest_price > emas.get("200")) if emas.get("200") is not None else None,
            "ema200_slope_positive": (emas.get("200") > ema200_previous) if emas.get("200") is not None and ema200_previous is not None else None,
        },
        "strength": {
            "rs_score": rs_rating,
            "distance_from_52w_high_percent": distance_52w_high,
            "periods_since_52w_high": periods_since_52w_high,
            "new_52w_high_within_30_periods": (periods_since_52w_high <= 30) if periods_since_52w_high is not None else None,
            "adx_14": adx14,
            "plus_di_14": plus_di14,
            "minus_di_14": minus_di14,
            "di_spread": di_spread14,
            "di_spread_gt_10": (di_spread14 > 10) if di_spread14 is not None else None,
        },
        "momentum": {
            "roc_1m_percent": roc_1m,
            "roc_3m_percent": roc_3m,
            "roc_6m_percent": roc_6m,
            "roc_12m_percent": roc_12m,
            "roc_1m_two_weeks_ago_percent": roc_1m_two_weeks_ago,
            "roc_1m_acceleration_points": roc_acceleration_1m,
        },
        "participation": {
            "average_volume_10": avg_volume_10,
            "average_volume_20": avg_volume_20,
            "average_volume_40": avg_volume_40,
            "average_volume_50": avg_volume_50,
            "delivery_percent": delivery_summary,
        },
        "volatility": {
            "atr_percent": atr_percent,
            "average_atr_percent_5": avg_atr_percent_5,
            "average_atr_percent_10": avg_atr_percent_10,
            "average_atr_percent_20": avg_atr_percent_20,
            "bollinger_width_percent": bb_width,
            "bollinger_width_20_periods_ago_percent": bb_width_20_periods_ago,
            "bb_width_contracting": (bb_width < bb_width_20_periods_ago) if bb_width is not None and bb_width_20_periods_ago is not None else None,
        },
        "base_formation": {
            "range_20_period_percent": range20,
            "range_90_period_percent": range90,
            "range_90_le_20_percent": (range90 <= 20) if range90 is not None else None,
            "vcp_stage": vcp_stage,
            "standard_deviation_contracting": std_contracting if len(contractions) == 3 else None,
            "volume_contracting": volume_contracting if len(contractions) == 3 else None,
        },
        "note": "These are real-data filter inputs from the client handwritten technical sheet. Ambiguous handwritten point allocations remain configurable rather than guessed.",
    }

    return _json_safe({
        "symbol": symbol,
        "exchange": exchange,
        "timeframe": timeframe,
        "ema": {key: (round(value, 2) if value is not None else None) for key, value in emas.items()},
        "ema_alignment": ema_alignment,
        "average_volume_10": round(avg_volume_10, 2) if avg_volume_10 is not None else None,
        "average_volume_20": round(avg_volume_20, 2),
        "average_volume_40": round(avg_volume_40, 2) if avg_volume_40 is not None else None,
        "average_volume_50": round(avg_volume_50, 2) if avg_volume_50 is not None else None,
        "volume_ratio": round(volume_ratio, 2) if volume_ratio is not None else None,
        "volume_ratio_50": round(volume_ratio_50, 2) if volume_ratio_50 is not None else None,
        "adr_20": round(adr_value, 2) if adr_value is not None else None,
        "adr_percent": round(adr_percent, 2) if adr_percent is not None else None,
        "atr_14": round(atr14, 2) if atr14 is not None else None,
        "atr_percent": round(atr_percent, 2) if atr_percent is not None else None,
        "average_atr_percent_5": round(avg_atr_percent_5, 2) if avg_atr_percent_5 is not None else None,
        "average_atr_percent_10": round(avg_atr_percent_10, 2) if avg_atr_percent_10 is not None else None,
        "average_atr_percent_20": round(avg_atr_percent_20, 2) if avg_atr_percent_20 is not None else None,
        "rsi_14": round(rsi14, 2) if rsi14 is not None else None,
        "bollinger_width_percent": round(bb_width, 2) if bb_width is not None else None,
        "range_20d_percent": round(range20, 2) if range20 is not None else None,
        "technical_metric_series": metric_series[-260:],
        "technical_metric_timeframe": timeframe,
        "technical_metric_window_periods": 20,
        "distance_from_52w_high_percent": round(distance_52w_high, 2) if distance_52w_high is not None else None,
        "pivot": round(pivot, 2) if pivot is not None else None,
        "breakout_status": breakout_status,
        "breakout_strength": breakout_strength,
        "gap_percent": round(gap_percent, 2) if gap_percent is not None else None,
        "gap_classification": gap_classification,
        "vcp_stage": vcp_stage,
        "vcp_contractions": [{k: (round(v, 2) if isinstance(v, (int, float)) and v is not None else v) for k, v in item.items()} for item in contractions],
        "vcp_standard_deviation_contraction": (std_contracting if len(contractions) == 3 else None),
        "vcp_volume_contraction": (volume_contracting if len(contractions) == 3 else None),
        "pattern": pattern,
        "client_technical_filters": client_technical_filters,
        "rs_comparison": rs_comparison,
        "volume_delivery": delivery_summary,
        "rs_rating": rs_rating,
        "rs_available": rs_rating is not None and len(rs_chart) > 1,
        "rs_universe": {
            "market": _rs_market_group(exchange),
            "market_exchanges": list(_rs_market_exchanges(exchange)),
            "target_size": _rs_percentile_total(exchange),
            "scored_stocks_available": int(rs_metrics.get("_scored_stocks_available", 0) or 0),
            "coverage_percent": round(
                min(100.0, (float(rs_metrics.get("_scored_stocks_available", 0) or 0) / _rs_percentile_total(exchange)) * 100.0),
                2,
            ),
            "complete": int(rs_metrics.get("_scored_stocks_available", 0) or 0) >= _rs_percentile_total(exchange),
            "note": (
                f"Client percentile denominator is fixed at {_rs_percentile_total(exchange):,} for {_rs_market_group(exchange)}. "
                f"The RS score is provisional until {_rs_percentile_total(exchange):,} stored stocks have usable comparison history."
                if int(rs_metrics.get("_scored_stocks_available", 0) or 0) < _rs_percentile_total(exchange)
                else f"The stored RS comparison universe meets the client-required {_rs_percentile_total(exchange):,}-stock denominator for {_rs_market_group(exchange)}."
            ),
        },
        "rs_weighted_relative_return_percent": round(rs_weighted_relative_return, 2) if rs_weighted_relative_return is not None else None,
        "rs_benchmark": benchmark_name,
        "rs_periods": rs_metrics,
        "rs_chart": rs_chart,
        "rs_period_weights": rs_period_weights,
        "rs_formula": {
            "period_return": "((current close / current period candle open) - 1) * 100",
            "relative_return": "stock return % - benchmark return %",
            "relative_return_uses_editable_weights": False,
            "stock_percentile": f"((lower stocks + 0.5 * equal stocks) * 100) / {_rs_percentile_total(exchange)}",
            "stock_percentile_denominator": _rs_percentile_total(exchange),
            "final_rs_score": "sum(period percentile * enabled weight) / sum(enabled weights)",
            "default_weights": {"1w": 30, "1m": 25, "3m": 20, "6m": 15, "1y": 10, "2w": 0, "2m": 0, "sector": 0},
        },
        "rs_note": f"Relative Strength: period relative returns are raw market calculations and never change when RS score weights change. Each period uses TradingView-style current period candle return (period open to current close); relative return = stock return % - benchmark return %. Stock percentiles use the client-required fixed denominator of {_rs_percentile_total(exchange):,} stocks for {_rs_market_group(exchange)}: [(lower stocks + 0.5 x equal stocks) x 100 / {_rs_percentile_total(exchange)}]. Final RS Score uses weighted percentile components. Default weights are 1W x 30% + 1M x 25% + 3M x 20% + 6M x 15% + 12M x 10%. 2W/2M and Sector RS are optional components with zero default weight; Sector RS is included only when its weight is greater than 0.",
        "criteria_note": f"Metrics use the selected {timeframe} timeframe. For a detected VCP, Pivot = highest high of the final contraction; otherwise it is the recent consolidation high. Near Pivot = 95%-102% of pivot. Confirmed breakout requires close > pivot by 0.3%, volume >= 1.4x 50-period average, close > open, and close in the upper half of the period's range. VCP requires successive price-depth, ATR%, standard-deviation, and average-volume contractions."
    })


@router.get("/benchmark/{exchange}")
def get_benchmark(exchange: str, limit: int = 400, db: Session = Depends(get_db)):
    exchange = exchange.upper()
    if exchange not in {"US", "NSE", "BSE"}:
        raise HTTPException(status_code=400, detail="Unsupported exchange")

    points, ticker_symbol, benchmark_name, method = _load_benchmark_points(exchange, db=db)
    if points:
        values = [
            {"date": trade_date.isoformat(), "close": close_value}
            for trade_date, _open, _high, _low, close_value in points[-max(1, limit):]
        ]
        payload = {
            "name": benchmark_name,
            "symbol": ticker_symbol,
            "data": values,
            "method": method,
            "data_points": len(points),
            "first_date": points[0][0].isoformat(),
            "last_date": points[-1][0].isoformat(),
        }
        if method == "Stored benchmark fallback":
            payload["warning"] = f"Using stored {benchmark_name} history because the live benchmark feed is temporarily unavailable."
        return payload

    return {
        "name": benchmark_name,
        "symbol": ticker_symbol,
        "data": [],
        "warning": f"{benchmark_name} data is temporarily unavailable from both Yahoo benchmark paths and no stored benchmark cache is available yet.",
    }


@router.get("/chart/{symbol}")
def get_chart_data(
    symbol: str,
    exchange: str = "US",
    timeframe: str = Query("daily", pattern="^(daily|weekly|monthly)$"),
    limit: int = 260,
    db: Session = Depends(get_db)
):
    rows = _market_rows_with_live_fallback(
        db, symbol=symbol, exchange=exchange, min_rows=1, years=5
    )

    if not rows:
        raise HTTPException(status_code=404, detail="No verified market data is available for this symbol yet")

    data = [
        {
            "date": row.date,
            "open": row.open,
            "high": row.high,
            "low": row.low,
            "close": row.close,
            "volume": row.volume
        }
        for row in rows
    ]

    if timeframe == "daily":
        result = data

    else:
        import pandas as pd

        df = pd.DataFrame(data)
        df["date"] = pd.to_datetime(df["date"])
        df["actual_date"] = df["date"]
        df = df.set_index("date")

        rule = "W" if timeframe == "weekly" else "ME"

        df = df.resample(rule).agg({
            "open": "first",
            "high": "max",
            "low": "min",
            "close": "last",
            "volume": "sum",
            "actual_date": "last"
        }).dropna(subset=["open", "high", "low", "close"])

        df = df.reset_index(drop=True).rename(columns={"actual_date": "date"})

        result = df.to_dict(orient="records")

    return _json_safe({
        "symbol": symbol.upper(),
        "exchange": exchange.upper(),
        "timeframe": timeframe,
        "count": len(result[-limit:]),
        "data": result[-limit:]
    })

@router.post("/fundamentals/{symbol}")
def refresh_fundamentals(
    symbol: str,
    exchange: str = "US",
    db: Session = Depends(get_db)
):
    try:
        exchange = exchange.upper()
        if exchange not in {"US", "NSE", "BSE"}:
            raise HTTPException(status_code=400, detail="Unsupported exchange")

        # Repair exact NSE company identity before refreshing any related data.
        # This prevents stale name/ISIN metadata from surviving when the user
        # switches symbols and the provider response omits identity fields.
        if exchange == "NSE":
            try:
                repair_company_identity(db, symbol.upper(), exchange)
            except Exception:
                pass

        provider = YahooProvider()
        data = provider.get_fundamentals(symbol.upper(), exchange)

        # Use statement-derived ratios for ROE/ROA when available. This keeps
        # the snapshot consistent with the annual table and uses average balance
        # sheet denominators instead of an opaque provider summary ratio.
        try:
            history = provider.get_fundamental_history(symbol.upper(), exchange)
            latest_annual = (history.get("annual") or [None])[0]
            if latest_annual:
                if latest_annual.get("roe") is not None:
                    data["return_on_equity"] = latest_annual["roe"] / 100
                if latest_annual.get("roa") is not None:
                    data["return_on_assets"] = latest_annual["roa"] / 100
        except Exception:
            pass

        result = sync_fundamental_data(
            db=db,
            symbol=symbol.upper(),
            exchange=exchange,
            data=data
        )

        return {
            **result,
            "fundamentals": data
        }

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Fundamental refresh failed: {str(e)}"
        )

@router.get("/fundamentals/{symbol}")
def get_fundamentals(
    symbol: str,
    exchange: str = "US",
    db: Session = Depends(get_db)
):
    exchange = exchange.upper()
    symbol = symbol.upper()
    if exchange == "NSE":
        try:
            repair_company_identity(db, symbol, exchange)
        except Exception:
            pass

    fundamental = (
        db.query(Fundamental)
        .filter(
            Fundamental.symbol == symbol.upper(),
            Fundamental.exchange == exchange.upper()
        )
        .first()
    )

    ownership = (
        db.query(Ownership)
        .filter(
            Ownership.symbol == symbol.upper(),
            Ownership.exchange == exchange.upper()
        )
        .first()
    )

    company = (
        db.query(Company)
        .filter(Company.symbol == symbol.upper(), Company.exchange == exchange.upper())
        .first()
    )

    live = {}
    if _free_tier_mode() or not fundamental or not ownership or not company or not company.isin:
        try:
            live = YahooProvider().get_fundamentals(symbol, exchange) or {}
        except Exception:
            live = {}

    if not fundamental and not ownership and not live:
        raise HTTPException(status_code=404, detail="No fundamental data found")

    def pick(model, attr, live_key):
        value = getattr(model, attr, None) if model is not None else None
        return value if value is not None else live.get(live_key)

    name = company.name if company and company.name and company.name != symbol else live.get("name")
    isin = company.isin if company and company.isin else live.get("isin")
    # Exact fallback already verified for the client's recurring INFY identity.
    if exchange == "NSE" and symbol == "INFY":
        name = "Infosys Limited"
        isin = "INE009A01021"

    return {
        "symbol": symbol.upper(),
        "name": name,
        "isin": isin,
        "exchange": exchange.upper(),
        "fundamentals": {
            "market_cap": pick(fundamental, "market_cap", "market_cap"),
            "trailing_eps": pick(fundamental, "trailing_eps", "trailing_eps"),
            "forward_eps": pick(fundamental, "forward_eps", "forward_eps"),
            "revenue": pick(fundamental, "revenue", "revenue"),
            "net_income": pick(fundamental, "net_income", "net_income"),
            "profit_margin": pick(fundamental, "profit_margin", "profit_margin"),
            "return_on_equity": pick(fundamental, "return_on_equity", "return_on_equity"),
            "return_on_assets": pick(fundamental, "return_on_assets", "return_on_assets"),
        },
        "ownership": {
            "insider_percent": pick(ownership, "insider_percent", "insider_percent"),
            "institution_percent": pick(ownership, "institution_percent", "institution_percent"),
            "shares_outstanding": pick(ownership, "shares_outstanding", "shares_outstanding"),
            "float_shares": pick(ownership, "float_shares", "float_shares"),
        }
    }

@router.get("/fundamentals-history/{symbol}")
def get_fundamentals_history(
    symbol: str,
    exchange: str = "US"
):
    try:
        exchange = exchange.upper()
        if exchange not in {"US", "NSE", "BSE"}:
            raise HTTPException(status_code=400, detail="Unsupported exchange")

        provider = YahooProvider()

        data = provider.get_fundamental_history(
            symbol.upper(), exchange
        )

        return data

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Fundamental history failed: {str(e)}"
        )

@router.get("/indicators/{symbol}")
def get_indicators(
    symbol: str,
    exchange: str = "US",
    timeframe: str = "daily",
    sma_short: int = 20,
    sma_long: int = 50,
    rsi_period: int = 14,
    db: Session = Depends(get_db)
):
    rows = _market_rows_with_live_fallback(
        db, symbol=symbol, exchange=exchange, min_rows=20, years=5
    )

    if not rows:
        raise HTTPException(
            status_code=404,
            detail="No historical data found"
        )

    timeframe = timeframe.lower()

    # Build closes for selected timeframe
    if timeframe == "daily":
        closes = [float(r.close) for r in rows]

    elif timeframe == "weekly":
        weekly = {}

        for r in rows:
            # ISO year + ISO week prevents week-number collisions across years
            iso = r.date.isocalendar()
            key = (iso.year, iso.week)
            weekly[key] = float(r.close)

        closes = list(weekly.values())

    elif timeframe == "monthly":
        monthly = {}

        for r in rows:
            key = (r.date.year, r.date.month)
            monthly[key] = float(r.close)

        closes = list(monthly.values())

    else:
        raise HTTPException(
            status_code=400,
            detail="Timeframe must be daily, weekly, or monthly"
        )

    minimum_required = max(
        sma_short,
        sma_long,
        rsi_period + 1
    )

    if len(closes) < minimum_required:
        raise HTTPException(
            status_code=404,
            detail=f"Not enough {timeframe} historical data for selected indicator settings"
        )

    # SMA
    sma_short_value = sum(closes[-sma_short:]) / sma_short
    sma_long_value = sum(closes[-sma_long:]) / sma_long

    # EMA
    def calculate_ema(values, period):
        multiplier = 2 / (period + 1)

        ema = sum(values[:period]) / period

        for price in values[period:]:
            ema = ((price - ema) * multiplier) + ema

        return ema

    ema_short_value = calculate_ema(closes, sma_short)
    ema_long_value = calculate_ema(closes, sma_long)
    ema_150_value = calculate_ema(closes, 150) if len(closes) >= 150 else None
    ema_200_value = calculate_ema(closes, 200) if len(closes) >= 200 else None

    # RSI
    changes = [
        closes[i] - closes[i - 1]
        for i in range(1, len(closes))
    ]

    gains = [max(change, 0) for change in changes]
    losses = [max(-change, 0) for change in changes]

    def calculate_rma(values, period):
        rma = sum(values[:period]) / period
        alpha = 1 / period

        for value in values[period:]:
            rma = (alpha * value) + ((1 - alpha) * rma)

        return rma

    avg_gain = calculate_rma(gains, rsi_period)
    avg_loss = calculate_rma(losses, rsi_period)

    if avg_loss == 0:
        rsi_value = 100
    else:
        rs = avg_gain / avg_loss
        rsi_value = 100 - (100 / (1 + rs))

    return {
        "symbol": symbol.upper(),
        "exchange": exchange.upper(),
        "timeframe": timeframe,
        "settings": {
            "sma_short": sma_short,
            "sma_long": sma_long,
            "rsi_period": rsi_period
        },
        "sma_short": round(sma_short_value, 2),
        "sma_long": round(sma_long_value, 2),
        "ema_short": round(ema_short_value, 2),
        "ema_long": round(ema_long_value, 2),
        "ema_150": round(ema_150_value, 2) if ema_150_value is not None else None,
        "ema_200": round(ema_200_value, 2) if ema_200_value is not None else None,
        "rsi": round(rsi_value, 2)
    }

# ---------------------------------------------------------------------------
# Universe screener: stored-data-first list view + filtered Excel export.
# This powers the client's requested "many stocks in one table" workflow.
# It intentionally uses only data already stored in this application's DB.
# Missing fields stay N/A; no synthetic fundamentals/ownership values are made.
# ---------------------------------------------------------------------------

SCREENER_COLUMN_LABELS = {
    "symbol": "Symbol",
    "name": "Company",
    "isin": "ISIN",
    "exchange": "Exchange",
    "sector": "Sector",
    "industry": "Industry",
    "close": "LTP",
    "volume": "Volume",
    "market_cap": "Market Cap",
    "trailing_eps": "EPS",
    "forward_eps": "Forward EPS",
    "revenue": "Revenue",
    "net_income": "Net Income",
    "profit_margin": "Profit Margin %",
    "return_on_equity": "ROE %",
    "return_on_assets": "ROA %",
    "institution_percent": "Institution %",
    "insider_percent": "Insider %",
    "shares_outstanding": "Shares Outstanding",
    "float_shares": "Float Shares",
    "distance_52w_high": "Distance From 52W High %",
    "distance_52w_low": "Distance From 52W Low %",
    "volume_ratio": "Volume / 52W Avg",
    "latest_date": "Latest Price Date",
    "data_coverage": "Data Coverage %",
}

SCREENER_DEFAULT_COLUMNS = [
    "symbol", "name", "isin", "exchange", "close", "market_cap", "trailing_eps",
    "profit_margin", "return_on_equity", "institution_percent",
    "distance_52w_high", "volume_ratio", "data_coverage",
]


def _screener_market_exchanges(market: str):
    market = (market or "ALL").upper()
    if market == "US":
        return ["US"]
    if market in {"INDIA", "IN"}:
        return ["NSE", "BSE"]
    if market == "NSE":
        return ["NSE"]
    if market == "BSE":
        return ["BSE"]
    return ["US", "NSE", "BSE"]


def _screener_query_parts(db: Session, market: str):
    exchanges = _screener_market_exchanges(market)
    latest_dates = (
        db.query(
            OHLCV.symbol.label("symbol"),
            OHLCV.exchange.label("exchange"),
            func.max(OHLCV.date).label("max_date"),
        )
        .filter(OHLCV.exchange.in_(exchanges))
        .group_by(OHLCV.symbol, OHLCV.exchange)
        .subquery()
    )
    latest = aliased(OHLCV)
    cutoff = date.today() - timedelta(days=370)
    year_stats = (
        db.query(
            OHLCV.symbol.label("symbol"),
            OHLCV.exchange.label("exchange"),
            func.max(OHLCV.high).label("high_52w"),
            func.min(OHLCV.low).label("low_52w"),
            func.avg(OHLCV.volume).label("avg_volume_52w"),
        )
        .filter(OHLCV.exchange.in_(exchanges), OHLCV.date >= cutoff)
        .group_by(OHLCV.symbol, OHLCV.exchange)
        .subquery()
    )

    distance_high = case(
        (year_stats.c.high_52w > 0, ((year_stats.c.high_52w - latest.close) / year_stats.c.high_52w) * 100.0),
        else_=None,
    )
    distance_low = case(
        (year_stats.c.low_52w > 0, ((latest.close - year_stats.c.low_52w) / year_stats.c.low_52w) * 100.0),
        else_=None,
    )
    volume_ratio = case(
        (year_stats.c.avg_volume_52w > 0, latest.volume / year_stats.c.avg_volume_52w),
        else_=None,
    )

    # Prefer rows with useful real data instead of filling the first page with
    # N/A-only listings.  This is a completeness indicator only; it never
    # substitutes or estimates a missing value.
    data_points = (
        case((latest.close.isnot(None), 1), else_=0)
        + case((Fundamental.market_cap.isnot(None), 1), else_=0)
        + case((Fundamental.trailing_eps.isnot(None), 1), else_=0)
        + case((Fundamental.revenue.isnot(None), 1), else_=0)
        + case((Fundamental.net_income.isnot(None), 1), else_=0)
        + case((Fundamental.profit_margin.isnot(None), 1), else_=0)
        + case((Fundamental.return_on_equity.isnot(None), 1), else_=0)
        + case((Ownership.institution_percent.isnot(None), 1), else_=0)
        + case((or_(Company.sector.isnot(None), Company.industry.isnot(None)), 1), else_=0)
    )
    data_coverage = (data_points * 100.0 / 9.0)

    query = (
        db.query(
            Company.symbol.label("symbol"),
            Company.name.label("name"),
            Company.isin.label("isin"),
            Company.exchange.label("exchange"),
            Company.sector.label("sector"),
            Company.industry.label("industry"),
            latest.close.label("close"),
            latest.volume.label("volume"),
            latest.date.label("latest_date"),
            Fundamental.market_cap.label("market_cap"),
            Fundamental.trailing_eps.label("trailing_eps"),
            Fundamental.forward_eps.label("forward_eps"),
            Fundamental.revenue.label("revenue"),
            Fundamental.net_income.label("net_income"),
            Fundamental.profit_margin.label("profit_margin"),
            Fundamental.return_on_equity.label("return_on_equity"),
            Fundamental.return_on_assets.label("return_on_assets"),
            Ownership.institution_percent.label("institution_percent"),
            Ownership.insider_percent.label("insider_percent"),
            Ownership.shares_outstanding.label("shares_outstanding"),
            Ownership.float_shares.label("float_shares"),
            distance_high.label("distance_52w_high"),
            distance_low.label("distance_52w_low"),
            volume_ratio.label("volume_ratio"),
            data_coverage.label("data_coverage"),
        )
        .outerjoin(Fundamental, (Fundamental.symbol == Company.symbol) & (Fundamental.exchange == Company.exchange))
        .outerjoin(Ownership, (Ownership.symbol == Company.symbol) & (Ownership.exchange == Company.exchange))
        .outerjoin(latest_dates, (latest_dates.c.symbol == Company.symbol) & (latest_dates.c.exchange == Company.exchange))
        .outerjoin(latest, (latest.symbol == Company.symbol) & (latest.exchange == Company.exchange) & (latest.date == latest_dates.c.max_date))
        .outerjoin(year_stats, (year_stats.c.symbol == Company.symbol) & (year_stats.c.exchange == Company.exchange))
        .filter(Company.is_active == 1, Company.exchange.in_(exchanges))
    )
    # Defensive query-time equity filter: even if a provider sync is delayed,
    # legacy US warrants/units/SPAC rows cannot leak into the normal screener.
    query = apply_eligible_equity_filter(query, exchanges)

    expressions = {
        "symbol": Company.symbol,
        "name": Company.name,
        "isin": Company.isin,
        "exchange": Company.exchange,
        "sector": Company.sector,
        "industry": Company.industry,
        "close": latest.close,
        "volume": latest.volume,
        "market_cap": Fundamental.market_cap,
        "trailing_eps": Fundamental.trailing_eps,
        "forward_eps": Fundamental.forward_eps,
        "revenue": Fundamental.revenue,
        "net_income": Fundamental.net_income,
        "profit_margin": Fundamental.profit_margin,
        "return_on_equity": Fundamental.return_on_equity,
        "return_on_assets": Fundamental.return_on_assets,
        "institution_percent": Ownership.institution_percent,
        "insider_percent": Ownership.insider_percent,
        "shares_outstanding": Ownership.shares_outstanding,
        "float_shares": Ownership.float_shares,
        "distance_52w_high": distance_high,
        "distance_52w_low": distance_low,
        "volume_ratio": volume_ratio,
        "latest_date": latest.date,
        "data_coverage": data_coverage,
    }
    return query, expressions


def _apply_screener_filters(
    query,
    expressions,
    q=None,
    sector=None,
    industry=None,
    market_cap_min=None,
    market_cap_max=None,
    eps_min=None,
    revenue_min=None,
    net_income_min=None,
    roe_min=None,
    roa_min=None,
    profit_margin_min=None,
    institution_min=None,
    insider_min=None,
    close_min=None,
    close_max=None,
    distance_52w_high_max=None,
    distance_52w_low_max=None,
    volume_ratio_min=None,
):
    if q:
        pattern = f"%{q.strip()}%"
        query = query.filter(or_(Company.symbol.ilike(pattern), Company.name.ilike(pattern), Company.isin.ilike(pattern)))
    if sector:
        query = query.filter(Company.sector == sector)
    if industry:
        query = query.filter(Company.industry == industry)
    bounds = [
        ("market_cap", market_cap_min, market_cap_max),
        ("close", close_min, close_max),
    ]
    for key, lower, upper in bounds:
        expr = expressions[key]
        if lower is not None:
            query = query.filter(expr >= lower)
        if upper is not None:
            query = query.filter(expr <= upper)
    # UI percent filters are entered as percentage points (20 means 20%),
    # while provider fundamentals/ownership are stored as fractions (0.20).
    minimums = [
        ("trailing_eps", eps_min),
        ("revenue", revenue_min),
        ("net_income", net_income_min),
        ("return_on_equity", None if roe_min is None else roe_min / 100.0),
        ("return_on_assets", None if roa_min is None else roa_min / 100.0),
        ("profit_margin", None if profit_margin_min is None else profit_margin_min / 100.0),
        ("institution_percent", None if institution_min is None else institution_min / 100.0),
        ("insider_percent", None if insider_min is None else insider_min / 100.0),
        ("volume_ratio", volume_ratio_min),
    ]
    for key, value in minimums:
        if value is not None:
            query = query.filter(expressions[key] >= value)
    if distance_52w_high_max is not None:
        query = query.filter(expressions["distance_52w_high"] <= distance_52w_high_max)
    if distance_52w_low_max is not None:
        query = query.filter(expressions["distance_52w_low"] <= distance_52w_low_max)
    return query


def _screener_row_dict(row):
    data = {}
    for key in SCREENER_COLUMN_LABELS:
        value = getattr(row, key, None)
        if isinstance(value, (datetime, date)):
            value = value.isoformat()
        elif isinstance(value, float) and not math.isfinite(value):
            value = None
        data[key] = value
    return data


def _screener_facets(db: Session, market: str):
    exchanges = _screener_market_exchanges(market)

    sector_query = (
        db.query(Company.sector)
        .filter(
            Company.is_active == 1,
            Company.exchange.in_(exchanges),
            Company.sector.isnot(None),
            Company.sector != "",
        )
    )
    sector_query = apply_eligible_equity_filter(sector_query, exchanges)
    sectors = [
        value for (value,) in sector_query.distinct().order_by(Company.sector.asc()).all() if value
    ]

    industry_query = (
        db.query(Company.industry)
        .filter(
            Company.is_active == 1,
            Company.exchange.in_(exchanges),
            Company.industry.isnot(None),
            Company.industry != "",
        )
    )
    industry_query = apply_eligible_equity_filter(industry_query, exchanges)
    industries = [
        value for (value,) in industry_query.distinct().order_by(Company.industry.asc()).all() if value
    ]
    return {"sectors": sectors[:500], "industries": industries[:1000]}




@router.get("/sector-analysis")
def get_sector_analysis(
    market: str = "ALL",
    sector: str | None = None,
    db: Session = Depends(get_db),
):
    """Stored-provider sector analysis for the Milestone-2 sector view.

    Current snapshot metrics are aggregated with medians. Historical growth /
    acceleration scores are deliberately left unavailable unless peer history
    exists; no growth score is fabricated from a current snapshot.
    """
    query, _ = _screener_query_parts(db, market)
    if sector:
        query = query.filter(Company.sector == sector)
    rows = query.all()

    groups = {}
    for row in rows:
        name = (getattr(row, "sector", None) or "Unclassified").strip()
        bucket = groups.setdefault(name, {
            "sector": name, "stock_count": 0, "classified_count": 0,
            "eps": [], "pat": [], "sales": [], "margin": [], "roe": [],
            "institution": [], "insider": [], "coverage": [],
        })
        bucket["stock_count"] += 1
        if name != "Unclassified":
            bucket["classified_count"] += 1
        for key, attr in [
            ("eps", "trailing_eps"), ("pat", "net_income"), ("sales", "revenue"),
            ("margin", "profit_margin"), ("roe", "return_on_equity"),
            ("institution", "institution_percent"), ("insider", "insider_percent"),
            ("coverage", "data_coverage"),
        ]:
            value = getattr(row, attr, None)
            try:
                value = float(value)
                if math.isfinite(value):
                    bucket[key].append(value)
            except (TypeError, ValueError):
                pass

    def med(values):
        return float(median(values)) if values else None

    output = []
    for name, bucket in groups.items():
        output.append({
            "sector": name,
            "stock_count": bucket["stock_count"],
            "median_eps": med(bucket["eps"]),
            "median_pat": med(bucket["pat"]),
            "median_sales": med(bucket["sales"]),
            "median_profit_margin": med(bucket["margin"]),
            "median_roe": med(bucket["roe"]),
            "median_institution_percent": med(bucket["institution"]),
            "median_insider_percent": med(bucket["insider"]),
            "data_coverage_percent": med(bucket["coverage"]),
            # The client's sector formula needs historical peer growth series.
            # Do not substitute current EPS/PAT/Sales levels for growth ranks.
            "eps_growth_rs": None,
            "pat_growth_rs": None,
            "sales_growth_rs": None,
            "growth_acceleration_rs": None,
            "growth_breadth": None,
            "acceleration_breadth": None,
            "sector_rs_score": None,
            "history_status": "Peer historical fundamentals required" if name != "Unclassified" else "Classification unavailable",
        })

    output.sort(key=lambda item: (-(item.get("data_coverage_percent") or -1), -item["stock_count"], item["sector"]))
    return _json_safe({
        "market": market.upper(),
        "sector": sector,
        "rows": output,
        "formula": "EPS Growth RS 30% + PAT Growth RS 25% + Sales Growth RS 20% + Growth Acceleration RS 15% + Growth Breadth 5% + Acceleration Breadth 5%",
        "aggregation": "Median stock growth by sector, per client note.",
        "data_rule": "Current snapshot medians are real stored provider values. Historical growth-ranking fields remain N/A until real peer history is available; they are never fabricated.",
    })


@router.get("/top-composite")
def get_top_composite_dashboard(
    market: str = "ALL",
    limit: int = Query(200, ge=20, le=200),
    candidate_limit: int = Query(700, ge=200, le=1200),
    technical_weight: float = Query(25.0, ge=0),
    fundamental_weight: float = Query(30.0, ge=0),
    ownership_weight: float = Query(15.0, ge=0),
    sector_weight: float = Query(5.0, ge=0),
    relative_strength_weight: float = Query(25.0, ge=0),
    db: Session = Depends(get_db),
):
    """Front-dashboard ranking using verified stored data only.

    This path intentionally avoids the much heavier generic screener query,
    which calculates 52-week aggregates for the entire universe.  The dashboard
    does not use those fields, so scanning them made the Top-200 request prone
    to timeouts on Railway as the database grew.

    Candidate metadata is selected with a lightweight company/fundamental/
    ownership query.  Price history is then streamed only for those candidates
    and only for the period needed by the dashboard calculations.
    """
    exchanges = _screener_market_exchanges(market)
    if _free_tier_mode():
        # Keep the live provider batch bounded on Railway's 500 MB tier.
        candidate_limit = min(int(candidate_limit), 220)


    # The client asked for editable top-level composite weights.  Accept the
    # entered values directly and normalize them to 100% so any non-negative
    # combination remains usable while preserving the relative proportions.
    requested_weights = {
        "technical": float(technical_weight or 0),
        "fundamental": float(fundamental_weight or 0),
        "ownership": float(ownership_weight or 0),
        "sector": float(sector_weight or 0),
        "relative_strength": float(relative_strength_weight or 0),
    }
    entered_weight_total = sum(max(0.0, value) for value in requested_weights.values())
    if entered_weight_total <= 0:
        raise HTTPException(status_code=400, detail="At least one composite weight must be greater than 0.")
    weights = {
        key: (max(0.0, value) / entered_weight_total) * 100.0
        for key, value in requested_weights.items()
    }

    def _weight_text(value):
        rounded = round(float(value), 2)
        return str(int(rounded)) if rounded.is_integer() else f"{rounded:g}"

    formula_text = (
        f"Technical {_weight_text(weights['technical'])}% + "
        f"Fundamental {_weight_text(weights['fundamental'])}% + "
        f"Ownership {_weight_text(weights['ownership'])}% + "
        f"Sector {_weight_text(weights['sector'])}% + "
        f"RS {_weight_text(weights['relative_strength'])}%"
    )

    # Lightweight candidate coverage score.  Do not join the all-universe
    # 52-week aggregate subquery used by /screener; Top-200 does not need it.
    candidate_points = (
        case((Fundamental.market_cap.isnot(None), 1), else_=0)
        + case((Fundamental.trailing_eps.isnot(None), 1), else_=0)
        + case((Fundamental.revenue.isnot(None), 1), else_=0)
        + case((Fundamental.net_income.isnot(None), 1), else_=0)
        + case((Fundamental.profit_margin.isnot(None), 1), else_=0)
        + case((Fundamental.return_on_equity.isnot(None), 1), else_=0)
        + case((Ownership.institution_percent.isnot(None), 1), else_=0)
        + case((Ownership.insider_percent.isnot(None), 1), else_=0)
        + case((or_(Company.sector.isnot(None), Company.industry.isnot(None)), 1), else_=0)
    )
    candidate_coverage = candidate_points * 100.0 / 9.0

    query = (
        db.query(
            Company.symbol.label("symbol"),
            Company.name.label("name"),
            Company.isin.label("isin"),
            Company.exchange.label("exchange"),
            Company.sector.label("sector"),
            Company.industry.label("industry"),
            Fundamental.market_cap.label("market_cap"),
            Fundamental.trailing_eps.label("trailing_eps"),
            Fundamental.forward_eps.label("forward_eps"),
            Fundamental.revenue.label("revenue"),
            Fundamental.net_income.label("net_income"),
            Fundamental.profit_margin.label("profit_margin"),
            Fundamental.return_on_equity.label("return_on_equity"),
            Fundamental.return_on_assets.label("return_on_assets"),
            Ownership.institution_percent.label("institution_percent"),
            Ownership.insider_percent.label("insider_percent"),
            Ownership.shares_outstanding.label("shares_outstanding"),
            Ownership.float_shares.label("float_shares"),
            candidate_coverage.label("data_coverage"),
        )
        .outerjoin(
            Fundamental,
            (Fundamental.symbol == Company.symbol)
            & (Fundamental.exchange == Company.exchange),
        )
        .outerjoin(
            Ownership,
            (Ownership.symbol == Company.symbol)
            & (Ownership.exchange == Company.exchange),
        )
        .filter(Company.is_active == 1, Company.exchange.in_(exchanges))
    )
    query = apply_eligible_equity_filter(query, exchanges)
    candidates = (
        query.order_by(
            candidate_coverage.desc(),
            Fundamental.market_cap.desc().nullslast(),
            Company.symbol.asc(),
        )
        .limit(candidate_limit)
        .all()
    )

    base_rows = [_screener_row_dict(row) for row in candidates]
    if not base_rows:
        return {
            "market": market.upper(),
            "rows": [],
            "candidate_count": 0,
            "formula": formula_text,
            "score_weights": {key: round(value, 2) for key, value in weights.items()},
            "entered_weight_total": round(entered_weight_total, 2),
            "data_rule": "Verified stored data only; missing values remain N/A.",
        }

    by_exchange = {}
    for row in base_rows:
        ex = row.get("exchange") or ""
        symbol = row.get("symbol")
        if symbol:
            by_exchange.setdefault(ex, []).append(symbol)

    # 400 calendar days safely covers the 252-trading-day 1Y window.
    grouped = {}
    if not _free_tier_mode():
        # Larger-volume mode can use the persisted OHLCV cache.
        cutoff = date.today() - timedelta(days=400)
        history_chunk_size = 150
        for ex, symbols in by_exchange.items():
            for offset in range(0, len(symbols), history_chunk_size):
                chunk = symbols[offset:offset + history_chunk_size]
                price_rows = (
                    db.query(OHLCV.symbol, OHLCV.close)
                    .filter(
                        OHLCV.exchange == ex,
                        OHLCV.symbol.in_(chunk),
                        OHLCV.date >= cutoff,
                        OHLCV.close.isnot(None),
                    )
                    .order_by(OHLCV.symbol.asc(), OHLCV.date.asc())
                    .yield_per(5000)
                )
                for item in price_rows:
                    try:
                        close = float(item.close)
                    except (TypeError, ValueError):
                        continue
                    if not math.isfinite(close) or close <= 0:
                        continue
                    grouped.setdefault((ex, item.symbol), []).append(close)
    else:
        # Free-tier mode reads bounded candidate history directly from Yahoo
        # and never writes the multi-million-row OHLCV universe back to DB.
        grouped.update(_live_close_history_for_candidates(base_rows))

    def technical_score(closes):
        if not closes or len(closes) < 20:
            return None
        latest = closes[-1]
        values = []
        for period in (20, 50, 150, 200):
            if len(closes) >= period:
                ema = _ema(closes, period)
                if ema is not None:
                    values.append(100.0 if latest > ema else 0.0)
        rsi = _rsi(closes, 14) if len(closes) >= 15 else None
        if rsi is not None:
            values.append(
                100.0 if 50 <= rsi <= 70
                else 50.0 if (40 <= rsi < 50 or 70 < rsi <= 80)
                else 0.0
            )
        return round(sum(values) / len(values), 2) if values else None

    def ownership_score(row):
        values = []
        inst = row.get("institution_percent")
        insider = row.get("insider_percent")
        if inst is not None:
            try:
                x = float(inst)
                x = x * 100 if x <= 1 else x
                values.append((max(0.0, min(100.0, x)), 70.0))
            except Exception:
                pass
        if insider is not None:
            try:
                x = float(insider)
                x = x * 100 if x <= 1 else x
                values.append((max(0.0, min(100.0, x * 5.0)), 30.0))
            except Exception:
                pass
        total = sum(weight for _, weight in values)
        return (
            round(sum(value * weight for value, weight in values) / total, 2)
            if total else None
        )

    periods = {"1w": 5, "1m": 21, "3m": 63, "6m": 126, "1y": 252}
    period_weights = {"1w": 30.0, "1m": 25.0, "3m": 20.0, "6m": 15.0, "1y": 10.0}
    raw_returns = {}
    peers_by_group = {
        "US": {key: [] for key in periods},
        "INDIA": {key: [] for key in periods},
    }
    for row in base_rows:
        key = (row.get("exchange"), row.get("symbol"))
        closes = grouped.get(key, [])
        values = {}
        for label, days in periods.items():
            if len(closes) > days and closes[-1 - days] not in (None, 0):
                values[label] = ((closes[-1] / closes[-1 - days]) - 1.0) * 100.0
        raw_returns[key] = values
        group = "US" if row.get("exchange") == "US" else "INDIA"
        for label, value in values.items():
            peers_by_group[group][label].append(value)

    # First compute the inexpensive market-based components for the full bounded
    # candidate set.  We then enrich only the strongest live candidates with
    # real historical statements/metadata so the 500 MB deployment does not
    # perform an 11,500-stock statement crawl on every request.
    preliminary = []
    preliminary_by_key = {}
    for row in base_rows:
        ex, symbol = row.get("exchange"), row.get("symbol")
        closes = grouped.get((ex, symbol), [])
        technical = technical_score(closes)
        ownership = ownership_score(row)
        group = "US" if ex == "US" else "INDIA"
        rs_points = []
        rs_weight = 0.0
        for label, weight in period_weights.items():
            value = raw_returns.get((ex, symbol), {}).get(label)
            peers = peers_by_group[group][label]
            percentile = _percentile_rank(peers, value) if value is not None and peers else None
            if percentile is not None:
                rs_points.append(percentile * weight)
                rs_weight += weight
        rs = round(sum(rs_points) / rs_weight, 2) if rs_weight else None
        simple = {"technical": technical, "ownership": ownership, "relative_strength": rs}
        simple_weight = sum(weights[k] for k, v in simple.items() if v is not None)
        pre_score = (
            sum(simple[k] * weights[k] for k in simple if simple[k] is not None) / simple_weight
            if simple_weight else -1
        )
        key = (str(ex or "").upper(), str(symbol or "").upper())
        item = {"row": row, "technical": technical, "ownership": ownership, "rs": rs, "pre_score": pre_score}
        preliminary.append(item)
        preliminary_by_key[key] = item

    preliminary.sort(key=lambda item: (-(item.get("pre_score") or -1), str((item.get("row") or {}).get("symbol") or "")))
    enrichment_rows = [item["row"] for item in preliminary]
    enrichment = {}
    enrichment_remaining = []
    if _free_tier_mode():
        # Load the compact persisted cache first. This survives Railway restarts
        # and means Top 200 can return quickly instead of repeating dozens of
        # statement-provider calls inside one HTTP request.
        enrichment.update(_load_persisted_ranking_enrichment(enrichment_rows))
        enrichment.update(_apply_cached_ranking_enrichment(enrichment_rows))

        missing_rows = []
        for candidate_row in enrichment_rows:
            candidate_key = (
                str(candidate_row.get("exchange") or "").upper(),
                str(candidate_row.get("symbol") or "").upper(),
            )
            if candidate_key not in enrichment:
                missing_rows.append(candidate_row)

        # Only a small first batch is synchronous. The old 50-stock cold fetch
        # could exceed the browser/Railway timeout and forced the UI back to an
        # older cached dashboard. The remainder is warmed and persisted by a
        # daemon worker, so later refreshes gain coverage without growing OHLCV.
        try:
            sync_limit = int(os.getenv("TOP200_SYNC_ENRICH_LIMIT", "20") or 20)
        except Exception:
            sync_limit = 20
        # Enrich enough leading candidates synchronously that the first visible
        # ranking page is not dominated by low-coverage rows. Keep the cap
        # bounded for the Railway free tier; remaining candidates continue in
        # the background/persisted cache.
        sync_limit = max(0, min(30, sync_limit))
        if missing_rows and sync_limit > 0:
            enrichment.update(_apply_ranking_enrichment(missing_rows, limit=sync_limit))
            enrichment.update(_apply_cached_ranking_enrichment(enrichment_rows))

        enrichment_remaining = []
        for candidate_row in enrichment_rows[:200]:
            candidate_key = (
                str(candidate_row.get("exchange") or "").upper(),
                str(candidate_row.get("symbol") or "").upper(),
            )
            if candidate_key not in enrichment:
                enrichment_remaining.append(candidate_row)
        _warm_ranking_enrichment_background(enrichment_remaining)
    sector_stats = _sector_scores_from_enriched(enrichment_rows, enrichment) if enrichment else {}

    # Alpha/Beta use real daily return series versus the client's exact broad
    # market benchmark.  No extra database storage is required.
    benchmark_closes = {}
    for ex in {str(row.get("exchange") or "").upper() for row in base_rows}:
        group_key = "US" if ex == "US" else "INDIA"
        if group_key in benchmark_closes:
            continue
        benchmark_closes[group_key] = _live_benchmark_closes(group_key)
        if benchmark_closes[group_key]:
            continue
        try:
            bench_exchange = "US" if group_key == "US" else "NSE"
            points, _bsym, _bname, _bmethod = _load_benchmark_points(bench_exchange, db=db, minimum_points=60)
            benchmark_closes[group_key] = [float(point[4]) for point in points if len(point) >= 5 and _finite_number(point[4]) is not None]
        except Exception:
            benchmark_closes[group_key] = []

    ranked = []
    for row in base_rows:
        ex, symbol = row.get("exchange"), row.get("symbol")
        key = (str(ex or "").upper(), str(symbol or "").upper())
        closes = grouped.get((ex, symbol), [])
        pre = preliminary_by_key.get(key) or {}
        technical = pre.get("technical")
        rs = pre.get("rs")

        payload = enrichment.get(key) or {}
        # Metadata enrichment may have filled ownership fields after the first
        # pass, so calculate ownership again from the now-complete row.
        ownership = ownership_score(row)
        fundamental = payload.get("fundamental_score")
        eps_score = payload.get("eps_score")
        pat_score = payload.get("pat_score")
        sales_score = payload.get("sales_score")

        sector_name = str(row.get("sector") or "").strip()
        sector_info = sector_stats.get(sector_name) or {}
        sector = sector_info.get("score")

        group_key = "US" if ex == "US" else "INDIA"
        alpha, beta = _alpha_beta_from_closes(closes, benchmark_closes.get(group_key) or [])
        standard_deviation_percent = _standard_deviation_percent_from_closes(closes)

        components = {
            "technical": technical,
            "fundamental": fundamental,
            "ownership": ownership,
            "sector": sector,
            "relative_strength": rs,
        }
        available_weight = sum(
            weights[key_name] for key_name, value in components.items() if value is not None
        )
        provisional = None
        if available_weight > 0:
            # IMPORTANT: do not renormalize away missing categories. Doing so
            # allowed a 55%-coverage row (Technical + Ownership + RS only) to
            # display a 90+ provisional score and outrank rows that actually
            # had Fundamental/Sector data. Missing categories remain N/A and
            # simply do not earn their configured weight. Because `weights`
            # are already normalized to 100, this score is naturally bounded
            # by coverage (e.g. a 55%-coverage row cannot score above 55).
            provisional = round(
                sum(
                    components[key_name] * weights[key_name]
                    for key_name in components
                    if components[key_name] is not None
                ) / 100.0,
                2,
            )

        # The bounded live peer set materially improves real data coverage, but
        # it is still not the client's complete 5,000-stock historical
        # ranking universe.  Therefore free-tier rows remain explicitly
        # Provisional even when every displayed component is populated.
        all_required_available = all(
            components.get(key_name) is not None
            for key_name, weight in weights.items()
            if float(weight or 0) > 0
        )
        exact_history_available = (
            _finite_number(payload.get("fundamental_rule_coverage")) is not None
            and float(payload.get("fundamental_rule_coverage") or 0) >= 99.9
            and int(sector_info.get("peer_count") or 0) >= 5
        )
        final_allowed = all_required_available and exact_history_available and not _free_tier_mode()
        final_composite = provisional if final_allowed else None
        ranked.append({
            **row,
            "composite_score": provisional,
            "final_composite_score": final_composite,
            "provisional_composite_score": provisional,
            "score_status": "Final" if final_composite is not None else "Provisional",
            "score_coverage_percent": round(available_weight, 2),
            "technical_score": technical,
            "fundamental_score": fundamental,
            "fundamental_rule_coverage_percent": payload.get("fundamental_rule_coverage"),
            "fundamental_status": (
                "Confirmed EPS/PAT/Sales handwritten growth rules; NPM/CFO points remain excluded until exact client weights are confirmed"
                if fundamental is not None else None
            ),
            "ownership_score": ownership,
            "sector_score": sector,
            "sector_peer_count": sector_info.get("peer_count"),
            "sector_status": "Provisional bounded real-history peer ranking" if sector is not None else None,
            "rs_score": rs,
            "eps_score": eps_score,
            "pat_score": pat_score,
            "sales_score": sales_score,
            "eps_rule_coverage_percent": payload.get("eps_rule_coverage"),
            "pat_rule_coverage_percent": payload.get("pat_rule_coverage"),
            "sales_rule_coverage_percent": payload.get("sales_rule_coverage"),
            "alpha": alpha,
            "beta": beta,
            "standard_deviation_percent": standard_deviation_percent,
        })

    ranked = [
        row for row in ranked
        if row.get("provisional_composite_score") is not None
    ]
    ranked.sort(
        key=lambda row: (
            -(row.get("composite_score") or -1),
            -(row.get("score_coverage_percent") or 0),
            str(row.get("symbol") or ""),
        )
    )
    rows = ranked[:limit]
    for index, row in enumerate(rows, start=1):
        row["rank"] = index

    return _json_safe({
        "market": market.upper(),
        "rows": rows,
        "candidate_count": len(base_rows),
        "formula": formula_text,
        "score_weights": {key: round(value, 2) for key, value in weights.items()},
        "entered_weight_total": round(entered_weight_total, 2),
        "rs_note": "RS percentiles on this dashboard use the bounded live candidate peer set and remain provisional until the full client 5,000-stock market universe is populated.",
        "data_rule": "The free-tier dashboard uses a compact persisted real-provider enrichment cache for statement history, sector metadata and EPS/PAT/Sales handwritten-rule scores, while price history remains live and is never stored as a huge universe cache. Missing provider values remain N/A. Fundamental excludes ambiguous NPM/CFO point allocations, and sector/RS peer ranks remain Provisional until the full client universe is available.",
        "enrichment_cached_count": len(enrichment) if _free_tier_mode() else len(base_rows),
        "enrichment_target_count": min(200, len(enrichment_rows)),
        "enrichment_remaining_count": len(enrichment_remaining) if _free_tier_mode() else 0,
        "enrichment_in_progress": bool(enrichment_remaining) if _free_tier_mode() else False,
        "sync_enrichment_limit": int(os.getenv("TOP200_SYNC_ENRICH_LIMIT", "20") or 20) if _free_tier_mode() else 0,
    })


@router.get("/screener")
def get_universe_screener(
    market: str = "ALL",
    q: str | None = None,
    sector: str | None = None,
    industry: str | None = None,
    market_cap_min: float | None = None,
    market_cap_max: float | None = None,
    eps_min: float | None = None,
    revenue_min: float | None = None,
    net_income_min: float | None = None,
    roe_min: float | None = None,
    roa_min: float | None = None,
    profit_margin_min: float | None = None,
    institution_min: float | None = None,
    insider_min: float | None = None,
    close_min: float | None = None,
    close_max: float | None = None,
    distance_52w_high_max: float | None = None,
    distance_52w_low_max: float | None = None,
    volume_ratio_min: float | None = None,
    sort_by: str = "symbol",
    sort_dir: str = "asc",
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=10, le=100),
    db: Session = Depends(get_db),
):
    """Paginated multi-stock screener using only real stored DB data."""
    # If the symbol-master table has not populated yet, recover visible rows
    # from verified OHLCV/fundamental/ownership data already stored locally.
    # This prevents a transient external symbol-master outage from producing a
    # misleading "0 eligible stocks" screener.
    exchanges = _screener_market_exchanges(market)
    active_count = db.query(Company.id).filter(Company.is_active == 1, Company.exchange.in_(exchanges)).count()
    if active_count == 0:
        try:
            bootstrap_companies_from_stored_data(db)
        except Exception:
            db.rollback()
    query, expressions = _screener_query_parts(db, market)
    query = _apply_screener_filters(
        query, expressions, q, sector, industry, market_cap_min, market_cap_max,
        eps_min, revenue_min, net_income_min, roe_min, roa_min, profit_margin_min, institution_min, insider_min, close_min,
        close_max, distance_52w_high_max, distance_52w_low_max, volume_ratio_min,
    )
    total = int(query.count())
    sort_expr = expressions.get(sort_by, Company.symbol)
    order = sort_expr.desc() if (sort_dir or "asc").lower() == "desc" else sort_expr.asc()
    rows = query.order_by(order.nullslast(), Company.symbol.asc()).offset((page - 1) * page_size).limit(page_size).all()
    row_items = [_screener_row_dict(row) for row in rows]
    if _free_tier_mode():
        # OHLCV is intentionally not persisted on the 500 MB tier. Enrich only
        # the visible page with live one-year price statistics.
        row_items = _enrich_screener_rows_live(row_items)
    return _json_safe({
        "market": market.upper(),
        "page": page,
        "page_size": page_size,
        "total": total,
        "pages": max(1, math.ceil(total / page_size)) if page_size else 1,
        "rows": row_items,
        "facets": _screener_facets(db, market),
        "coverage": universe_data_status(db, market),
        "columns": [{"key": key, "label": label} for key, label in SCREENER_COLUMN_LABELS.items()],
        "default_columns": SCREENER_DEFAULT_COLUMNS,
        "data_rule": "Verified provider/database values only. On FREE_TIER_MODE, visible-page LTP/52-week statistics are fetched live without writing OHLCV to PostgreSQL; missing values remain N/A.",
    })


@router.get("/screener-export")
def export_universe_screener(
    market: str = "ALL",
    q: str | None = None,
    sector: str | None = None,
    industry: str | None = None,
    market_cap_min: float | None = None,
    market_cap_max: float | None = None,
    eps_min: float | None = None,
    revenue_min: float | None = None,
    net_income_min: float | None = None,
    roe_min: float | None = None,
    roa_min: float | None = None,
    profit_margin_min: float | None = None,
    institution_min: float | None = None,
    insider_min: float | None = None,
    close_min: float | None = None,
    close_max: float | None = None,
    distance_52w_high_max: float | None = None,
    distance_52w_low_max: float | None = None,
    volume_ratio_min: float | None = None,
    sort_by: str = "symbol",
    sort_dir: str = "asc",
    columns: str | None = None,
    db: Session = Depends(get_db),
):
    """Export the complete currently filtered screener result to Excel."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
        from openpyxl.utils import get_column_letter
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Excel export dependency is unavailable: {exc}")

    query, expressions = _screener_query_parts(db, market)
    query = _apply_screener_filters(
        query, expressions, q, sector, industry, market_cap_min, market_cap_max,
        eps_min, revenue_min, net_income_min, roe_min, roa_min, profit_margin_min, institution_min, insider_min, close_min,
        close_max, distance_52w_high_max, distance_52w_low_max, volume_ratio_min,
    )
    sort_expr = expressions.get(sort_by, Company.symbol)
    order = sort_expr.desc() if (sort_dir or "asc").lower() == "desc" else sort_expr.asc()
    rows = query.order_by(order.nullslast(), Company.symbol.asc()).limit(10000).all()

    requested = [c.strip() for c in (columns or "").split(",") if c.strip()]
    selected = [c for c in requested if c in SCREENER_COLUMN_LABELS] or list(SCREENER_DEFAULT_COLUMNS)
    if "symbol" not in selected:
        selected.insert(0, "symbol")

    wb = Workbook()
    ws = wb.active
    ws.title = "Filtered Stocks"
    ws.append([SCREENER_COLUMN_LABELS[c] for c in selected])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    fraction_percent_fields = {"profit_margin", "return_on_equity", "return_on_assets", "institution_percent", "insider_percent"}
    for row in rows:
        item = _screener_row_dict(row)
        values = []
        for c in selected:
            value = item.get(c)
            if c in fraction_percent_fields and value is not None:
                try:
                    value = float(value) * 100.0
                except Exception:
                    pass
            values.append(value)
        ws.append(values)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for idx, key in enumerate(selected, start=1):
        max_len = len(SCREENER_COLUMN_LABELS[key])
        for cell in ws[get_column_letter(idx)][1: min(ws.max_row, 300)]:
            max_len = max(max_len, len(str(cell.value)) if cell.value is not None else 0)
        ws.column_dimensions[get_column_letter(idx)].width = min(32, max(12, max_len + 2))

    meta = wb.create_sheet("Filter Summary")
    meta.append(["Filter", "Value"])
    for c in meta[1]: c.font = Font(bold=True)
    for key, value in [
        ("Market", market), ("Search", q), ("Sector", sector), ("Industry", industry),
        ("Market Cap Min", market_cap_min), ("Market Cap Max", market_cap_max),
        ("EPS Min", eps_min), ("Revenue Min", revenue_min), ("Net Income Min", net_income_min),
        ("ROE Min", roe_min), ("ROA Min", roa_min), ("Profit Margin Min", profit_margin_min),
        ("Institution Min", institution_min), ("Insider Min", insider_min),
        ("Close Min", close_min), ("Close Max", close_max),
        ("Distance 52W High Max", distance_52w_high_max),
        ("Distance 52W Low Max", distance_52w_low_max),
        ("Volume Ratio Min", volume_ratio_min), ("Sort By", sort_by), ("Sort Direction", sort_dir),
        ("Exported Rows", len(rows)),
    ]:
        meta.append([key, value])
    meta.append(["Data Rule", "Stored provider/database values only; missing fields remain blank/N/A."])

    stream = BytesIO()
    wb.save(stream)
    stream.seek(0)
    filename = f"{market.upper()}_filtered_stock_screener.xlsx"
    payload = stream.getvalue()
    return Response(
        content=payload,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(payload)),
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
        },
    )
